<?php
  session_start();
  
  // rudy@rudypospisil.com
  // Okay. You have to hit here in order to gain permission to move further.
  // Yeah, it's convoluted security, but that is the point.
  // Plus, I just like showing off my chops. :)

  echo('<form method=post action="toggle.php">' . "\n");
    echo('<label for=allowLdapSearch>Enter password:</label><br>' . "\n");
    echo('<input type=password name=allowLdapSearch />' . "\n");
    echo('<input type=submit />' . "\n");
  echo('</form>' . "\n");

  // Execute upon using hitting the submit button.
  if($_POST)
  {
    if($_POST['allowLdapSearch'] == 'GoldmanF')
    {
      $_SESSION['allowLdapSearch'] = true;  
      echo('LDAP search granted.');  
    }
    else
    {
      $_SESSION['allowLdapSearch'] = false;    
      echo('LDAP search not granted.');  
    }
  }
  
