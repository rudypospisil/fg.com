<?php 
  echo $_SERVER['DOCUMENT_ROOT'];
  var_dump($_SERVER);
  phpinfo();