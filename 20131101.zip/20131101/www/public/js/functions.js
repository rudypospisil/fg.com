/**
 * FG JavaScript functions.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */




/**
 * editOpenRequest()
 * This function listens for which edit link is clicked in the Open Requests module
 * and alerts the controller to which request needs to be loaded in for editing.
 * 
 */

function editOpenRequest()
{
  $(".selectable").click(function(event) {
      path = '/index.php/open_requests/edit?id=';
      window.location.href = path + $(this).attr("id");
  });
}


newRequestAlert = function(){
  var buttonSelected = confirm('It is necessary for the system to query the NAV server and fetch over 36,000 items. This may take up to 2-3 minutes. Please be patient. (Perhaps a cup of coffee is in order?) Click "OK" to continue, or click "Cancel" to cancel the request.');
  
  if(buttonSelected == true)
  {
    location.href = '/new_request/nav_wait';
  }
  else
  {
    return(false);
  }
}


/*

var startItemList_backup = $(function(){
  url = '/new_request/getItemListForAjax/0';
  $.getJSON(url, function(data){
    var output = '';
    for(i = 0; i < data.length; i++)
    {
      output += '<input id="' + data[i].item_no + '" class=' + i + ' type=radio name=item value=' 
        + data[i].item_no + '>' 
        + data[i].item_no + '&nbsp;&nbsp;&nbsp;' + data[i].style_no 
        + '</input></br>';
    }
    $('#output').html(output);
  });
});


var startItemList = $(function(){
  url = '/new_request/getItemListForAjax/0';
  $.getJSON(url, function(data){
    var output = '<ul>';
    for(i = 0; i < data.length; i++)
    {
      output += '<li id="' + data[i].item_no + '" class=' + i + ' name=item value=' 
        + data[i].item_no + '>' 
        + data[i].item_no + '&nbsp;&nbsp;&nbsp;' + data[i].style_no 
        + '</li></br>';
    }
    output += '</ul>';
    $('#output').html(output);
  });
});

*/


var scrollItemListListener = $(function(){
  var skip = 100;
  $('#itemList').scroll(function(){
    url = '/new_request/getItemListForAjax/' + skip;
    $.getJSON(url, function(data){
      var output = '';
      for(i = 0; i < data.length; i++)
      {
        output += '<input id="' + data[i].item_no + '" class=' + i + ' type=radio name=item value=' 
          + data[i].item_no + '>' 
          + data[i].item_no + '&nbsp;&nbsp;&nbsp;' + data[i].style_no 
          + '</input></br>';
      }
      $('#output').append(output);
      skip += 100;
    });
  });
});


var set_itemListHoverListener = $(function(){
  $('input[type=radio][name=item]').select(function(){
    var itemChecked = $('input[type=radio][name=item]:checked').val();
    var itemSearched = $('input[name=itemSearch]').val(itemChecked);
  console.log('Selected via Search Box: ' + itemSearched);
  console.log('Item Checked via Radio Button: ' + itemChecked);

  });
});


var autoCompleteListener = $(function(){                    
            //attach autocomplete  
            $("#itemSearch").autocomplete({  
                minLength: 2,          
                //define callback to format results  
                source: function(req, add){  
                          
                    //pass request to server  
                    $.getJSON("/new_request/getItemListForAutocomplete", req, function(data) {  
                                  
                        //create array for response objects  
                        var itemList = [];  
                                  
                        //process response  
                        for(i = 0; i < data.length; i++)
                        {
                          itemList.push(data[i].item_no);
                        }
                                  
                    //pass array to callback  
                    add(itemList);  
                    });  
                },
                select: function(event, ui){
                  $('#itemList').css({'display' : 'none'});
                  var id = ui.item.value;
                                    
                  $('input:radio[id="' + id + '"]').attr('checked',true);
                  $('input[name=item_no]').val(id);
                },
                response: function(event, ui){
                  if(ui.item == null){
                    $('#itemList').css({'display' : 'block'});
                    $('input[name=item_no]').val('');
                  }
                }                    
            }); 
          }); 


// Grab the starter list of NAV items.
var get_navStarterList = $(function(){                    
  url = '/new_request/getItemListForAjax/0';
  $.getJSON(url, function(data){
    var output = '';
    for(i = 0; i < data.length; i++)
    {
      output += '<input id="' + data[i].item_no + '" class=' + i + ' type=radio name=item value=' 
        + data[i].item_no + '>' 
        + data[i].item_no + '&nbsp;&nbsp;&nbsp;' + data[i].style_no 
        + '</input></br>';
    }
    $('#output').html(output);
  });
});


// Set the scroll function to feed in more items as user requires. Basically, a lazy load.
var set_navScrolling = $(function(){                    
  var skip = 100;
  $('#itemList').scroll(function(){
    url = '/new_request/getItemListForAjax/' + skip;
    $.getJSON(url, function(data){
      var output = '';
      for(i = 0; i < data.length; i++)
      {
        output += '<input id="' + data[i].item_no + '" class=' + i + ' type=radio name=item value=' 
          + data[i].item_no + '>' 
          + data[i].item_no + '&nbsp;&nbsp;&nbsp;' + data[i].style_no 
          + '</input></br>';
      }
      $('#output').append(output);
      skip += 100;
    });
  });
});


// Autocomplete functionality. User types in search box and list will then filter out accordingly.  
var set_navAutocomplete = $(function(){                    
      //attach autocomplete  
      $("#itemSearch").autocomplete({  
          minLength: 5,          
          //define callback to format results  
          source: function(req, add){  
                    
              //pass request to server  
              $.getJSON("/new_request/getItemListForAutocomplete", req, function(data) {
              
                  if(data.length > 1000)
                  {
                    var queue = 1000;                      
                    var navCount = '<br>(' + data.length + ' avail. Please refine search.)';
                  }
                  else
                  {
                    var queue = data.length;  
                    var navCount = ' (' + queue + ' avail.)';
                  }          
                  
                  $('#navCount').html(navCount);

                  //create array for response objects  
                  var itemList = [];  
                            
                  //process response  
                  for(i = 0; i < queue; i++)
                  {
                    itemList.push(data[i].item_no);
                  }
                            
              //pass array to callback  
              add(itemList);  
              });  
          },
          select: function(event, ui){
            $('#itemList').css({'display' : 'none'});
            var id = ui.item.value;
                              
            $('input:radio[id="' + id + '"]').attr('checked',true);
            $('input[name=item_no]').val(id);
          },
          response: function(event, ui){
            if(ui.item == null){
              $('#itemList').css({'display' : 'block'});
              $('input[name=item_no]').val('');
            }
          }                    
      }); 
});


// Grab the list of customers. Change customer info on onchange event.
var get_customerList = $(function(){                    

    var url = '/new_request/getCustomersList';

    // This will be the array of customers returned by the JSON function.
    var customers = [];
    //var batchingCustomer = '<?php echo $previousRequest->

    $.getJSON(url, function(data){
      customers = data;
      var customerDropdown = '<option value=null>Select...</option>';
      for(i = 0; i < data.length; i++)
      {
        customerDropdown += '<option value="' 
                          + data[i].customer 
                          + '">' 
                          + data[i].customer 
                          + '</option>';
      }
      
      $('#customerDropdown').html(customerDropdown);
    });
        
    $('#cusReqMore').change(function(){
      var customerSelection = $('#customerDropdown').val();
      
      if(customerSelection != 'null')
      {
        for(i = 0; i < customers.length; i++)
        {
          console.log(customers[i]);
          if(customerSelection == customers[i].customer)
          {
            var customerName = '<input type=hidden name="customerName"' + ' value="' + customers[i].customer + '" />';
            $('#customerName').val(customers[i].customer);
            console.log('customerName: '+ customerName);
            
            var customerFileType = '<input type=hidden name="customerFileType"' + ' value="' + customers[i].file_type + '" />' + customers[i].file_type;
            $('#customerFileType').html(customerFileType);
            
            var customerFileSizeWidth  = '<input type=hidden name="customerFileSizeWidth"' + ' value="' + customers[i].width + '" />';
            var customerFileSizeHeight  = '<input type=hidden name="customerFileSizeHeight"' + ' value="' + customers[i].height + '" />';            
            var customerFileSize = customers[i].width + 'px (w) by ' + customers[i].height + 'px (h)';            
            $('#customerFileSize').html(customerFileSizeWidth + customerFileSizeHeight + customerFileSize);
            
            var customerComment  = '<input type=hidden name="customerComment"' + ' value="' + customers[i].comment + '" />' + customers[i].comment;
            $('#customerComment').html(customerComment);
          }          
        }
      }
      if(customerSelection == 'null')
      {
        $('#customerFileType').html('&nbsp;');
        $('#customerFileSize').html('&nbsp;');
        $('#customerComment').html('&nbsp;');
      }
    });
});






// Validate the new request before submitting to database.
var validateNewRequest = function(){
  console.log('hello');
  
  var errorMsg = '';
        
  //var itemSearchBox = $('input[type=text][id=itemSearch]').val();
  var itemChecked = $('input[type=radio][name=item]:checked').val();
  var itemSearched = $('input[name=itemSearch]').val();
  console.log('Selected via Search Box: ' + itemSearched);
  console.log('Item Checked via Radio Button: ' + itemChecked);
  if((!itemChecked || typeof(itemChecked) === 'undefined' || itemChecked == '')
    && (!itemSearch || typeof(itemSearched) === 'undefined' || itemSearched == ''))
  {
    errorMsg += 'You must select an item!';
    console.log(errorMsg);
  }
  
  var angle = $('input[type=checkbox]:checked').val();
  //console.log('Angle: ' + angle);
  if(!angle)
  {
    errorMsg += '<br>You must select at least one angle!';
    //console.log(errorMsg);
  }
  
  var priority = $('select[name=priority]').val();
  //console.log('Priority: ' + priority);
  if(!priority || typeof(priority) === 'undefined' || priority == '' || priority == 0)
  {
    errorMsg += '<br>You must set the priority!';
    //console.log(errorMsg);
  }
  
  var customer = $('#customerDropdown').val();
  var requestType = $('input[type=radio][name=type]:checked').val();
  //console.log('Type: ' + requestType);
  //console.log('Customer: ' + customer);
  if(requestType === 'Customer Request' && customer === 'null')
  {
    errorMsg += '<br>You must choose a customer!';
  } 
  
  if(errorMsg == '')
  {
    return true;
  }
  else
  {
    $('#errorMsg').empty();
    $('#errorMsg').html(errorMsg);

    return false;
  }    
}


// Make sure that at least one batch member was selected.
var validateBatchMembersChecked = function(){
  $('#noBatchMemberSelectedError').css('visibility', 'hidden');
  var memberChecked = $('input[type=checkbox]:checked').val();
  console.log(memberChecked);
  if(!memberChecked || typeof(memberChecked) === 'undefined' || memberChecked == '')  
  {
    $('#noBatchMemberSelectedError').css({'visibility': 'visible'});
    console.log('No members have been checked.');
    return false;
  }
  else
  {
    var membersChecked = [];
    var output = '';
    $('input[type=checkbox]:checked').each(function() {
     //membersChecked.push($(this).val());
     output += $(this).val() + '|';
    });
    $('#batchMembersToDelete').html('<input type=hidden name=batchMembersToDelete value="' + output + '" />');
    $('#batchMembersToUpdate').html('<input type=hidden name=batchMembersToUpdate value="' + output + '" />');
    console.log($('#batchMembersToDelete').html());
    console.log($('#batchMembersToUpdate').html());
    console.log('Members have been checked.');
    return true;
  }
}



// Give the user a chance to say no.
var validateBatchTitle = function(){
  var batchProjectTitle = $('input[type=text][name=batchProjectTitle]').val();
  if(batchProjectTitle)
  {
    console.log('batchProjectTitle: ' + batchProjectTitle);
    return true;
  }
  else
  {
    console.log('Nothing was entered for a new Project Title: ' + batchProjectTitle);
    return false;
  }
}

// Give the user a chance to say no.
var validateBatchInputs = function(){
  var batchProjectTitle  = $('input[type=text][name=batchProjectTitle]').val();
  var batchPriority      = $('input[type=select][name=batchPriority]').val();
  var batchDueDate       = $('input[type=text][name=batchDueDate]').val();
  var batchPhotographer  = $('input[type=select][name=batchPhotographer]').val();
  var batchShootDate     = $('input[type=text][name=batchShootDate]').val();
  if(batchProjectTitle )
  {
    console.log('batchProjectTitle: ' + batchProjectTitle);
    return true;
  }
  else
  {
    console.log('Nothing was entered for a new Project Title.');
    return false;
  }
}

// Give the user a chance to say no.
var validateBatchMemberDelete = function(){
  if(validateBatchMembersChecked() == true)
  {
    var secondChance = confirm('Are you sure that you want to delete? Once you do, they are gone forever.');
    if(secondChance == true)
    {
      return true;
    }
    else
    {
      console.log('Cancel button clicked.');
      return false;
    }
  }
  else
  {
    console.log('Confirm dialog bypassed.');
    return false;
  }
}

// Give the user a chance to say no.
var validateBatchMemberUpdate = function(){
  //console.log($('select[name=batchPriority]').val());
  if(validateBatchMembersChecked() == true || validateBatchTitle() == true)
  {
    console.log('update is true');
    return true;
  }
  else
  {
    return false;
  }
}


// Grab the list of customers. Change customer info on onchange event.
var get_customerListWithSelect = function(){                    

    $.getJSON('/data/get_customer', function(cust){
      //console.log('Cust: ' + cust[0].customer);
    });

    var url = '/new_request/getCustomersList';

    // This will be the array of customers returned by the JSON function.
    var customers = [];

    $.getJSON(url, function(data){
  
      customers = data;
      for(i = 0; i < customers.length; i++)
      {
        //console.log($('#customerDropdown').html());
        //console.log($('#customerDropdown').val());

        if(customers[i].customer == $('#customerDropdown').val())
        {
          //console.log(customers[i].customer);
          customerDropdown += '<option selected=selected value="' 
                          + customers[i].customer 
                          + '">' 
                          + customers[i].customer 
                          + '</option>';          
        }
        else
        {
          customerDropdown += '<option value="' 
                          + customers[i].customer 
                          + '">' 
                          + customers[i].customer 
                          + '</option>';          
        }
      }
      document.getElementById('customerDropdown').innerHTML = '';
      document.getElementById('customerDropdown').innerHTML = customerDropdown;
      //$('#customerDropdown').html(customerDropdown);
      //console.log($('#customerDropdown').html());
      //console.log(customerDropdown);
    });
        
    $('#cusReqMore').change(function(){
      var customerSelection = $('#customerDropdown').val();
      
      if(customerSelection != 'null')
      {
        for(i = 0; i < customers.length; i++)
        {
          console.log(customers[i]);
          if(customerSelection == customers[i].customer)
          {
            var customerName = '<input type=hidden name="customerName"' + ' value="' + customers[i].customer + '" />';
            $('#customerName').val(customers[i].customer);
            //console.log('customerName: '+ customerName);
            
            var customerFileType = '<input type=hidden name="customerFileType"' + ' value="' + customers[i].file_type + '" />' + customers[i].file_type;
            $('#customerFileType').html(customerFileType);
            
            var customerFileSizeWidth  = '<input type=hidden name="customerFileSizeWidth"' + ' value="' + customers[i].width + '" />';
            var customerFileSizeHeight  = '<input type=hidden name="customerFileSizeHeight"' + ' value="' + customers[i].height + '" />';            
            var customerFileSize = customers[i].width + 'px (w) by ' + customers[i].height + 'px (h)';            
            $('#customerFileSize').html(customerFileSizeWidth + customerFileSizeHeight + customerFileSize);
            
            var customerComment  = '<input type=hidden name="customerComment"' + ' value="' + customers[i].comment + '" />' + customers[i].comment;
            $('#customerComment').html(customerComment);
          }          
        }
      }
      if(customerSelection == 'null')
      {
        $('#customerFileType').html('&nbsp;');
        $('#customerFileSize').html('&nbsp;');
        $('#customerComment').html('&nbsp;');
      }
    });
}  


// Set up the Customer hide/show function for the edit page.
var customerHideShow = function(){    
  $('select[name=type]').change(function(){
    var typeSelected = $(this).val();
    //console.log('typeSelected: ' + typeSelected);
    if(typeSelected == 'Customer Request')
    {
      $('#customerLabels').show();
      $('#cusReqMore').show();
      var customerSelected = $('#customerDropdown').val();     
      //console.log('customerSelected: ' + customerSelected);
      $('input[name=customer]').val(customerSelected);
      //console.log('customer: ' + $('input[name=customer]').val());
      //console.log('customerName: ' + $('input[name=customerName]').val());
    }
    else
    {
      $('#customerLabels').hide();
      $('#cusReqMore').hide();
    }
  });
  
  $('select[name=customerDropdown]').change(function(){
    var customerSelected = $('#customerDropdown').val();
    $('input[name=customer]').val(customerSelected);
      //console.log('customer: ' + $('input[name=customer]').val());
  });
}


// This preps the tooltip which becomes visible when user clicks icon.
var prepTooltip = function(){
  $('#tooltipIcon').click(function(){
    if($('#tooltipPopup').css('display') == 'none')
    {
      $('#tooltipIcon').attr('src', '/img/icons/icon_tooltip_on.png');
      $('#tooltipPopup').css('display', 'block');
    }
    else
    {
      $('#tooltipIcon').attr('src', '/img/icons/icon_tooltip.png');
      $('#tooltipPopup').css({'display':'none'});
    }
  });
}


// Grab the open request from the db and show in a popup.
var requestDetailsPopup = function(itemId){                    
  
  var url = '/open_requests/ajax_getOpenRequest/' + itemId;
  var output = '';

  $.getJSON(url, function(request){
    $.each(request, function(){
      $.each(this, function(key, value){
        //console.log('Key: ' + key);
        //console.log('Value: ' + value);
        output += '<li>' + key + ': ' + value + '</li>';
      });
    console.log(output);
     $('.itemDetailPopup').css('display', 'block');
     $('.itemDetailPopup').html(output);
    return output;
    });
  });    
}



// Grab the open request from the db and show in a popup.
var get_openRequestDetailsPopup = function(itemId){                    
  
  var url = '/open_requests/ajax_getOpenRequest/' + itemId;
  var payload = '';

  $.getJSON(url, function(openRequest){
    payload = 
      '<ul id=popup>'
      + '<li><span class=bold >Project Title: </span>'     + openRequest[0].project_title        + '</li>' + "\n"
      + '<li><span class=bold >Item: No: </span>'          + openRequest[0].item_no              + '</li>' + "\n"
      + '<li><span class=bold >Style No: </span>'          + openRequest[0].style_no             + '</li>' + "\n"
      + '<li><span class=bold >Angle: </span>'             + openRequest[0].angle                + '</li>' + "\n"
      + '<li><span class=bold >Brand: </span>'             + openRequest[0].brand                + '</li>' + "\n"
      + '<li><span class=bold >Priority: </span>'          + openRequest[0].priority             + '</li>' + "\n"
      + '<li><span class=bold >Due Date: </span>'          + openRequest[0].due_date             + '</li>' + "\n"
      + '<li><span class=bold >Status: </span>'            + openRequest[0].status               + '</li>' + "\n"
      + '<li><span class=bold >Type: </span>'              + openRequest[0].type                 + '</li>' + "\n"
      + '<li><span class=bold >Customer: </span>'          + openRequest[0].customer             + '</li>' + "\n"
      + '<li><span class=bold >File Type: </span>'         + openRequest[0].file_type            + '</li>' + "\n"
      + '<li><span class=bold >File Width: </span>'        + openRequest[0].file_width           + '</li>' + "\n"
      + '<li><span class=bold >File Height: </span>'       + openRequest[0].file_height          + '</li>' + "\n"
      + '<li><span class=bold >Customer Comment: </span>'  + openRequest[0].customer_comment     + '</li>' + "\n"
      + '<li><span class=bold >Photographer: </span>'      + openRequest[0].photographer         + '</li>' + "\n"
      + '<li><span class=bold >Shoot Date: </span>'        + openRequest[0].shoot_date           + '</li>' + "\n"
      + '<li><span class=bold >Requester: </span>'         + openRequest[0].requester            + '</li>' + "\n"
      + '<li><span class=bold >Submitted: </span>'         + openRequest[0].timestamp_created    + '</li>' + "\n"
      + '<li><span class=bold >Notes: </span>'             + openRequest[0].notes                + '</li>' + "\n"
      + '<li><span class="bold italic" >PIS Batch No: </span>'      + openRequest[0].batch_no             + '</li>' + "\n"
      + '<li><span class="bold italic" >PIS ID: </span>'            + openRequest[0].id                   + '</li>' + "\n"
      + '</ul>'
      ;
    //console.log(payload);    
     $('.itemDetailPopup').css('display', 'block');
     $('.itemDetailPopup').html(payload);     
    //return payload;
  });   
}

// Grab the open request from the db and show in a popup.
var get_completedRequestDetailsPopup = function(itemId){                    
  
  var url = '/completed_requests/ajax_getCompletedRequest/' + itemId;
  var payload = '';

  $.getJSON(url, function(completedRequest){
    payload = 
      '<ul id=popup>'
      + '<li><span class=bold >Project Title: </span>'     + completedRequest[0].project_title        + '</li>' + "\n"
      + '<li><span class=bold >Item: No: </span>'          + completedRequest[0].item_no              + '</li>' + "\n"
      + '<li><span class=bold >Style No: </span>'          + completedRequest[0].style_no             + '</li>' + "\n"
      + '<li><span class=bold >Angle: </span>'             + completedRequest[0].angle                + '</li>' + "\n"
      + '<li><span class=bold >Brand: </span>'             + completedRequest[0].brand                + '</li>' + "\n"
      + '<li><span class=bold >Priority: </span>'          + completedRequest[0].priority             + '</li>' + "\n"
      + '<li><span class=bold >Due Date: </span>'          + completedRequest[0].due_date             + '</li>' + "\n"
      + '<li><span class=bold >Status: </span>'            + completedRequest[0].status               + '</li>' + "\n"
      + '<li><span class=bold >Type: </span>'              + completedRequest[0].type                 + '</li>' + "\n"
      + '<li><span class=bold >Customer: </span>'          + completedRequest[0].customer             + '</li>' + "\n"
      + '<li><span class=bold >File Type: </span>'         + completedRequest[0].file_type            + '</li>' + "\n"
      + '<li><span class=bold >File Width: </span>'        + completedRequest[0].file_width           + '</li>' + "\n"
      + '<li><span class=bold >File Height: </span>'       + completedRequest[0].file_height          + '</li>' + "\n"
      + '<li><span class=bold >Customer Comment: </span>'  + completedRequest[0].customer_comment     + '</li>' + "\n"
      + '<li><span class=bold >Photographer: </span>'      + completedRequest[0].photographer         + '</li>' + "\n"
      + '<li><span class=bold >Shoot Date: </span>'        + completedRequest[0].shoot_date           + '</li>' + "\n"
      + '<li><span class=bold >Requester: </span>'         + completedRequest[0].requester            + '</li>' + "\n"
      + '<li><span class=bold >Submitted: </span>'         + completedRequest[0].timestamp_created    + '</li>' + "\n"
      + '<li><span class=bold >Notes: </span>'             + completedRequest[0].notes                + '</li>' + "\n"
      + '<li><span class="bold italic" >PIS Batch No: </span>'      + completedRequest[0].batch_no             + '</li>' + "\n"
      + '<li><span class="bold italic" >PIS ID: </span>'            + completedRequest[0].id                   + '</li>' + "\n"
      + '<li><span class="bold italic" >Open Request ID: </span>'            + completedRequest[0].open_request_id                   + '</li>' + "\n"
      + '</ul>'
      ;
    //console.log(payload);    
     $('.itemDetailPopup').css('display', 'block');
     $('.itemDetailPopup').html(payload);     
    //return payload;
  });   
}



// Grab the batch request from the db and show in a popup.
var get_batchedRequestsDetailsPopup = function(batchNo)
{                      
  var url = '/open_requests/ajax_getBatchedRequests/' + batchNo;
  var payload = '';

  $.getJSON(url, function(batchDetails){
    payload = 
      '<ul id=popup>'
      + '<li><span class=bold >Project Title: </span>'     + batchDetails[0].project_title        + '</li>' + "\n"
      + '</ul>'
      ;
    //console.log(payload);    
     $('.batchDetailPopup').css('display', 'block');
     $('.batchDetailPopup').html(payload);     
    //return payload;
  });   
}



var get_mouseY = function(){
 $(document).mousemove(function(e){
    var yPosition = e.pageY - 380;
    $('.itemDetailPopup').css('top', yPosition);
    console.log('Browser Height: ' + $(window).height());
    console.log('Mouse Y: ' + yPosition);
    console.log('Height of Popup: ' + $('.itemDetailPopup').height());
    //console.log('Bottom Y of Popup: ' + $('.itemDetailPopup').height());
    return yPosition;
 });
}


var selectAllCheckboxes = function(){
  $('#selectAll').find(':checkbox').prop('checked', true);
}
var deselectAllCheckboxes = function(){
  $('#selectAll').find(':checkbox').prop('checked', false);
}



// NEW REQUESTS
// Set up the jQuery tabs.
var set_tabsNewRequest = function()
{
  $("#tabs").tabs({ active: 0 });
}  
    
// Set up the calendar function.
var set_datePickerNewRequest = function()
{
  $("#dueDatePicker").datepicker(
    {
      defaultDate: 'TBD',
    }
  );
}

// Set up the Customer hide/show function.
var set_customerBoxNewRequest = function()
{
  $('#cusReqMore').hide();
  
  $('#prototype').click(function(){
    $('#cusReqMore').hide()
  });
    
  $('#production').click(function(){
    $('#cusReqMore').hide()
  });
    
  $('#cusreq').click(function(){
    $('#cusReqMore').show();  
  });  
}
