<?php
/**
 * Admin Control Panel view.
 * This view builds the admin control panel page.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
?>

<?php Loader::load('head', $title); ?>

<script>
 $(function($) {
   // Grab # location from the URI.
   // This is coming after a user adds/updates/deletes.
   var tab = window.location.hash;
   
   // The tab variable must be numbered indices, so this switch will convert them.
   switch(tab)
   {
     case '#tab-status_codes':
      tab = 0;
      break;
     case '#tab-angles':
      tab = 1;
      break;
     case '#tab-photographers':
      tab = 2;
      break;
     case '#tab-customers':
      tab = 3;
      break;
     case '#tab-applications':
      tab = 4;
      break;
     default:
      tab = 0;
   }
   
   // Jump to the current tab in use.
   $("#tabs").tabs({ active: tab });
 }); 
</script>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=adminContent>
              
      <h3>ADMIN CONTROL PANEL</h3>

        <div id="tabs">
          <ul>
          <?php
            $memberof = Login::get_userMemberof();
            switch($memberof)
            {
              case 'admin':
          ?>
            <li><a href="#tab-status_codes">Status Codes</a></li>
            <li><a href="#tab-angles">Angles</a></li>
            <li><a href="#tab-photographers">Photographers</a></li>
            <li><a href="#tab-customers">Customers</a></li>
            <li><a href="#tab-applications">Applications</a></li>
            <li><a href="#tab-definitions">Definitions</a></li>
          <?php
                break;
              case 'manager':
          ?>
            <li><a href="#tab-status_codes">Status Codes</a></li>
            <li><a href="#tab-angles">Angles</a></li>
            <li><a href="#tab-photographers">Photographers</a></li>
            <li><a href="#tab-customers">Customers</a></li>
          <?php
              break;        
            }
          ?>
          </ul>

          <?php
            if($memberof == 'admin')
            {
            ?>          
            <div id="tab-applications">            
              <div>                
                <?php echo(Form::open('admin/add_entry/app_spec','post')); ?>
                <?php echo(Form::submit('+')); ?>
                <?php echo(Form::close()); ?>                            
                <br>
              </div>
            
              <?php
                if(count($app_specs) == 0)
                {
                  echo 'There are currently no application specs set up in the database. You must add them.';
                }
                else
                {
              ?>
              <table>
                <tr class=header><td>&nbsp;</td><td>APPLICATION</td><td>NAMING FORMULA</td><td>FILE LOCATION</td><td>WIDTH</td><td>HEIGHT</td><td>TYPE</td></tr>
              <?php
                for($i = 0; $i < count($app_specs); $i++)
                {
                  echo('<tr><td>');
                  echo(Form::open('admin/add_child_entry/app_spec/' . $app_specs[$i]->application,'post'));
                  echo(Form::submit('+'));
                  echo(Form::close());                            
                  echo('</td>');
                  echo(Form::open('admin/update/app_spec','post'));
                  echo(Form::hidden('id', $app_specs[$i]->id));
                  echo('<td class=largeField>' . Form::text('application', $app_specs[$i]->application) . '</td>');
                  echo('<td class=largeField>' . Form::text('naming_formula', $app_specs[$i]->naming_formula) . '</td>');
                  echo('<td class=largeField>' . Form::text('file_location', $app_specs[$i]->file_location) . '</td>');
                  echo('<td class=medField>' . Form::text('width', $app_specs[$i]->width) . '</td>');
                  echo('<td class=medField>' . Form::text('height', $app_specs[$i]->height) . '</td>');
                  echo('<td class=smallField>' . Form::select('type', array('jpg' => 'jpg', 'gif' => 'gif', 'png' => 'png', 'psd' => 'psd', 'tif' => 'tif'), $app_specs[$i]->type) . '</td>');
                  echo('<td class=noBorder>' . Form::submit('UPDATE') . '</td>');
                  echo(Form::close() . "\n");
                  echo(Form::open('admin/delete/app_spec','post'));
                  echo(Form::hidden('id', $app_specs[$i]->id));
                  echo('<td class=noBorder>' . Form::submit('DELETE', array('id' => 'delete')) . '</td>');
                  echo(Form::close());
                  echo('</tr>' . "\n");
                }
              }
              ?>
              </table>
              <br>
              <p>All parameters must be separated (delimited) by commas.</p>
              <p>Visit the Definitions tab for a handy cheat sheet detailing which codes to use.</p>
              <p>&nbsp;</p>
              <p><em>Please note: if any data is missing for an item, the option will not show up in the Imaging Utility.</em></p>
              <br>
            </div>
            <?php
            }
            ?>
            
            <div id="tab-status_codes">
               <div>                
                <?php echo(Form::open('admin/add_entry/status_code','post')); ?>
                <?php echo(Form::submit('+')); ?>
                <?php echo(Form::close()); ?>                            
                <br>
              </div>
            
              <?php
                if(count($status_codes) == 0)
                {
                  echo 'There are currently no status codes set up in the database. You must add them.';
                }
                else
                {
              ?>
              <table>
                <tr class=header><td>STATUS CODES</td></tr>
              <?php
                for($j = 0; $j < count($status_codes); $j++)
                {
                  if($status_codes[$j]->status_code == 'Completed')
                  {
                    echo '<tr><td class="largeField italic">Completed</td><td>(unmodifiable)</td></tr>';
                  }
                  else
                  {
                    echo('<tr>');
                    echo(Form::open('admin/update/status_code','post'));
                    echo(Form::hidden('id', $status_codes[$j]->id));
                    echo('<td class=largeField>' . Form::text('status_code', $status_codes[$j]->status_code) . '</td>');
                    echo('<td class=noBorder>' . Form::submit('UPDATE') . '</td>');
                    echo(Form::close() . "\n");
                    echo(Form::open('admin/delete/status_code','post'));
                    echo(Form::hidden('id', $status_codes[$j]->id));
                    echo('<td class=noBorder>' . Form::submit('DELETE', array('id' => 'delete')) . '</td>');
                    echo(Form::close());
                    echo('</tr>' . "\n");
                  }
                }
              }
              ?>
              </table>
              <br>
            </div>
            
            <div id="tab-angles">
              <div>                
                <?php echo(Form::open('admin/add_entry/angle','post')); ?>
                <?php echo(Form::submit('+')); ?>
                <?php echo(Form::close()); ?>                            
                <br>
              </div>
            
              <?php
                if(count($angles) == 0)
                {
                  echo 'There are currently no angles set up in the database. You must add them.';
                }
                else
                {
              ?>
              <table>
                <tr class=header><td>ANGLES</td></tr>
              <?php
                for($j = 0; $j < count($angles); $j++)
                {
                  echo('<tr>');
                  echo(Form::open('admin/update/angle','post'));
                  echo(Form::hidden('id', $angles[$j]->id));
                  echo('<td class=largeField>' . Form::text('angle', $angles[$j]->angle) . '</td>');
                  echo('<td class=noBorder>' . Form::submit('UPDATE') . '</td>');
                  echo(Form::close() . "\n");
                  echo(Form::open('admin/delete/angle','post'));
                  echo(Form::hidden('id', $angles[$j]->id));
                  echo('<td class=noBorder>' . Form::submit('DELETE', array('id' => 'delete')) . '</td>');
                  echo(Form::close());
                  echo('</tr>' . "\n");
                }
              }
              ?>
              </table>
              <br>
            </div>

            <div id="tab-photographers">
              <div>                
                <p>When creating a new photographer, the system will automatically create a username & password from the First Name & Last Name.
                  <br>
                  If you update a photographer's name, a new username and password will be generated. If you update their email, a new password will be generated. This is simply for reasons of security.
                </p>
                <br>
                <br>
                <?php echo(Form::open('admin/add_entry/photographer','post')); ?>
                <?php echo(Form::submit('+') . ' (add new photographer)' . '<br><br>'); ?>
                <?php echo(Form::close()); ?>  
              </div>
            
              <?php
                if(count($photographers) == 0)
                {
                  echo 'There are currently no photographers set up in the database. You must add them.';
                }
                else
                {
              ?>
              <table>
                <tr class=header>
                  <td>FIRST NAME</td>
                  <td>LAST NAME</td>
                  <td>E-MAIL</td>
                  <td>USERNAME</td>
                  <td>PASSWORD</td>
                </tr>
              <?php
                for($i = 0; $i < count($photographers); $i++)
                {
                  echo('<tr>');
                  echo(Form::open('admin/update/photographer','post'));
                  echo(Form::hidden('id', $photographers[$i]->id));
                  echo('<td>' . Form::text('first_name', $photographers[$i]->first_name) . '</td>');
                  echo('<td>' . Form::text('last_name', $photographers[$i]->last_name) . '</td>');
                  echo('<td>' . Form::text('email', $photographers[$i]->email) . '</td>');
                  echo('<td>' . $photographers[$i]->username . '</td>');
                  echo('<td>' . $photographers[$i]->password . '</td>');
                  echo('<td class=noBorder>' . Form::submit('UPDATE') . '</td>');
                  echo(Form::close() . "\n");
                  echo(Form::open('admin/delete/photographer','post'));
                  echo(Form::hidden('id', $photographers[$i]->id));
                  echo('<td class=noBorder>' . Form::submit('DELETE', array('id' => 'delete')) . '</td>');
                  echo(Form::close());
                  echo('</tr>' . "\n");
                }
              }
              ?>
              </table>
              <br>
            </div><!-- #tab-photographers -->


            <div id="tab-customers">
              <div>                
                <?php echo Form::open('admin/add_entry/customer','post'); ?>
                <?php echo Form::submit('+'); ?>
                <?php echo Form::close(); ?>                            
                <br>
              </div>
            
              <?php
                if(count($customers) == 0)
                {
                  echo 'There are currently no customers in the database. You must add them.';
                }
                else
                {
              ?>
              <table>
                <tr class=header><td>CUSTOMER NAME</td><td>FILE TYPE</td><td>WIDTH (px)</td><td>HEIGHT (px)</td><td>COMMENT</td>
                <!-- <td>DOCUMENTATION</td> -->
                </tr>
              <?php
                  for($i = 0; $i < count($customers); $i++)
                  {
                    echo('<tr>');
                    echo Form::open('admin/update/customer','post');
                    echo Form::hidden('id', $customers[$i]->id);
                    echo('<td class=largeField>' . Form::text('customer', $customers[$i]->customer) . '</td>');
                    echo('<td class=medField>' . Form::select('file_type', array('jpg' => 'jpg', 'gif' => 'gif', 'png' => 'png', 'psd' => 'psd', 'tif' => 'tif'), $customers[$i]->file_type) . '</td>');
                    echo('<td class=medField>' . Form::text('width', $customers[$i]->width) . '</td>');
                    echo('<td class=medField>' . Form::text('height', $customers[$i]->height) . '</td>');
                    echo('<td class=largeField>' . Form::text('comment', $customers[$i]->comment) . '</td>');
                    //echo('<td class=medField><a href="__' . $customers[$i]->file_path . '" /></td>');
                    
                    echo('<td class=noBorder>' . Form::submit('UPDATE') . '</td>');                    
                    echo Form::close() . "\n";
                    
                    echo(Form::open('admin/delete/customer','post'));
                    echo(Form::hidden('id', $customers[$i]->id));
                    echo('<td class=noBorder>' . Form::submit('DELETE', array('id' => 'delete')) . '</td>');
                    echo Form::close();
                    echo '</tr>' . "\n";
                  }
                }
              ?>
              </table>
              <br>
              <!--
              <form enctype="multipart/form-data" action="admin/uploadDoc/customer" method="POST">
                <input type="hidden" name="MAX_FILE_SIZE" value="100000" />
                Choose a file to upload: <input name="uploadDoc" type="file" /><br />
                <input type="submit" value="Upload File" />
                </form>
              -->
            </div><!-- #tab-customers -->

          <?php
            if($memberof == 'admin')
            {
            ?>          
            <div id="tab-definitions">
              <table>
                <tr class=header><td>CODE</td><td>The Naming Formula's Attribute.</td></tr>
                  <tr><td><strong>item_no </strong></td><td>A product's item number.</tr>
                  <tr><td><strong>angle </strong></td><td>A product's angle.</tr>
                  <tr><td><strong>- </strong></td><td>A delimiter. Used to separate parameters within file name.</tr>
                  <tr><td><strong> </strong></td><td></tr>
                  <tr><td><strong> </strong></td><td></tr>
                  <tr><td><strong> </strong></td><td></tr>
                  <tr><td><strong> </strong></td><td></tr>
                  <tr><td><strong> </strong></td><td></tr>
                  <tr><td><strong> </strong></td><td></tr>
              </table>
              <br>
              <p>A typical example would be "item_no,-,style_no,-,angle". This will yield, as an example, "1234-567-flat" as the file name.</p>
            </div><!-- #tab-definitions -->
          <?php
            }
          ?>
          
        </div><!--adminContent-->
        
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
<?php Loader::load('footer'); ?>