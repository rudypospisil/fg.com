<?php
/**
 * Product Detail view.
 * This view shows each individual product page.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date May 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<script>
 $(function($) {   
   // Jump to the current tab in use.
   $("#tabs").tabs({ active: 0 });
 }); 
</script>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=adminContent>
              
      <h3 style="margin: 0 0 10px 0;">PRODUCT DETAIL PAGE</h3>
      <a href="/index.php/library"><p style="margin: 0 0 10px 0;">< BACK</p></a>

        <div id="tabs">
          <ul>
            <li><a href="#tab-product">Product</a></li>
            <li><a href="#tab-more_details">More Details</a></li>
          </ul>
          
            <div id="tab-product">            
              <div id=productDetailThumb>                
                 <img src="/filestore/thumbnails/300px/<?php echo($fileDetails->pis_file_name); ?>_300px_tb.jpg"  style="float: left;" />
              </div>
               <div id=productDetails>
               <?php 
                echo('File Name: ' . $fileDetails->pis_file_name . '<br>');
                
                if($fileDetails->pis_no != 0)
                {
                  echo('Angle: ' . $productDetails->angle . '<br>');
                  echo('Type: ' . $productDetails->type . '<br>');
                  echo('Customer: ' . $productDetails->customer . '<br>');
                  echo('Originally Requested By: ' . $productDetails->requester . '<br>');
                  echo('Photographer: ' . $productDetails->photographer . '<br>');
                }
               ?>
               </div><!--productDetails-->
              <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
            </div><!--tab-product-->
            
        </div><!--tabs-->
        
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>