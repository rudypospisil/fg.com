<?php
/**
 * New Request view - adding to a batch.
 * This view builds the new request form.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>

<?php Loader::load('head', $title); ?>

<script>
  // Set up the jQuery tabs.
  $(function(){
   $("#tabs").tabs({ active: 0 });
  });  
    
  // Set up the calendar function.
  $(function() {
    $("#dueDatePicker").datepicker();
  });

  // Set up the Customer hide/show function.
  $(function() {
    var reqType = '<?php echo $previousRequest->type; ?>';
    console.log(reqType);
    if(reqType == 'Customer Request')
    {
      $('#cusReqMore').show();
    }
    else
    {
      $('#cusReqMore').hide();
    }
    
    $('#prototype').click(function(){
      $('#cusReqMore').hide()
    });
      
    $('#production').click(function(){
      $('#cusReqMore').hide()
    });
      
    $('#cusreq').click(function(){
      $('#cusReqMore').show();  
    });  
  });
    
 $(document).ready(function(){
    var errorMsg = '';
    var itemChecked = '';
    var itemSearch = '';
    // Grab the starter list of NAV items.
    get_navStarterList();
    
    // Set the scroll function to feed in more items as user requires. Basically, a lazy load.
    set_navScrolling();
    
    // Autocomplete functionality. User types in search box and list will then filter out accordingly.
    set_navAutocomplete();
  
    // Grab the list of customers from db. Change customer info on onchange event.
    get_customerList();  
});
</script>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=content class=newRequest>
        
      <h3>BATCHING:<br>ADDING ANOTHER REQUEST TO YOUR PROJECT</h3>
      
       <div id="tabs">
          <ul>
            <li><a href="#tab-newRequest">Project Batch Request</a></li>
            <li><a href="#tab-photoStandards">Photography Standards</a></li>
          </ul>

          <div id="tab-newRequest">
            <div style="width: 960px; margin: 0 auto;">      
            <div style="float: left; margin: 0 30px;">
            
              <?php echo Form::open('new_request/submit','post', 
                array('name' => 'newRequest', 'onsubmit' => 'return validateNewRequest();')); ?>              
                              
                <br>
                  <?php echo Form::label('projectTitle', 'PROJECT TITLE'); ?>
                  <br>
                  <?php echo (!$previousRequest->project_title) ? 'None Given.' : $previousRequest->project_title; ?>
                  <?php echo Form::hidden('projectTitle', $previousRequest->project_title); ?>
                  <br><br>
                  <?php echo Form::label('dueDate', 'DUE DATE'); ?>
                  <br>
                  <?php echo Form::text('dueDate', $previousRequest->due_date, 
                                          array('id' => 'dueDatePicker')); ?>
                  <br>
                <br>
                
                <div id=reqType>
                  <?php echo Form::label('type', 'TYPE'); ?>
                  <br>
                  <?php echo Form::radio('type', 'Prototype', 
                                          ($previousRequest->type == 'Prototype' ? true : false),
                                          array('id' => 'prototype')); ?>
                  <?php echo Form::label('prototype', 'Prototype'); ?><br>
          
                  <?php echo Form::radio('type', 'Production', 
                                          ($previousRequest->type == 'Production' ? true : false), 
                                          array('id' => 'production')); ?>
                  <?php echo Form::label('production', 'Production'); ?><br>
        
                  <div id=custumerRequest>
                    <?php echo Form::radio('type', 'Customer Request', 
                                            ($previousRequest->type == 'Customer Request' ? true : false), 
                                            array('id' => 'cusreq')); ?>
                    <?php echo Form::label('cusreq', 'Customer Request'); ?><br>
                  </div>
                </div><!-- div#reqType -->
                
                <br>
                                
                <div id=product>
                  <label>SELECT AN ITEM</label> <span id=navCount>(<?php echo(number_format($itemListCount)); ?> avail.)</span><br>
                  
                  <input id=itemSearch name=itemSearch placeholder="Scroll, or type in item number to search (min 5 char)." />
                  
                  <fieldset>                  
                    <div id=itemList>
                      <table>
                        <tr><td><div id=output></div></td></tr>
                        <tr><td><input type=hidden name=item_no /></td></tr>
                      </table>
                    </div><!-- div#itemList -->
                </div><!-- div#product -->
                
            </div>

            <div style="float: left; margin: 20px 0 0 0;">
              <div id=angles>
                  <?php echo(Form::label('angles', 'ANGLES')); ?>
                  <br>
                  <?php foreach($angles as $angle)
                        {
                          $checked = false;
                          foreach($previousRequestAngles as $previousAngle)
                          {
                            if($previousAngle == $angle) { $checked = true; }
                          }
                          echo Form::checkbox("angles[]", $angle, $checked);
                          echo $angle;
                        }
                  ?>
                  <br>
                  <?php echo Form::label('angle', 'Other Angle?&nbsp;'); ?>
                  <?php echo Form::text('anglesOther', '', 
                                          array('id' => 'anglesOther', 
                                                'value' => $previousRequest->angle_other)); ?>
              </div>
              <br>

              <div id=cusReqMore>
                  <ul>
                    <li class=customerLabel>Customer</li>
                    <li class=customerData><select id=customerDropdown></select></li>
                    <input type=hidden name=customerName id=customerName />
                    <br>
                    <li class=customerLabel>File Type</li>
                    <li id=customerFileType class=customerData>&nbsp;</li>
                    <br>
                    <li class=customerLabel>File Size</li>
                    <li id=customerFileSize class=customerData>&nbsp;</li>
                    <br>
                    <li class=customerLabel>Comment</li>
                    <li id=customerComment class=customerData>&nbsp;</li>
                  </ul>
                <br><br>             
              </div>            
      
              <div>
                  <?php echo Form::label('notes', 'NOTES'); ?>
                  <br>
                  <?php echo Form::textarea('notes', '', 
                                            array('id' => 'notes', 
                                                  'placeholder' => 'Notes are optional.', 
                                                  'rows' => 3)); ?>
              </div>
              <br>
               
              <div>
                  <?php echo(Form::label('emailAlerts', "EMAIL ALERTS")); ?>
                  <br>
                  <span><em style="font-size: 12px;">(separate multiple addresses with commas)</em></span>
                  <br>
                  
                  <!-- , Session::get('ldap_email') . ', ' -->
                  <?php echo Form::textarea('emailAlerts', $previousRequest->email_alerts, 
                                              array('id' => 'emailAlerts', 'rows' => 2)); ?>
              </div>
              <br>
              
              <div>
                  <?php echo Form::label('priority', 'PRIORITY'); ?>
                  <br>
                  <em style="font-size: 12px;">(1 being lowest priority, 5 being highest priority)</em>
                  <br>
                  <?php echo Form::select('priority', 
                                          array('' => $priorityCodes), 
                                          $previousRequest->priority); ?>
             
              <br><br><br>
              <?php echo Form::submit('Submit'); ?>   
              <p id=errorMsg></p>  
            <?php echo Form::close(); ?>   
            </div><!--automargin-->
            </div>
          </div><!--tab-newRequest-->
          <br><br>
          
          <div id="tab-photoStandards">
            <ul>
              <li><a href="/filestore/specs/photographyStandards_2013_Zale_Corporation.pdf">Zales</a>, (PDF, 610K)</li>
            </ul>
          </div><!--tab-photoStandards-->

      </div><!--tabs-->
      
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
<?php Loader::load('footer'); ?>