<?php
/**
 * New Request Success view.
 * This view shows success and allows user to continue as batch or end.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=contentFixedWidth>
         <div class=editSavedNotice><p><img src="http://172.16.1.29/img/icons/icon_checkMark_green.png" />YOUR EDIT HAS BEEN SAVED.</p></div>
        <div style="clear: both;"></div><br>
        <p class=smallItal>(it is now available for editing in the Open Requests module.)</p>
        
        <div id=newRequestLabels>
          <ul>
            <li>Project Title: </li>
            <li>Priority: </li>
            <li>Requester: </li>
            <li>Submitted: </li>
            <li>Status: </li>
            <li>Due Date: </li>
            <li>Item No: </li>
            <li>Style No: </li>
            <li>Brand: </li>
            <li>Angles: </li>
            <li>Type: </li>
            <li>Customer: </li>
            <li>File Type: </li>
            <li>Size: </li>
            <li>Photographer: </li>
            <li>Shoot Date: </li>
            <li>Email Alerts: </li>
            <li>Notes: </li>
            <li>PIS Batch #: </li>
          </ul>
        </div>

        <div id=newRequestData>
          <ul>
          
          <?php $globals = DB::table('globals')->find(1) ?>
            <li><?php echo($request->project_title ? $request->project_title : 'NULL'); ?></li>
            <li><?php echo($request->priority ? $request->priority : '1'); ?></li>
            <li><?php echo($request->requester ? $request->requester : 'NULL'); ?></li>
            <li><?php echo($request->timestamp_created ? : 'NULL'); ?></li>
            <li><?php echo($request->status ? $request->status : 'NULL'); ?></li>
            <li><?php echo($request->due_date ? $request->due_date : 'TBD'); ?></li>          
            <li><?php echo($request->item_no ? $request->item_no : 'NULL'); ?></li>
            <li><?php echo($request->style_no ? $request->style_no : 'NULL'); ?></li>
            <li><?php echo($request->brand ? $request->brand : 'NULL'); ?></li>
            <li><?php echo($request->angle ? $globals->angles : 'NULL'); ?></li>
            <li><?php echo($request->type ? $request->type : 'NULL'); ?></li>
            <li><?php echo($request->customer ? $request->customer : 'NULL'); ?></li>
            <li><?php echo($request->file_type ? $request->file_type : 'NULL'); ?></li>
            <li><?php 
                    $fileSize = $request->file_width . 'px (w) by ' . $request->file_height . 'px (h)';
                    echo($request->file_width ? $fileSize : 'NA'); ?></li>
            <li><?php echo($request->photographer ? $request->photographer : 'NULL'); ?></li>
            <li><?php echo($request->shoot_date ? $request->shoot_date : 'NULL'); ?></li>
            <li><?php echo($request->email_alerts ? $request->email_alerts : 'NULL'); ?></li>
            <li><?php echo($request->notes ? $request->notes : 'NULL'); ?></li>
            <li><?php echo($request->batch_no ? $request->batch_no : 'NULL'); ?></li>
          </ul>
        </div> 
          
        <div class=clear></div> <br>
        
        <?php echo(Form::open('new_request/add_to_batch','post', array('class' => ''))); ?>
        Are you batching together requests under one project? (#<?php echo($request->batch_no); ?>)
        <br>If so, click Continue. Otherwise, click Finished.<br><br>
        <div class=floatLeft>
        <?php echo(Form::submit('Continue Batching')); ?>
        <?php echo(Form::close()); ?>                            
        </div>

        <?php echo(Form::open('new_request/no_batch','post', array('class' => ''))); ?>
        <?php echo(Form::submit('Finished')); ?>
        <?php echo(Form::close()); ?>                            

      
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>