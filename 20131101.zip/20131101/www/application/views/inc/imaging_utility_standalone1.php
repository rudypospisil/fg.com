<?php echo(Form::open('/imaging_utility/choose_apps')); ?>

  <div id=namingFormula style="float: left;">
    <?php echo(Form::label('namingFormula', 'SELECT THE APPLICATION USAGES FOR YOUR IMAGE')); ?>

    <div id=progressArrows class=step1>
      <p>Step 1.</p>
    </div>

    <?php 
      for($i = 0; $i < count($appSpecs); $i++)
      {
        // Echo checkbox. The group 'name' is 'apps'. Values are the individual application names.
        echo(Form::checkbox('apps[]', $appSpecs[$i]->application));
        
        // echo name.
        echo('&nbsp;' . $appSpecs[$i]->application . "\n");
          
        echo('<br>');
      }
    ?>
  </div><!--namingFormula-->
      
  <br>   

  <div style="clear: both;"></div>
  <br>   
    <?php
      echo(Form::submit('NEXT'));
      echo Form::close();
    ?>
  <br><br>