<?php
/**
 * Masthead include.
 * This view creates the primary navigation.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
        <?php $memberof = Login::get_userMemberof(); ?>
        
        <!-- This block is for debugging purposes only. -->
        <?php
          // When pulling out this debug block, remember to use the $memberof variable for privileges.
          //$member = Session::has('privileges') ? Session::get('privileges') : 'admin';
          //Session::put('privileges', $member);
        ?> 
        <div style="position: absolute; right: 10px;">
          Debug ->&nbsp;&nbsp; 
          <a 
          <?php echo($memberof == 'admin' ? 'class="bold red" ' : ''); ?>
          href="/debug/changePrivileges?memberof=a">A</a>&nbsp;&nbsp;
          <a 
          <?php echo($memberof == 'manager' ? 'class="bold red" ' : ''); ?>
          href="/debug/changePrivileges?memberof=m">M</a>&nbsp;&nbsp;
          <a 
          <?php echo($memberof == 'contributor' ? 'class="bold red" ' : ''); ?>
          href="/debug/changePrivileges?memberof=c">C</a>&nbsp;&nbsp;
          <a 
          <?php echo($memberof == 'photographer' ? 'class="bold red" ' : ''); ?>
          href="/debug/changePrivileges?memberof=p">P</a>&nbsp;&nbsp;
        </div>
        <!-- This block is for debugging purposes only. -->

    <div id=masthead>
      <div class=logo>
        <a href="/">
          <img src="/img/logo_FGoldmanSig60Lockup.png" width=350 />
        </a>
      </div>
      <div class=nav>
        <p>Hello, 
        <?php echo Login::get_userName();
            
          echo(' (' . ucfirst($memberof) . ')');

          if($memberof == 'admin' || $memberof == 'manager')
          {
            echo(' / <a href="/admin"'
              . ($section == 'Admin Panel' ? ' class="bold red">' : '>')
              . 'Admin Panel</a>');
          }
          ?>
        / <a href="/login/logout">Logout</a></p><br>
        
        
        <ul>
          <?php 
            // Bring in the menu array. (Changing menus items done in this file.)
            $primaryNav = Config::get('primary_nav');
            
            // Get count of menu items for looping purposes.
            $count = count($primaryNav);
            
            // Build navigation.
            for($i = 0; $i < $count; $i++)
            {            
              // Begin HTML.
              echo('<li><a');
              
              // Provide visual feedback for current page.
              if($primaryNav[$i] == $section) { echo(' class=current'); }
              
              // Echo URL.
              // echo ' href="/' . $primaryNav[$i]->url . '">');
              echo(' href="/' . str_replace(' ', '_', strtolower($primaryNav[$i])) . '">');
                             
              // Print menu item.
              if($primaryNav[$i] == 'Completed Requests')
              {
                echo('Completed');
              }   
              else
              {          
                echo($primaryNav[$i]);
              }
              // echo $primaryNav[$i]->menuTitle;
              
              // Close HTML block.
              echo('</a></li>');
              
              // Insert a pipe between menu items. No pipe after last item.
              if($i < ($count - 1))
              {
                echo('<li class=pipePad> | </li>' . "\n");
              }
            }
          ?>
        </ul>      
      </div>
    </div>
    <div id=headerHr>&nbsp;</div>