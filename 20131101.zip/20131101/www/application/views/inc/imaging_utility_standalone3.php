<?php echo(Form::open_for_files('/imaging_utility/upload_standalone')); ?>

  <div id=uploaderStandalone style="float: left;">
    <?php echo(Form::label('uploadFile', 'UPLOAD YOUR FILE FOR ' . $pisFileName)); ?>

    <div id=progressArrows class=step3>
      <p>Step 3.</p>
    </div>
    
      <input type="hidden" id="MAX_FILE_SIZE" name="MAX_FILE_SIZE" value="300000000" />
      <?php echo(Form::hidden('TEST_pisFileName', $pisFileName) . "\n"); ?>            

      <div>
        <?php echo(Form::label('image', 'File to upload (only one allowed):')); ?>
      	<?php echo(Form::file('image',array('id'=> 'image_id'))); ?>
      </div>
      
      <br>
      
      <div id=defaultStyle>
          <?php echo(Form::label('defaultStyle', 'DEFAULT FOR STYLE')); ?>
          <br>
          <?php echo(Form::radio("defaultStyle", 'Yes')); ?>Yes
          <?php echo(Form::radio("defaultStyle", 'No', true)); ?>No
      </div>
      
  </div><!--uploaderStandalone-->

  <div style="clear: both;"></div>

  <br><br>   
    
    <?php
      echo(Form::submit('UPLOAD'));
      echo Form::close();
    ?>

  <br><br>