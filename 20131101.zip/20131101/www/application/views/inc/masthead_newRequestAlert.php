<?php
/**
 * Masthead include.
 * This view creates the primary navigation.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
        <?php
          $memberof = Session::get('ldap_memberof');
        ?>
        <!-- This block is for debugging purposes only. -->
        <?php
          // When pulling out this debug block, remember to use the $memberof variable for privileges.
          //$member = Session::has('privileges') ? Session::get('privileges') : 'admin';
          //Session::put('privileges', $member);
        ?> 
        <div style="position: absolute; right: 10px;">
          Debug ->&nbsp;&nbsp; 
          <a 
          <?php echo($memberof == 'admin' ? 'class=bold ' : ''); ?>
          href="/debug/changePrivileges?memberof=a">A</a>&nbsp;&nbsp;
          <a 
          <?php echo($memberof == 'manager' ? 'class=bold ' : ''); ?>
          href="/debug/changePrivileges?memberof=m">M</a>&nbsp;&nbsp;
          <a 
          <?php echo($memberof == 'contributor' ? 'class=bold ' : ''); ?>
          href="/debug/changePrivileges?memberof=c">C</a>&nbsp;&nbsp;
          <a 
          <?php echo($memberof == 'photographer' ? 'class=bold ' : ''); ?>
          href="/debug/changePrivileges?memberof=p">P</a>&nbsp;&nbsp;
        </div>
        <!-- This block is for debugging purposes only. -->

    <div id=masthead>
      <div class=logo>
        <a href="/">
          <img src="/img/logo_FGoldmanSig60Lockup.png" width=350 />
        </a>
      </div>
      <div class=nav>
        <p>Hello, 
        <?php 
          // If valid user, echo their username.
          echo(Session::has('ldap_cn') && Session::get('ldap_cn') != false
            ? Session::get('ldap_cn')
            : 'Unknown'); // Note to self: Change false to redirect to login page. This is just yet another error check. 3rd redundant.
            
          echo(' (' . ucfirst($memberof) . ')');

          if($memberof == 'admin')
          {
            echo(' / <a href="/admin"'
              . ($section == 'Admin Panel' ? ' class=bold>' : '>')
              . 'Admin Panel</a>');
          }
          ?>
        / <a href="/login/logout">Logout</a></p><br>
        
        
        <ul>
          <?php 
            // Bring in the menu array. (Changing menus items done in this file.)
            $primaryNav = Config::get('primary_nav');
            
            // Get count of menu items for looping purposes.
            $count = count($primaryNav);
            
            // Build navigation.
            for($i = 0; $i < $count; $i++)
            {            
              // Begin HTML.
              if($primaryNav[$i] == 'New Request')
              {
                echo('<li><a onmousedown="newRequestAlert();"');
              }   
              else
              {          
                echo('<li><a');
              }
              
              // Provide visual feedback for current page.
              if($primaryNav[$i] == $section) { echo(' class=current'); }
              
              // Print URL.
              if($primaryNav[$i] == 'New Request')
              {
                echo('>');
              }   
              else
              {          
                echo(' href="/' . str_replace(' ', '_', strtolower($primaryNav[$i])) . '">');
              }
              
              
              // Print menu item.
              if($primaryNav[$i] == 'Completed Requests')
              {
                echo('Completed');
              }   
              else
              {          
                echo($primaryNav[$i]);
              }
              
              // Close HTML block.
              echo('</a></li>');
              
              // Insert a pipe between menu items. No pipe after last item.
              if($i < ($count - 1))
              {
                echo('<li class=pipePad> | </li>' . "\n");
              }
            }
          ?>
        </ul>      
      </div>
    </div>
    <div id=headerHr>&nbsp;</div>