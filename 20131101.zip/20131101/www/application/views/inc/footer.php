<?php
/**
 * Footer include.
 * This view creates the footer legalese.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
  <br>
  <div id=footerWrapper>
    <div id=footer>
      <br>
      <!-- <div id=footerHr>&nbsp;</div> -->
      <p id=legalese>© Frederick Goldman, <script type="text/javascript">document.write(new Date().getFullYear());</script>. All rights reserved.</p><br>   
    </div><!-- #footer --> 
  </div><!-- #footerWrapper --> 
</body>
<!--
 * © Frederick Goldman, 2013
 * Rudy Pospisil, NY, NY
 * rudy@rudypospisil.com, http://rudypospisil.com/
-->
</html>
 
