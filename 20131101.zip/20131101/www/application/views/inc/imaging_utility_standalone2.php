<?php echo(Form::open('/imaging_utility/set_formulas')); ?>

  <div id=namingFormula style="float: left;">
  
    <?php echo(Form::label('namingFormula', 'FILE NAMING FORMULAS')); ?>

    <div id=progressArrows class=step2>
      <p>Step 2.</p>
    </div>
    
    <table>
    <?php 
      // Start with an outer loop of an array of only the user selected applications.
      for($i = 0; $i < count($userApps); $i++)
      {
        // Now loop through a second array containing all of the applications in the db.
        foreach($appSpecs as $singleAppSpecs)
        {
          // Is the user checked box equal to a application name in the db?
          if($userApps[$i] == $singleAppSpecs->application)
          {
            // Echo the application title.
            echo('<tr>');
            echo('<td>' . $singleAppSpecs->application . '</td>');              
            echo('</tr>' . "\n");
            
           // Now, echo the input boxes.
            echo('<tr>');             
            for($k = 0; $k < count($singleAppSpecs->namingFormulaArray); $k++)
            {
              // Echo the inputs on the line below.
              // Echo the hyphens as text only, not input boxes.
              echo('<td>');
              if($singleAppSpecs->namingFormulaArray[$k] == '-')
              {
                echo('&nbsp;' . $singleAppSpecs->namingFormulaArray[$k] . '&nbsp;');
              }
              else
              {
                echo(Form::text($singleAppSpecs->application . '_' . $singleAppSpecs->namingFormulaArray[$k], '', array('placeholder' => $singleAppSpecs->namingFormulaArray[$k])));
              }
              echo('</td>');                         
            }                              
            echo('</tr>' . "\n");
          }
        }          
      }
    ?>
  </table>
  </div><!--namingFormula-->

  <div style="clear: both;"></div>

  <br><br>   
    
    <?php
      echo(Form::submit('NEXT'));
      echo Form::close();
    ?>

  <br><br>