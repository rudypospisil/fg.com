<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo($title); ?></title>
<?php 
  // Load in css and javascript.
  echo(Asset::styles());
  echo(Asset::scripts());
?>
</head>
