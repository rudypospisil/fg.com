<p>SUCCESS!</p><br> 

<?php echo($pisFileName . ' (originally: ' . Input::file('image.name') . ")\n");?>
<br><img src="/filestore/thumbnails/150px/<?php echo($thumbnailName150px); ?>" />
<br><br>
<?php 
  echo(Form::open('/imaging_utility/continue')); 
  echo(Form::submit('CONTINUE'));
  echo Form::close();    
?>
<br><br>