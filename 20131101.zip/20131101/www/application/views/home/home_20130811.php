<?php
/**
 * Home view.
 * This view shows the table of contents for logged in users.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>

<?php Loader::load('head', $title); ?>

<body id=background>

    <div id=backplate>

    <div id=tocWrapper>    
      <br><br>
      <div class=centerMe><img src="/img/logo_FGoldmanSig60Lockup.png" width=375 /></div><br>
      
      <div id=toc>
        <p><b>Hello, 
        <?php 
          // If valid user, echo their username.
          echo(((Session::get('ldap_cn') != false) && Session::has('ldap_cn'))
            ? Session::get('ldap_cn')
            : '');
          ?>
          </b>
          <br>Welcome to PIS.</p><br>

        <ul>
          <?php
            // Build the table of contents according to the user's privileges.
            $memberof = Login::get_userMemberof();
                       
            switch($memberof)
            {
              case 'admin':
                echo('<li>&bull;&nbsp;<a href="new_request">Create New Request</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="open_requests">View Open Requests</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="completed_requests">View Completed Requests</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="library">Asset Library</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="imaging_utility">Imaging Utility</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="admin">Admin Panel</a></li>' . "\n");              
                echo('<li>&bull;&nbsp;<a href="login/logout">Logout</a></li>' . "\n");
                break;
              case 'manager':
                echo('<li>&bull;&nbsp;<a href="new_request">Create New Request</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="open_requests">View Open Requests</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="completed_requests">View Completed Requests</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="library">Asset Library</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="imaging_utility">Imaging Utility</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="admin">Admin Panel</a></li>' . "\n");              
                echo('<li>&bull;&nbsp;<a href="login/logout">Logout</a></li>' . "\n");
                break;
              case 'contributor':
                echo('<li>&bull;&nbsp;<a href="new_request">Create New Request</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="open_requests">View Open Requests</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="completed_requests">View Completed Requests</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="library">Asset Library</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="login/logout">Logout</a></li>' . "\n");
                break;
              case false:
              default:
                echo('<li>&bull;&nbsp;<a href="/open_requests">View Open Requests</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="/library">Asset Library</a></li>' . "\n");
                echo('<li>&bull;&nbsp;<a href="/login/logout">Logout</a></li>' . "\n");
                break;
            }
            ?>          
        </ul>
        
      </div><!--#tocWrapper-->
      
    </div><!--#backplate-->

    </div><!--#background-->
    
</body>
</html>