<?php require_once('/var/www/application/views/inc/head.php'); ?>

<body id=background>

  <div id=mainWrapper>

    <div id=backplate>

    <div id=loginWrapper>    
      <br><br>
      <div class=centerMe><img src="/img/logo_FGoldmanSig60Lockup.png" width=375 /></div><br>
      
      <div id=loginForm>
      
      <?php echo(Form::open('login/checkLogin','post',array('class' => 'centerMe'))); ?>
      
      <?php echo(Form::label('username', 'Username')); ?><span style="font-size: 12px;">&nbsp;(First Initial, Last Name)</span>
      <br>
      <?php echo(Form::text('username',
                            '', 
                            array('size'       => '28',
                                  'placeholder' => 'Your FG login',
                                  'required'    => 'required'
                            ))); ?>
      <br><br>
      <?php echo(Form::label('password', 'Password')); ?>
      <br>      
      <?php echo(Form::password('password',
                            array('size'       => '28',
                                  'placeholder' => 'Your password',
                                  'required'    => 'required'
                            ))); ?>
      <br><br>
      <?php echo(Form::submit('Login')); ?>
      
      <?php echo(Session::has('loginError')
              ? '<br><br><p id=loginError>INVALID LOGIN</p>'
              :''
              ); 
      ?>
      
      <?php echo(Form::close()); ?>                            
      
      </div>
      
    </div>
    
    </div>
    
    <script type="text/javascript">document.getElementById('username').focus();</script>
    
  </body></html>