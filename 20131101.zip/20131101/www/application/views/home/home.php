<?php
/**
 * Home view.
 * This view shows the table of contents for logged in users.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>

<?php Loader::load('head', $title); ?>

<body id=background>

    <div id=backplate>

    <div id=tocWrapper>    
      <br><br>
      <div class=centerMe><img src="/img/logo_FGoldmanSig60Lockup.png" width=375 /></div><br>
      
      <div id=toc>
        <p><b>Hello, <?php echo Login::get_userName(); ?></b>
          <br>Welcome to PIS.</p><br>

        <ul>
        
        <?php Config::get('landing_nav'); ?>
        
        </ul>
        
      </div><!--#tocWrapper-->
      
    </div><!--#backplate-->

    </div><!--#background-->
    
</body>
</html>