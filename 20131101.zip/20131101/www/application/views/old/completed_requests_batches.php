<?php
/**
 * Open Requests view.
 * This view shows the current open requests in the system lumped together as batches.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <br>
      <div id=content>
      
        <div id=contentInner>

        <?php $sort = Input::has('sort') ? Input::get('sort') : 'batch_no'; ?>
        
        <div id=header>
          <h3>CURRENT OPEN REQUESTS - Batches View</h3>
          <p>View as: <a href="/index.php/open_requests?view=singles">Singles</a> | Batches</p>
        </div>
        

        <table id=openRequests>
        <tr>
          <th style="width: 50px;">Batch&nbsp;ID</th>
          <th>Requester</th>
          <th>Due&nbsp;Date</th>
          <th>Status</th>
          <th>Type</th>
          <th>Customer</th>
          <th>Photographer</th>
          <th>Shoot&nbsp;Date</th>
        </tr>

        <script>
          $(document).ready(function(){
            $('.perro').click(function(){
              $('.test').css('background-color', '');
            })
          });

        </script>  
          
        
          <?php

            // $request is the database object containing the entire SELECT.
            $i = 0;

            $parentCount = count($request);
            
            for($i = 0; $i < $parentCount; $i++)
            {
              $childCount = count($request[$i]);
                echo('<div>');
                $k = $i + 1;  
                echo('<span id=' . $k . '>Batch #' . $request[$i][0]->batch_no . '</span><br>');
                for($j = 0; $j < $childCount; $j++)
                {
                  echo('<span class=' . $k . '> -' . $request[$i][$j]->item_no . '</span><br>');
                }
                echo('</div>');              
              echo('<br>');
              
            }
          ?>
          <script>
          
          </script>
          
          
          
          </table>
          
        </div><!--contentInner-->

      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  

  <?php require_once('/var/www/application/views/inc/footer.php'); ?>