<?php
/**
 * Open Requests view.
 * This view shows the current open requests in the system.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <br>
      <div id=content>
      
        <div id=contentInner>
        <h3>LIBRARY</h3>
        
          <?php $files = DB::table('filestore')->order_by('pis_file_name', 'asc')->get(); ?>

          <?php
            foreach($files as $file)
            { 
          ?>  
          <div class=thumbWrapper>
            <a href="/index.php/library/product_detail?id=<?php echo($file->id); ?>">
              <div class=thumbBox>
                <?php echo('<img id=' . $file->id . ' src="/filestore/thumbnails/150px/' . $file->pis_file_name . '_150px_tb.jpg" width=150 height=150 />'); ?>
              </div>
              <p><?php echo($file->pis_file_name); ?></p>
            </a>
          </div>
            <?php
            }
            ?>
        </div><!--contentInner-->

      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>