<?php
/**
 * Open Requests view.
 * This view shows the current open requests in the system.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<script>
 $(function() {
   $( "#tabs" ).tabs();
 });
</script>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <br>
      <div id=content>
      
        <div id=contentInner>

        <?php $sort = Input::has('sort') ? Input::get('sort') : 'batch_no'; ?>
        
        <div id=header>
          <h3>CURRENT OPEN REQUESTS — Singles View</h3>

          <p>View as: Singles | <a href="/open_requests?view=batches">Projects</a></p>
          <div id=paginationOpenRequests>
            <?php echo(Form::hidden('page', $page)); ?>
            <?php echo(Form::hidden('sort', $sort, array('id' => 'sort'))); ?>
            <p>
              <?php echo($startNumber); ?>-<?php echo($all == false ? $endNumber : $totalCount); ?>&nbsp;of&nbsp;
              <?php echo($totalCount); ?>&nbsp;rows
              &nbsp;&nbsp;<a href="/open_requests?p=<?php echo($prevPage); ?>&sort=<?php echo($sort); ?>"> < </a>
              &nbsp;&nbsp;<a href="/open_requests?p=<?php echo($nextPage); ?>&sort=<?php echo($sort); ?>"> > </a>
              &nbsp;&nbsp;<?php echo($all == false ? ('<a href="/open_requests?all=true&sort=' . $sort . '">ALL</a>') : 'ALL'); ?>
              &nbsp;&nbsp;Page: <?php echo(Form::select('pageJump', $pageArray, $page)); ?>
            </p>
          </div>
        </div>
        

        <table id=openRequests>
        <tr>
          <th <?php if($sort == 'batch_no') { echo(' class=selected '); } ?> style="width: 50px;">
            <a <?php if($sort == 'batch_no') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=batch_no">Batch&nbsp;#</a></th>
            
          <th <?php if($sort == 'project_title') { echo(' class=selected '); } ?> style="width: 160px;">
            <a <?php if($sort == 'project_title') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=project_title">Project Title</a></th>

          <th <?php if($sort == 'priority') { echo(' class=selected '); } ?> style="width: 50px;">
            <a <?php if($sort == 'priority') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=priority">Priority</a></th>

          <th <?php if($sort == 'item_no') { echo(' class=selected '); } ?> style="width: 144px;">
            <a <?php if($sort == 'item_no') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=item_no">Item&nbsp;#</a></th>
            
          <th <?php if($sort == 'style_no') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'style_no') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=style_no">Style&nbsp;#</a></th>
            
          <th <?php if($sort == 'brand') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'brand') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=brand">Brand</a></th>
            
          <th<?php if($sort == 'angle') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'angle') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=angle">Angle</a></th>
            
          <th <?php if($sort == 'requester') { echo(' class=selected '); } ?> style="width: 140px;">
            <a <?php if($sort == 'requester') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=requester">Requester</a></th>
            
          <th <?php if($sort == 'timestamp_created') { echo(' class=selected '); } ?> style="width: 50px;">
            <a <?php if($sort == 'timestamp_created') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=timestamp_created">Submitted</a></th>
            
          <th <?php if($sort == 'due_date') { echo(' class=selected '); } ?> style="width: 50px;">
            <a <?php if($sort == 'due_date') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=due_date">Due&nbsp;Date</a></th>
            
          <th <?php if($sort == 'status') { echo(' class=selected '); } ?> style="width: 150px;">
            <a <?php if($sort == 'status') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=status">Status</a></th>
            
          <th <?php if($sort == 'type') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'type') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=type">Type</a></th>
            
          <th <?php if($sort == 'customer') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'customer') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=customer">Customer</a></th>
          
          <th <?php if($sort == 'photographer') { echo(' class=selected '); } ?> style="width: 80px;">
            <a <?php if($sort == 'photographer') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=photographer">Photog</a></th>
            
          <th <?php if($sort == 'shoot_date') { echo(' class=selected '); } ?> style="width: 50px;">
            <a <?php if($sort == 'shoot_date') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=shoot_date">Shoot&nbsp;Date</a></th>
        </tr>
        
          <?php

            $highlight[0] = 'highlightGreen';
            $highlight[1] = 'highlightIndigo';
            $i = 0;
            $num = 0;

            $count = count($requests);
            
            // $requests is the database object containing the entire SELECT.
            for($i = 0; $i < $count; $i++)
            {
              
              // Get the primary key to use as as ID for each row.
              $id = $requests[$i]->id;

              if($i > 0)
              {
                $j = $i - 1;
              }
              else
              {
                $j = 0;
              }
              if($requests[$i]->batch_no != $requests[$j]->batch_no)
              {
                $num++;
                $num = $num % 2;
              }              


              echo('<tr id=' . $id . ' class="' . $highlight[$num] . ' selectable">');                
              echo('<td>');
              echo($requests[$i]->batch_no
                    . '</td><td>'
                    . substr($requests[$i]->project_title, 0, 9) . '...'
                    . '</td><td>'
                    . $requests[$i]->priority
                    . '</td><td>'
                    . $requests[$i]->item_no
                    . '</td><td>'
                    . $requests[$i]->style_no
                    . '</td><td>'
                    . $requests[$i]->brand
                    . '</td><td>'
                    . $requests[$i]->angle
                    . '</td><td>'
                    . substr($requests[$i]->requester, 0, 9) . '...'
                    . '</td><td>'
                    . date('m/d/y', strtotime($requests[$i]->timestamp_created))
                    . '</td><td>'
                    . date('m/d/y', strtotime($requests[$i]->due_date))
                    . '</td><td>'
                    . $requests[$i]->status
                    . '</td><td>'
                    . $requests[$i]->type
                    . '</td><td>'
                    . $requests[$i]->customer
                    . '</td><td>'
                    . substr($requests[$i]->photographer, 0, 9) . '...'
                    . '</td><td>'
                    . $requests[$i]->shoot_date);
              echo('</td>');
              // Output the edit/view link using the primary key.
              echo('<td style="width: 30px;"><a style="text-decoration: underline; color: blue;" href="/open_requests/edit?id=' . $id . '">edit</a>
              </td>');
              echo('</tr>' . "\n");
              
            }
          ?>
          </table>
          
        </div><!--contentInner-->

      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->

<!--  
  <div id="input-menus" class="inline-spaces">
        <div class="context-menu-three box menu-1" 
          data-yesno0="true" 
          data-yesno2="true" 
        <strong>right click to filter</strong>
      </div>
  </div>
  
<uul></uul>
-->
<script>
$(document).ready(function() {
    // Sorting and pagination function.
    sort = $('#sort').val();
      
    $(".selectable").click(function(e) {
        path = '/open_requests/edit?id=';
        window.location.href = path + $(this).attr('id');
    });
  
    $('select[name=pageJump]').change(function(e)
    {
      path = '/open_requests?p=';
      window.location.href = path + $(':selected',this).attr("value") + '&sort=' + sort;      
    });
    
    $.getJSON('/open_requests_test/group_by/angle', function(data){
      $.each(data, function(key, value){
        $('uul').append('<li>' + value + '</li>');
      });
    });
});
</script>    
    <script type="text/javascript">
        $(function(){
            /**************************************************
             * Menu Input
             **************************************************/
            $.contextMenu({
                selector: '.context-menu-three', 
                items: {
                    yesno0: {name: "Brand", type:'checkbox', value:""},
                    sep1: "---------",
                    yesno1: {name: "Batch ID", type:'checkbox', selected:true},
                    yesno2: {name: "Item No", type:'checkbox', selected:true},
                    yesno3: {name: "Style No", type:'checkbox', selected:true},
                    yesno4: {name: "Requester", type:'checkbox', selected:true},
                    yesno5: {name: "Due Date", type:'checkbox', selected:true},
                    sep2: "---------",
                    key: {name: "Click to Filter", callback: function(e){alert($(".context-menu-three").data('yesno0'))}}
                }, 
                events: {
                    show: function(opt) {
                        var $this = this;
                        // import states from data store
                        $.contextMenu.setInputValues(opt, $this.data());
                    }, 
                    hide: function(opt) {
                        var $this = this;
                        // export states to data store
                        $.contextMenu.getInputValues(opt, $this.data());
                        alert($(".context-menu-three").data('yesno0'));
                    }
                }
            });
        });
    </script>
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>