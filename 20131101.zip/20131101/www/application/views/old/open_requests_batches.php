<?php
/**
 * Open Requests view.
 * This view shows the current open requests in the system lumped together as batches.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <?php $sort = Input::has('sort') ? Input::get('sort') : 'batch_no'; ?>
  
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <br>
      <div id=content>
      
        <div id=contentInner>

        <?php 
          // Grab the sort parameter from the query string.
          $sort = Input::has('sort') ? Input::get('sort') : 'batch_no'; 
        ?>
        
        <div id=openRequestBatches>
        <div id=header>
          <h3>CURRENT OPEN REQUESTS - Project View</h3>
          <br><br>
          <p id=sortMenu>Sort by: 
          <?php 
            echo($sort != 'batch_no') 
              ? '<a href="/open_requests?view=batches&sort=batch_no">Batch #</a>'
              : 'Batch #';
            echo(' / ');
            echo($sort != 'project_title') 
              ? '<a href="/open_requests?view=batches&sort=project_title">Project Title</a>'
              : 'Project Title';
          ?>          
          <p>View as: <a href="/open_requests?view=singles">Singles</a> | Projects</p>
          <br>
        </div>
        

<script>
$(document).ready(function() {
  $('.collapsible').collapsible();
  //$( ".collapsible" ).accordion({ collapsible: true });
  //$('#parent4').collapsible('expand');      

  $(".selectable").click(function(e) {
      path = '/open_requests/edit?id=';
      window.location.href = path + $(this).attr('id');
  });
});

$(function() {
  $('.batchDueDate').datepicker();
});
</script>    

          <?php

            // $request is the database object containing the entire SELECT.
            $i = 0;

            // Set the number of total parents.
            $parentCount = count($request);
            
            
            // Now, echo out the data.
            echo('<br>' . "\n");
            
            // Outer loop. This loops through all of the parents.              
            for($i = 0; $i < $parentCount; $i++)
            {
              $childCount = count($request[$i]);
              
              echo("\n" . '<div class=batch>' . "\n");
              
              $k = $i + 1; 
               
              echo('<ul id=parent' . $k . ' class="parent collapsible" data-collapsed="true">' . "\n");
              
              // Set headline for the parent.
              //echo('<script>$(function(){ $("#parent' . $request[$i][0]->batch_no . '").collapsible();</script>');
              
              echo('<li>Batch #' 
                    . $request[$i][0]->batch_no 
                    . ' / Project Title: ' 
                    . $request[$i][0]->project_title 
                    . "\n");
              echo('<br><br>' . "\n");              
              echo('<ul>' . "\n");
              
              echo('<table>');
              
              // Set the column headers for the parent.
              echo('<tr style="background-color: #666; color: #fff;">
                    <td>Item</td>
                    <td>Angle</td>
                    <td>Status</td>
                    <td>Due Date</td>
                    <td>Photographer</td>
                    <td>Shoot Date</td>
                    <td>Requester</td>
                    </tr>');
              
              // Inner loop. This loops through all of the children within each parent.           
              for($j = 0; $j < $childCount; $j++)
              {
                echo('<tr id=' . $request[$i][$j]->id . ' class=selectable>');
                echo('<td><li class=child' . $k . '>' 
                  . $request[$i][$j]->item_no
                  . '</li></td>'
                  . '<td>' . $request[$i][$j]->angle . '</td>' . "\n"
                  . '<td>' . $request[$i][$j]->status . '</td>' . "\n"
                  . '<td>' . $request[$i][$j]->due_date . '</td>' . "\n"
                  . '<td>' . $request[$i][$j]->photographer . '</td>' . "\n"
                  . '<td>' . $request[$i][$j]->shoot_date . '</td>' . "\n"
                  . '<td>' . $request[$i][$j]->requester . '</td>' . "\n"
                  . '</tr>'
                  . "\n");
              }
              echo('</table>');
              echo('<br><a href="/open_requests/">Add to Batch</a>');           
              echo('&nbsp;&nbsp;&nbsp;&nbsp;');           
              echo('<a href="/open_requests/">Delete Batch</a><br><br>');
                         
              echo(Form::open('open_requests/change_batch_due_date/' . $request[$i][0]->batch_no, 'post'));
              echo(Form::label('batchDueDate_' . $request[$i][0]->batch_no, 'Change Batch Due Date '));
              echo(Form::text('batchDueDate_' . $request[$i][0]->batch_no, '', array('class' => 'batchDueDate', 'placeholder' => 'Select New Date')));
              echo(Form::submit('Update'));     
              echo('<br><br><br>' . "\n");              
              echo(Form::close());   
              
              echo('</ul>' . "\n");              
              echo('</li>' . "\n");
              echo('</div>' . "\n");              
              echo('<br>' . "\n");              
            }
          ?>

        </div><!--#openRequestBatches-->
          
        </div><!--#contentInner-->

      </div><!--#content-->
   
    </div><!--#inner-->
    
  </div><!--#outer-->
  

  <?php require_once('/var/www/application/views/inc/footer.php'); ?>