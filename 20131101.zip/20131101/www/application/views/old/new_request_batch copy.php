<?php
/**
 * New Request view - adding to a batch.
 * This view builds the new request form.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<script>
$(function() {
  $("#dueDatePicker").datepicker();
  $("#shootDatePicker").datepicker();
});

$(document).ready(function(){
  $('#cusReqMore').hide();
  
  $('#prototype').click(function(){
    $('#cusReqMore').hide()
  });
    
  $('#production').click(function(){
    $('#cusReqMore').hide()
  });
    
  $('#cusreq').click(function(){
    $('#cusReqMore').show();  
  });  
});

 $(function() {
   $( "#tabs" ).tabs({ active: 0 });
 });  
</script>
<!-- I put the following in script blocks for ease of removal. (trying to be modular) -->
<script>
  url = '/new_request/getItemListForAjax/0';
  $.getJSON(url, function(data){
    var output = '';
    for(i = 0; i < data.length; i++)
    {
      output += '<input id="' + data[i].item_no + '" class=' + i + ' type=radio name=item value=' 
        + data[i].item_no + '>' 
        + data[i].item_no + '&nbsp;&nbsp;&nbsp;' + data[i].style_no 
        + '</input></br>';
    }
    $('#output').html(output);
  });
</script>


<script>
var skip = 100;
$('#itemList').scroll(function(){
  url = '/new_request/getItemListForAjax/' + skip;
  $.getJSON(url, function(data){
    var output = '';
    for(i = 0; i < data.length; i++)
    {
      output += '<input id="' + data[i].item_no + '" class=' + i + ' type=radio name=item value=' 
        + data[i].item_no + '>' 
        + data[i].item_no + '&nbsp;&nbsp;&nbsp;' + data[i].style_no 
        + '</input></br>';
    }
    $('#output').append(output);
    skip += 100;
  });
});
</script>
    <script type="text/javascript">  
        $(function(){                    
            //attach autocomplete  
            $("#itemSearch").autocomplete({  
                minLength: 2,          
                //define callback to format results  
                source: function(req, add){  
                          
                    //pass request to server  
                    $.getJSON("/new_request/getItemListForAutocomplete", req, function(data) {  
                                  
                        //create array for response objects  
                        var itemList = [];  
                                  
                        //process response  
                        for(i = 0; i < data.length; i++)
                        {
                          itemList.push(data[i].item_no);
                        }
                                  
                    //pass array to callback  
                    add(itemList);  
                    });  
                },
                select: function(event, ui){
                  $('#itemList').css({'display' : 'none'});
                  var id = ui.item.value;
                                    
                  $('input:radio[id="' + ui.item.value + '"]').attr('checked',true);
                  row = $('input:radio[id="' + ui.item.value + '"]').attr('class');
                },
                response: function(event, ui){
                  if(ui.item == null){
                    $('#itemList').css({'display' : 'block'});
                  }
                }                    
            }); 
          }); 
    </script>  
      
      


<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=content style="width: 95%; height: 680px;">
        
      <h3>BATCHING:<br>ADDING ANOTHER REQUEST</h3>
      
       <div id="tabs" style="height: 650px;">
          <ul>
            <li><a href="#tab-newRequest">Batch Request</a></li>
            <li><a href="#tab-photoStandards">Photography Standards</a></li>
          </ul>

          <div id="tab-newRequest">
            <div style="width: 960px; margin: 0 auto;">      
            <div style="float: left; margin: 0 30px;">
              <?php echo(Form::open('new_request/submit','post')); ?>
                <br>
                  <?php echo(Form::label('dueDate', 'DUE DATE')); ?>
                  <br>
                  <?php echo(Form::text('dueDate', $request->due_date, array('id' => 'dueDatePicker', 'placeholder' => 'Select Date', 'autofocus' => 'autofocus', 'style' => 'width:100px;'))); ?>
                  <br>
                <br>
                
                <div id=reqType>
                  <?php echo(Form::label('type', 'TYPE')); ?>
                  <br>
                  <?php echo(Form::radio('type', 'Prototype', ($request->type = 'Prototype' ? 'true' : 'false'), array('id' => 'prototype'))); ?>
                  <?php echo(Form::label('prototype', 'Prototype')); ?><br>
          
                  <?php echo(Form::radio('type', 'Production', ($request->type = 'Production' ? 'true' : 'false'), array('id' => 'production'))); ?>
                  <?php echo(Form::label('production', 'Production')); ?><br>
        
                  <div id=custumerRequest>
                    <?php echo(Form::radio('type', 'Customer Request', ($request->type = 'Customer Request' ? 'true' : 'false'), array('id' => 'cusreq'))); ?>
                    <?php echo(Form::label('cusreq', 'Customer Request')); ?><br>
                  </div>
                </div><!-- div#reqType -->
                
                <br>
                
                
                <div id=product>
                  <label>SELECT AN ITEM</label><br>
                  
                  <input id=itemSearch name=itemSearch placeholder="Scroll, or type in item number to search." />
                  
                  <fieldset>                  
                    <div id=itemList>
                      <table>
                        <tr><th>Available Items</th></tr> 

                        <tr><td><div id=output></div></td></tr>

                      </table>
                    </div><!-- div#itemList -->
                </div><!-- div#product -->
                
            </div>


            <div style="float: left; margin: 20px 0 0 0;">
            <div id=angles>
                <?php echo(Form::label('angles', 'ANGLES')); ?>
                <br>
                <?php echo(Form::checkbox("angles[]", '3Q')); ?>3Q
                <?php echo(Form::checkbox("angles[]", 'Flat')); ?>Flat
                <?php echo(Form::checkbox("angles[]", 'Front')); ?>Front
                <?php echo(Form::checkbox("angles[]", 'O')); ?>O
                <?php echo(Form::checkbox("angles[]", 'Top')); ?>Top
                <br>
                <?php echo(Form::label('angle', 'Other Angle?&nbsp;')); ?>
                <?php echo(Form::text('anglesOther')); ?>
            </div>
              <br>
      
              <div id=cusReqMore>
                <div id=cusReqMoreLeft>
                  <?php echo(Form::label('customer', 'Customer')); ?>
                  <br>
                  <?php echo(Form::label('filetype', 'File Type')); ?>
                  <br>
                  <?php echo(Form::label('size', 'Size')); ?>
                </div>
                <div id=cusReqMoreRight>
                  <?php echo(Form::select('customer', array('Zales' => 'Zales', 'Harmon' => 'Harmon', 'Goldman' => 'Goldman', 'Macys' => 'Macys'), $request->customer)); ?>
                  <br>
                  <?php echo(Form::select('filetype', array('matrix needed' => 'Matrix needed'), $request->file_type)); ?>
                  <br>
                  <?php echo(Form::select('size', array('matrix needed' => 'Matrix needed'), $request->size)); ?>
                </div> 
                <br><br>             
              </div>            
      
              <div>
                  <?php echo(Form::label('notes', 'NOTES')); ?>
                  <br>
                   <?php echo(Form::textarea('notes', $request->notes, array('rows' => 2, 'cols' => 35))); ?>
              </div>
              <br>
               
               <div>
                  <?php echo(Form::label('emailAlerts', "EMAIL ALERTS")); ?>
                  <br>
                  <span>(<i>separate multiple addresses with commas</i>)</span>
                  <br>
                  <?php echo(Form::textarea('emailAlerts', $request->email_alerts, array('rows' => 2, 'cols' => 30, 'placeholder' => 'name@domain.com,'))); ?>
              </div>
              <br>
              <?php echo(Form::submit('Submit')); ?>     
            <?php echo(Form::close()); ?>   
            </div><!--automargin-->
            </div>
          </div><!--tab-newRequest-->
          <br><br>
          
          <div id="tab-photoStandards">
            <ul>
              <li><a href="/filestore/specs/photographyStandards_2013_Zale_Corporation.pdf">Zales</a>, (PDF, 610K)</li>
            </ul>
          </div><!--tab-photoStandards-->

      </div><!--tabs-->
      
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  

  <?php require_once('/var/www/application/views/inc/footer.php'); ?>