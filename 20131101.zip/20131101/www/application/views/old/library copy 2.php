<?php
/**
 * Product Detail view.
 * This view shows each individual product page.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date May 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<script>
 $(function($) {   
   // Jump to the current tab in use.
   $("#tabs").tabs({ active: 0 });
 }); 
</script>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=adminContent>
              
      <h3>LIBRARY</h3>

        <div id="tabs">
          <ul>
            <li><a href="#tab-products">Products</a></li>
            <li><a href="#tab-product_details">Product Detail</a></li>
          </ul>
          
            <div id="tab-products">            

            <?php $files = DB::table('filestore')->order_by('pis_file_name', 'asc')->get(); ?>
  
            <?php
              foreach($files as $file)
              { 
            ?>  
            <div class=thumbWrapper>
              <a href="/index.php/library/product_detail?id=<?php echo($file->id); ?>">
                <div class=thumbBox>
                  <?php echo('<img id=' . $file->id . ' src="/filestore/thumbnails/150px/' . $file->pis_file_name . '_150px_tb.jpg" width=150 height=150 />'); ?>
                </div>
                <p><?php echo($file->pis_file_name); ?></p>
              </a>
            </div>
              <?php
              }
              ?>
              
            <div id="tab-product_details">            
              <div>                
                 <img src="/filestore/thumbnails/300px/<?php echo($fileDetails->pis_file_name); ?>_300px_tb.jpg"  style="float: left;" />
                 <?php 
                  if($fileDetails->pis_no != 0)
                  {
                    echo('File Name: ' . $fileDetails->pis_file_name . '<br>');
                    echo('Angle: ' . $productDetails->angle . '<br>');
                    echo('Type: ' . $productDetails->type . '<br>');
                    echo('Customer: ' . $productDetails->customer . '<br>');
                    echo('Originally Requested By: ' . $productDetails->requester . '<br>');
                    echo('Photographer: ' . $productDetails->photographer . '<br>');
                  }
                 ?>
                <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
              </div>                        
            </div><!--tab-product_details-->

        </div><!--tab-products-->
        </div><!--tabs-->
        
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
    
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>