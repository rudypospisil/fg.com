<?php
/**
 * New Request view - waiting for the NAV.
 * This view lets the user know to wait.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date June 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<script>
$(document).ready(function(){
  location.href = '/new_request';
});
</script>

<body id=background>

    <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=content>
        
        <h3>PLEASE WAIT WHILE THE NAV IS GATHERING THE ITEMS.</h3>
        <img src="/img/spinLoader.gif" />
       
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>

