<?php
/**
 * Edit Request view.
 * This view allows user to edit request.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=contentEditRequest>
        <h3>EDITING OPEN REQUEST — Contributer</h3>
        
        <div id=editRequest1>
          <table>
            <tr>
              <td>Requester: </td>
              <td><?php echo($request->requester); ?></td>
            </tr>
            <tr>
              <td>Submitted: </td>
              <td><?php echo($request->timestamp_created ? : ' '); ?></td>
            </tr>
            <tr>
              <td>Status: </td>
              <td><?php echo(Form::select('status', array('' => $statusDropdown), $request->status)); ?></td>
            </tr>
            <tr>
              <td>Due Date: </td>
              <td><?php echo($request->due_date); ?></td>
            </tr>
            <tr>
              <td>Item No: </td>
              <td><?php echo($request->item_no); ?></td>
            </tr>
            <tr>
              <td>Style No: </td>
              <td><?php echo($request->style_no); ?></td>
            </tr>
            <tr>
              <td>Brand: </td>
              <td><?php echo($request->brand); ?></td>
            </tr>
            <tr>
              <td>Angle - 3Q: </td>
              <td><?php echo($request->angle_3q); ?></td>
            </tr>
            <tr>
              <td>Angle - Flat: </td>
              <td><?php echo($request->angle_flat); ?></td>
            </tr>
            <tr>
              <td>Angle - Front: </td>
              <td><?php echo($request->angle_front); ?></td>
            </tr>
            <tr>
              <td>Angle - O: </td>
              <td><?php echo($request->angle_o); ?></td>
            </tr>
            <tr>
              <td>Angle - Top: </td>
              <td><?php echo($request->angle_top); ?></td>
            </tr>
          </table>
        </div>
            
        <div id=editRequest2>
          <table>
            <tr>
              <td>Type: </td>
              <td><?php echo($request->type); ?></td>
            </tr>
            <tr>
              <td>Customer: </td>
              <td><?php echo($request->customer); ?></td>
            </tr>
            <tr>
              <td>File Type: </td>
              <td><?php echo($request->file_type); ?></td>
            </tr>
            <tr>
              <td>Size: </td>
              <td><?php echo($request->size); ?></td>
            </tr>
            <tr>
              <td>Photographer: </td>
              <td><?php echo($request->photographer); ?></td>
            </tr>
            <tr>
              <td>Shoot Date: </td>
              <td><?php echo($request->shoot_date); ?></td>
            </tr>
            <tr>
              <td>Email Alerts: </td>
              <td><?php echo($request->email_alerts); ?></td>
            </tr>
            <tr>
              <td>Notes: </td>
              <td><?php echo($request->notes); ?></td>
            </tr>
            <tr>
              <td>Misc: </td>
              <td><?php echo($request->misc); ?></td>
            </tr>
            <tr>
              <td>Reference: </td>
              <td><?php echo($request->reference); ?></td>
            </tr>
            <tr>
              <td>Batch ID: </td>
              <td><?php echo($request->batch_no); ?></td>
            </tr>
          </table>
        </div>            
      
        <br><br>
        <div style="clear: both;"></div>
        
        <div id=alsoBatch>
          Members of this Batch:<br>
          <?php
            foreach($batchRequest as $row)
            {
              // Get the primary key to use as as ID for each row.
              $id = $row->id;
              if($id != Input::get('id'))
              {
                echo('<a style="text-decoration: underline; color: blue;" href="/index.php/open_requests/edit?id=' . $id . '">' . $row->item_no . '</a>');
              }
              else
              {
                echo($row->item_no . '&nbsp;&nbsp;');
              }
            }
          ?>
        </div>        
      
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>