<?php
/**
 * Imaging Utility view.
 * This view shows the imaging utility system.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<script>
 $(function($) {
   // Jump to the current tab in use.
   $("#tabs").tabs({ active: 2 });
 }); 
</script>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
    
      <div id=uploaderWrapper>        
        
      <h3>IMAGING UTILITY</h3>
      
       <div id="tabs">
          <ul>
            <li><a href="#tab-completedRequests">PIS</a></li>
            <li><a href="#tab-standalone">Standalone</a></li>
          </ul>
          
          <br>
            <div id="tab-completedRequests">            
              
              <form id="upload1" style="width: 900px; margin: auto;" action="/index.php/file/upload" method="POST" enctype="multipart/form-data">
              
                <fieldset>                  
                  <div id=completedList1 style="float: left; width: 300px; height: 300px; overflow: scroll; margin-right: 20px; line-height: 130%; border: 1px solid #666;">
                    <table>
                      <tr><th>Available Items</th></tr>        
                      <?php

                        // $requests is the database object containing the entire SELECT.
                        for($i = 0; $i < count($requests); $i++)
                        {              
                          // Get the primary key to use as as ID for each row.
                          //$id = $requests[$i]->id;
                          echo('<tr><td>');  
                          echo(Form::radio("imageUtility", 
                                            $requests[$i]->id, 
                                            (($requests[$i]->id == $id) ? 'checked' : ''),
                                            array('id'      => $requests[$i]->id, 
                                                  'class'   => 'item'
                                            )));
                          echo(' ' . $requests[$i]->item_no . ' [' . $requests[$i]->angle . ']');
                          echo('</td></tr>' . "\n");              
                        }
                      ?>
                    </table>
                  </div>
          
                   <div id=itemData1 style="float: left; width: 300px;">
                    <ul>
                      <li>Requester:</li>
                      <li id=requester>
                      <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->requester : '')); ?>
                      </li>
                      <li>Customer:</li>
                      <li id=customer>
                      <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->customer : '')); ?>
                      </li>
                      <li>Brand:</li>
                      <li id=brand>
                      <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->brand : '')); ?>
                      </li>
                      <li>Type:</li>
                      <li id=type>
                      <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->type : '')); ?>
                      </li>
                    </ul>
                  </div>
                  
                <div id=applications1 style="float: left; line-height: 130%; width: 250px;">
                  <?php echo(Form::label('apps', 'APPLICATIONS')); ?>
                  <br><p style="font-size: 12px; font-style: italic;">(check with your Admin if an option isn't displayed - spec data may be missing.)</p>
                  <?php 
                    for($i = 0; $i < count($appSpecs); $i++)
                    {
                      // Check that all values are present in db.
                      // If not, don't echo the option.
                      // This prevents later failing when trying to repurpose.
                      if(!empty($appSpecs[$i]->application)
                        && !empty($appSpecs[$i]->naming_formula)
                        && !empty($appSpecs[$i]->file_location)
                        && !empty($appSpecs[$i]->width)
                        && !empty($appSpecs[$i]->height)
                        && !empty($appSpecs[$i]->type))
                      {
                        echo(Form::checkbox($appSpecs[$i]->application, '1'));
                        echo($appSpecs[$i]->application . '<br>');
                      }
                    }
                  ?>
                </div>
                <div style="clear: both;"></div>
                <br><br><hr><br><br>
                <div id=uploader1>                  
                  <input type="hidden" id="MAX_FILE_SIZE" name="MAX_FILE_SIZE" value="300000" />
                  <div>
                  	<label for="fileselect">File to upload (only one allowed):</label>
                  	<input type="file" id="fileselect" name="fileselect[]" multiple="multiple" />
                  	<div id="filedrag">or drop file here (only one allowed).</div>
                  </div>
                  
                  <br>
                  
                  <div id=defaultStyle>
                      <?php echo(Form::label('defaultStyle', 'DEFAULT FOR STYLE')); ?>
                      <br>
                      <?php echo(Form::radio("defaultStyle", 'Yes')); ?>Yes
                      <?php echo(Form::radio("defaultStyle", 'No', true)); ?>No
                  </div>
                  
                  <br>              
                  <br>
                  <?php echo(Form::submit('Upload File')); ?>
                  <br>
                  
                  <div id="messages">
                    <br><p>Status Messages</p>
                  </div>                    
                <div>                 
              </fieldset>
         
              </form>
            </div>    
            
            <?php               
              if(isset($page) && ($page > 0))
              {
                require_once(SERVER_PATH . 'application/views/inc/imaging_utility_standalone' . $page . '.php');
              }
              else
              {
                require_once(SERVER_PATH . 'application/views/inc/imaging_utility_standalone1.php');
              }
            ?>
                           
        </div><!--id=tabs-->

      </div><!--id=uploaderWrapper-->
   
    </div><!--id=inner-->
    
  </div><!--id=outer-->
  
  <script>
    // getElementById
    function $id(id) {
    	return document.getElementById(id);
    }
    //
    // output information
    function Output(msg) {
    	var m = $id("messages");
    	m.innerHTML = msg + m.innerHTML;
    }
    
    // call initialization file
    if (window.File && window.FileList && window.FileReader) {
    	Init();
    }
    //
    // initialize
    function Init() {
    	var fileselect = $id("fileselect"),
    		filedrag = $id("filedrag"),
    		submitbutton = $id("submitbutton");
    	// file select
    	fileselect.addEventListener("change", FileSelectHandler, false);
    	// is XHR2 available?
    	var xhr = new XMLHttpRequest();
    	if (xhr.upload) {
    		// file drop
    		filedrag.addEventListener("dragover", FileDragHover, false);
    		filedrag.addEventListener("dragleave", FileDragHover, false);
    		filedrag.addEventListener("drop", FileSelectHandler, false);
    		filedrag.style.display = "block";
    		// remove submit button
    		submitbutton.style.display = "none";
    	}
    }
    
    // file drag hover
    function FileDragHover(e) {
    	e.stopPropagation();
    	e.preventDefault();
    	e.target.className = (e.type == "dragover" ? "hover" : "");
    }
    
    // file selection
    function FileSelectHandler(e) {
    	// cancel event and hover styling
    	FileDragHover(e);
    	// fetch FileList object
    	var files = e.target.files || e.dataTransfer.files;
    	// process all File objects
    	for (var i = 0, f; f = files[i]; i++) {
    		ParseFile(f);
    	}
    }
    
    function ParseFile(file) {
    	Output(
    		"<p>File information: <strong>" + file.name +
    		"</strong> type: <strong>" + file.type +
    		"</strong> size: <strong>" + file.size +
    		"</strong> bytes</p>"
    	);
    }
  </script>
  
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>