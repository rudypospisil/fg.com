<?php
/**
 * Batch Success view.
 * This view shows success and allows user to continue as batch or end.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date August 2013
 */
?>

<?php Loader::load('head', $title); ?>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=contentFixedWidth>
        <div class=editSavedNotice><p><img src="http://172.16.1.29/img/icons/icon_checkMark_green.png" />YOUR BATCH EDIT HAS BEEN SAVED.</p></div>
        <div style="clear: both;"></div><br>
        
        <div id=newRequestLabels>
          <ul>
            <li>Project Title: </li>
            <?php
              if(isset($batchEdits['priority']))
              {
                echo '<li>Priority: </li>';
              }
              if(isset($batchEdits['status']))
              {
                echo '<li>Status: </li>';
              }
              if(isset($batchEdits['due_date']))
              {
                echo '<li>Due Date: </li>';
              }
              if(isset($batchEdits['photographer']))
              {
                echo '<li>Photographer: </li>';
              }
              if(isset($batchEdits['shoot_date']))
              {
                echo '<li>Shoot Date: </li>';
              }
            ?>
          </ul>
        </div>

        <div id=newRequestData>
          <ul>
            <li><?php echo $batchEdits['project_title']; ?></li>
          <?php          
            if(isset($batchEdits['priority']))
            {
              echo '<li>' . $batchEdits['priority'] . '</li>';
            }
            if(isset($batchEdits['status']))
            {
              echo '<li>' . $batchEdits['status'] . '</li>';
            }
            if(isset($batchEdits['due_date']))
            {
              echo '<li>' . $batchEdits['due_date'] . '</li>';
            }
            if(isset($batchEdits['photographer']))
            {
              echo '<li>' . $batchEdits['photographer'] . '</li>';
            }
            if(isset($batchEdits['shoot_date']))
            {
              echo '<li>' . $batchEdits['shoot_date'] . '</li>';
            }
          ?>
          </ul>
        </div> 
          
        <div class=clear></div> <br>
              
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
<?php Loader::load('footer'); ?>