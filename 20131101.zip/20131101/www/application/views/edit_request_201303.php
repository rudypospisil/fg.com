<?php
/**
 * Edit Request view.
 * This view allows user to edit request.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<script>
$(function() {
  $("#dueDatePicker").datepicker();
  $("#shootDatePicker").datepicker();
$('#saved').css('visibility', 'visible');
$('#saved').fadeIn('slow');
$('#saved').fadeOut('slow');
$('#saved').css('visibility', 'hidden');
});

</script>
<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=contentEditRequest>
        <h3>EDITING OPEN REQUEST</h3>
        
      <?php echo(Form::open('open_requests/update','post')); ?>
        <?php echo(Form::hidden('id', $request->id)); ?>
        <div id=editRequest1>
          <table>
            <tr>
              <td>Requester: </td>
              <td><?php echo($request->requester ? $request->requester : ' '); ?></td>
            </tr>
            <tr>
              <td>Submitted: </td>
              <td><?php echo($request->timestamp_created ? : ' '); ?></td>
            </tr>
            <tr>
              <td>Status: </td>
              <td><?php echo(Form::select('status', array('' => $statusDropdown), $request->status)); ?></td>
            </tr>
            <tr>
              <td>Due Date: </td>
              <td><?php echo(Form::text('dueDate', $request->due_date, array('id' => 'dueDatePicker'))); ?></td>
            </tr>
            <tr>
              <td>Item No: </td>
              <td><?php echo(Form::text('itemNo', $request->item_no)); ?></td>
            </tr>
            <tr>
              <td>Style No: </td>
              <td><?php echo(Form::text('styleNo', $request->style_no)); ?></td>
            </tr>
            <tr>
              <td>Brand: </td>
              <td><?php echo(Form::text('brand', $request->brand)); ?></td>
            </tr>
            <tr>
              <td>Angle - 3Q: </td>
              <td><?php echo(Form::select('angle_3q', array('Yes' => 'Yes', 'No' => 'No'), $request->angle_3q)); ?></td>
            </tr>
            <tr>
              <td style="height: 26px;">Angle - Flat: </td>
              <td><?php echo(Form::select('angle_flat', array('Yes' => 'Yes', 'No' => 'No'), $request->angle_flat)); ?></td>
            </tr>
            <tr>
              <td style="height: 26px;">Angle - Front: </td>
              <td><?php echo(Form::select('angle_front', array('Yes' => 'Yes', 'No' => 'No'), $request->angle_front)); ?></td>
            </tr>
            <tr>
              <td style="height: 26px;">Angle - O: </td>
              <td><?php echo(Form::select('angle_o', array('Yes' => 'Yes', 'No' => 'No'), $request->angle_o)); ?></td>
            </tr>
            <tr>
              <td style="height: 26px;">Angle - Top: </td>
              <td><?php echo(Form::select('angle_top', array('Yes' => 'Yes', 'No' => 'No'), $request->angle_top)); ?></td>
            </tr>
          </table>
        </div>    
        
        <div id=editRequest2>
          <table>
            <tr>
              <td>Type: </td>
              <td><?php echo(Form::text('type', $request->type)); ?></td>
            </tr>
            <tr>
              <td>Customer: </td>
              <td><?php echo(Form::text('customer', $request->customer)); ?></td>
            </tr>
            <tr>
              <td>File Type: </td>
              <td><?php echo(Form::text('fileType', $request->file_type)); ?></td>
            </tr>
            <tr>
              <td>Size: </td>
              <td><?php echo(Form::text('size', $request->size)); ?></td>
            </tr>
            <tr>
              <td>Photographer: </td>
              <td><?php echo(Form::text('photographer', $request->photographer)); ?></td>
            </tr>
            <tr>
              <td>Shoot Date: </td>
              <td><?php echo(Form::text('shootDate', $request->shoot_date, array('id' => 'shootDatePicker'))); ?></td>
            </tr>
            <tr>
              <td>Email Alerts: </td>
              <td><?php echo(Form::textarea('emailAlerts', $request->email_alerts, array('rows' => 2, 'cols' => 20))); ?></td>
            </tr>
            <tr>
              <td>Notes: </td>
              <td><?php echo(Form::text('notes', $request->notes)); ?></td>
            </tr>
            <tr>
              <td>Misc: </td>
              <td><?php echo(Form::text('misc', $request->misc)); ?></td>
            </tr>
            <tr>
              <td>Reference: </td>
              <td><?php echo(Form::text('reference', $request->reference)); ?></td>
            </tr>
            <tr>
              <td>Batch ID: </td>
              <td><?php echo(Form::text('batchNo', $request->batch_no)); ?></td>
            </tr>
          </table>
        </div>
        <div style="position: absolute; top: 670px; left: 680px;">
          <?php echo(Form::submit('Submit')); ?>
          <div id=saved><br>SAVED...</div>
        </div>
        
      <?php echo(Form::close()); ?>                            
      
      <?php echo(Form::open('open_requests','post')); ?>
        <div style="position: absolute; top: 670px; left: 600px;">
          <?php echo(Form::submit('Cancel', array('id' => 'cancel'))); ?>
        </div>
      <?php echo(Form::close()); ?>                            
        
        <br><br>
        <div style="clear: both;"></div>
        
        <div id=alsoBatch>
          Members of this Batch:<br>
          <?php
            foreach($batchRequest as $row)
            {
              // Get the primary key to use as as ID for each row.
              $id = $row->id;
              if($id != Input::get('id'))
              {
                echo('<a style="text-decoration: underline; color: blue;" href="/index.php/open_requests/edit?id=' . $id . '">' . $row->item_no . '</a>');
              }
              else
              {
                echo($row->item_no . '&nbsp;&nbsp;');
              }
            }
          ?>
        </div>        
      
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>