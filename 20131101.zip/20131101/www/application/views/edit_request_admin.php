<?php
/**
 * Edit Request view.
 * This view allows user to edit request.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>

<?php Loader::load('head', $title); ?>

<script>
  $(function() {
    $("#tabs").tabs();
  
    $("#dueDatePicker").datepicker();
    $("#shootDatePicker").datepicker();
    $("#batchDueDatePicker").datepicker();
    $("#batchShootDatePicker").datepicker();
  
    $('#saved').css('visibility', 'visible');
    $('#saved').fadeIn('slow');
    $('#saved').fadeOut('slow');
    $('#saved').css('visibility', 'hidden');
  });

  // Set up the Customer hide/show function.
  $(function() {    
    $('select[name=type]').change(function(){
      var typeSelected = $(this).val();
      //console.log('typeSelected: ' + typeSelected);
      if(typeSelected == 'Customer Request')
      {
        $('#customerLabels').show();
        $('#cusReqMore').show();
        var customerSelected = $('#customerDropdown').val();     
        //console.log('customerSelected: ' + customerSelected);
        $('input[name=customer]').val(customerSelected);
        //console.log('customer: ' + $('input[name=customer]').val());
        //console.log('customerName: ' + $('input[name=customerName]').val());
      }
      else
      {
        $('#customerLabels').hide();
        $('#cusReqMore').hide();
      }
    });
    
    $('select[name=customerDropdown]').change(function(){
      var customerSelected = $('#customerDropdown').val();
      $('input[name=customer]').val(customerSelected);
        //console.log('customer: ' + $('input[name=customer]').val());
    });
  });

$(document).ready(function(){
  if($('select[name=type]').val() != 'Customer Request')
  {
    $('#customerLabels').hide();
    $('#cusReqMore').hide();    
  }    
  // Grab the list of customers from db. Change customer info on onchange event.
  get_customerListWithSelect();
  
  // Prep the tooltip.
  $('.tooltipIcon').click(function(){
    if($('.tooltipPopup').css('display') == 'none')
    {
      $('.tooltipPopup').css('display', 'block');
    }
    else
    {
      $('.tooltipPopup').css({'display':'none'});
    }
  });
  
  $('input[name=selectAll]').change(function(){
    //console.log('clicked');
    if($(this).attr('checked') == 'checked')
    {
      $(this).removeAttr('checked');
    }
    else
    {
      $(this).closest('form').find(':checkbox').attr('checked', 'checked');
    }
  });
});
</script>

<body id=background>

  <?php //Loader::load('masthead'); ?>
  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=contentEditRequestTest>
        <h3>EDITING OPEN REQUEST (Admin)</h3>
        
        <div id="tabs">
          <ul>
            <li><a href="#tabs-1">Single Details</a></li>
            <li><a href="#tabs-2">Project Members</a></li>
          </ul>
          
          <div id="tabs-1">
        
            <?php echo Form::open('open_requests/update?id=' . $request->id,'post'); ?>
            <?php echo Form::hidden('id', $request->id); ?>
            <div id=editRequest1>
              <h3>Single Edit Panel<img class=tooltipIcon src="/img/icons/icon_tooltip.png" /></h3>
              <div class=tooltipPopup>
                <h1>Editing Single Open Request</h1>
                <p>Simply make your changes and click the Submit button.</p>
                <h1>Email Alerts</h1>
                <p>Please note that you are able to expand the size of the input box. Simply click and drag the lower right corner of the box.</p>
                <h1>Notes</h1>
                <p>Please note that you are able to expand the size of the input box. Simply click and drag the lower right corner of the box.</p>
              </div><!--#tooltipPopup-->             
              <table>
                <tr>
                  <td>Project Title: </td>
                  <td><?php echo $request->project_title; ?></td>
                  <?php echo Form::hidden('projectTitle', $request->project_title); ?>
                </tr>
                <tr>
                  <td>Priority: </td>
                  <td><?php echo(Form::select('priority', array('' => $priorityDropdown), $request->priority)); ?></td>
                </tr>
                <tr>
                  <td>Requester: </td>
                  <td><?php echo($request->requester ? $request->requester : ' '); ?></td>
                </tr>
                <tr>
                  <td>Submitted: </td>
                  <?php echo(Form::hidden('timestamp_created', $request->timestamp_created)); ?>
                  <td><?php echo($request->timestamp_created ? : ' '); ?></td>
                </tr>
                <tr>
                  <td>Status: </td>
                  <td><?php echo(Form::select('status', array('' => $statusDropdown), $request->status)); ?></td>
                </tr>
                <tr>
                  <td>Due Date: </td>
                  <td><?php echo(Form::text('dueDate', $request->due_date, array('id' => 'dueDatePicker'))); ?></td>
                </tr>
                <tr>
                  <td>Item No: </td>
                  <td><?php echo(Form::text('itemNo', $request->item_no)); ?></td>
                </tr>
                <tr>
                  <td>Style No: </td>
                  <td><?php echo(Form::text('styleNo', $request->style_no)); ?></td>
                </tr>
                <tr>
                  <td>Brand: </td>
                  <td><?php echo(Form::text('brand', $request->brand)); ?></td>
                </tr>
                <tr>
                  <td>Angle: </td>
                  <td><?php echo(Form::select('angle', array('' => $angleDropdown), $request->angle)); ?></td>
                </tr>
              </table>
            </div><!--#editRequest1-->    
            
            <div id=editRequest2>
              <table>
                <tr>
                  <td>Type: </td>
                  <td><?php echo(Form::select('type', array('' => $typesDropdown), $request->type)); ?></td>
                </tr>
                <br>
                <tr>
                  <td>
                    <div id=customerLabels>
                      <ul>
                        <li class=customerLabel>Customer</li>
                        <li class=customerLabel>File Type</li>
                        <li class=customerLabel>File Size</li>
                        <li class=customerLabel>Comment</li>
                      </ul>
                    </div>
                  </td>
                  <td>
                    <div id=cusReqMore>
                      <ul>
                        <li class=customerData>
                          <select id=customerDropdown name=customerDropdown>
                          <?php //echo(Form::select('customerDropdown', array('' => $customerDropdown), $request->customer)); ?>
                          </select>
                          
                        </li><br>
                        <input type=hidden name=customer id=customer value="<?php echo($request->customer); ?>" />
                        <input type=hidden name=customerName id=customerName value="<?php echo($request->customer); ?>" />
                        <li id=customerFileType class=customerData><?php echo($request->file_type); ?></li><br>
                        <li id=customerFileSize class=customerData>
                          <?php echo($request->file_width); ?>px (w) by <?php echo($request->file_height) ?>px (h)
                        </li><br>
                        <li id=customerComment class=customerData><?php echo($request->customer_comment); ?></li>
                      </ul>
                    </div>
                  </td>            
                </tr>
                <tr>
                  <td>Photographer: </td>
                  <td><?php echo(Form::select('photographer', array('' => $photographerDropdown), $request->photographer)); ?></td>
                </tr>
                <tr>
                  <td>Shoot Date: </td>
                  <td><?php echo(Form::text('shootDate', $request->shoot_date, array('id' => 'shootDatePicker'))); ?></td>
                </tr>
                <tr>
                  <td>Email Alerts: </td>
                  <td><?php echo(Form::textarea('emailAlerts', $request->email_alerts, array('rows' => 2, 'cols' => 30))); ?></td>
                </tr>
                <tr>
                  <td>Notes: </td>
                  <td><?php echo(Form::textarea('notes', $request->notes, array('rows' => 2, 'cols' => 30))); ?></td>
                </tr>
                <tr>
                  <td>Batch ID: </td>
                  <td><?php echo $request->batch_no; ?></td>
                  <?php echo Form::hidden('batchNo', $request->batch_no); ?>
                </tr>
              </table>
            </div><!--#editRequest2-->
            
            <div style="clear: both;"></div>
            <br>
            <div class=buttons>
              <div class=leftButton>
                <?php echo Form::submit('Submit'); ?>
              </div>            
              <?php echo Form::close(); ?>                            
              
              <?php echo Form::open('open_requests','post'); ?>
                <div class=rightButton>
                  <?php echo Form::submit('Cancel', array('id' => 'cancel')); ?>
                </div>
              <?php echo Form::close(); ?>                            
            </div><!--.buttons-->
                            
            <div class=clear></div>
            </div><!-- tabs-1 -->


            <div id="tabs-2">
              <h3>Project Edit Panel<img class=tooltipIcon src="/img/icons/icon_tooltip.png" /></h3>
              <div class=tooltipPopup>
                <h1>Editing Project Title</h1>
                <p>All batch members MUST have the same Project Title. You cannot create separate Project Titles for individual members within the same project. To change Project Title, simply type it into the Project Title text box and click Update. Because this is a global update, it is unnecessary to tick which members. The PIS system knows what to do.</p>
                <h1>Updating Project Members</h1>
                <p>Tick which members that you want edited, type in/select your changes, and click the Update button.</p>
                <h1>Deleting Project Members</h1>
                <p>Tick which members that you want deleted, and click the Delete button.</p>
              </div><!--#tooltipPopup-->             
              <h6>(Whether you are updating or deleting, you MUST select which items.)</h6>
              
              <br><br>
              
              <div id=batchMembers>
                <form id=selectAll>
                <a class=defaultAnchorTag href="javascript: selectAllCheckboxes()">Select all</a> / <a class=defaultAnchorTag href="javascript: deselectAllCheckboxes()">Deselect all</a>
                <br><br>
                <?php
                  foreach($batchRequest as $batchedRequest)
                  {
                    // Get the primary key to use as as ID for each row.
                    $id = $batchedRequest->id;
                    echo Form::checkbox('batchMembers[]', $id);
                    if($id != Input::get('id'))
                    {                      
                      echo('<a class=defaultAnchorTag href="/index.php/open_requests/edit?id=' . $id . '">' 
                        . $batchedRequest->item_no 
                        . '</a> (' 
                        . $batchedRequest->angle 
                        . ')<br><br>'
                        . "\n");
                    }
                    else
                    {
                      echo($batchedRequest->item_no . ' (' . $batchedRequest->angle . ')<br><br>');
                    }
                  }
                  //echo Form::checkbox('selectAll', '');
                  //echo ' Select all.';
                 ?>
                <a class=defaultAnchorTag href="javascript: selectAllCheckboxes()">Select all</a> / <a class=defaultAnchorTag href="javascript: deselectAllCheckboxes()">Deselect all</a>
                </form> 
              </div><!--#batchMembers-->
                              
              <div id=batchEdits>
                 <?php 
                  echo Form::open('open_requests/updateBatchMembers?batch_no=' . $request->batch_no,'post', 
                    array('name' => 'updateBatchMembers', 'onsubmit' => 'return validateBatchMemberUpdate();'));
                 ?>                
                 <table id=cleanTable> 
                  <tr>              
                    <td style="border-right: 0; border-bottom: 0;">Project Title*: </td>
                    <td style="border-left: 0; border-bottom: 0;"><?php echo Form::text('batchProjectTitle'); ?></td>
                  </tr>
                  <tr>
                    <td colspan=2 style="font-size: 12px; border-top: 0;">*Changing "Project Title" will affect ALL members<br>regardless of which members you tick.</td>
                  </tr>
                  <tr>              
                    <td style="border-right: 0;">Priority: </td>
                    <td style="border-left: 0;"><?php echo Form::select('batchPriority', array('' => $priorityDropdown)); ?></td>
                  </tr>
                  <tr>              
                    <td style="border-right: 0;">Status: </td>
                    <td style="border-left: 0;"><?php echo Form::select('batchStatus', array('' => $statusDropdown)); ?></td>
                  </tr>
                  <tr>
                    <td style="border-right: 0;">Due Date: </td>
                    <td style="border-left: 0;"><?php echo Form::text('batchDueDate', '', array('id' => 'batchDueDatePicker')); ?></td>
                  <tr>
                  <tr>
                    <td style="border-right: 0;">Photographer: </td>
                    <td style="border-left: 0;"><?php echo Form::select('batchPhotographer', array('' => $photographerDropdown)); ?></td>
                  <tr>
                  <tr>
                    <td style="border-right: 0;">Shoot Date: </td>
                    <td style="border-left: 0;"><?php echo Form::text('batchShootDate', '', array('id' => 'batchShootDatePicker')); ?></td>
                  <tr>
                </table>
                
                <br>
                
                 <div class=buttons>
                 <div class=leftButton>
                   <?php
                     echo '<div id=batchMembersToUpdate></div>';
                     echo(Form::submit('Update'));
                     echo(Form::close());
                    ?>
                 </div>
                   <?php
                    echo Form::open('open_requests/deleteBatchMembers?batch_no=' . $request->batch_no,'post', 
                      array('name' => 'deleteBatchMembers', 'onsubmit' => 'return validateBatchMemberDelete();'));                
                    echo '<div id=batchMembersToDelete></div>';
                    echo Form::submit('Delete');
                    echo Form::close();
                  ?>
                  <br>
                   <?php
                    echo Form::open('new_request/append_to_batch?batch_no=' . $request->batch_no,'post', array('name' => 'addToBatch'));                
                    echo Form::submit('Add Member');
                    echo Form::close();
                  ?>
                  <div>
                    <p id=noBatchMemberSelectedError>You Must Select at Least One Member.</p>
                  </div>                
                </div><!--.batchButtons-->
                
              <div class=clear></div>

              </div><!--#batchEdits-->
              
              <div id=projectReport>
                <h3>Project Report</h3>
                <ul>
                  <li>Project Title: <?php echo $request->project_title; ?></li>
                  <li>Total Members in Project: <?php echo $countOfBatchedOpenRequests + $countOfBatchedCompletedRequests; ?></li>
                  <li>Still Open: <?php echo $countOfBatchedOpenRequests; ?> (see list at left)</li>
                  <li>Completed: <?php echo $countOfBatchedCompletedRequests; ?></li>
                <?php
                  foreach($completedRequests as $completedRequest)
                  {
                    echo '<li class=italic>' 
                      . $completedRequest->item_no 
                      . ' ('
                      . $completedRequest->angle
                      . ')'
                      . '</li>' . "\n";
                  }
                ?>
                </ul>
              </div><!--#projectReport-->
              <div class=clear></div>
              
            </div><!-- #tabs-2 -->       
        
        </div><!-- #tabs -->        
      
      </div><!--#contentEditRequest-->
   
    </div><!--#mainWrapperInner-->
    
  </div><!--#mainWrapperOuter-->
  
<?php Loader::load('footer'); ?>