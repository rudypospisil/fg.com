<?php
/**
 * Imaging Utility view.
 * This view shows the imaging utility system.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<script>
 $(function() {
   $( "#tabs" ).tabs({ active: 0 });
 }); 

  $(document).ready(function () {
    $("input.item[type=radio]").change(function () {
      var selection = $(this).val();
      path = '/imaging_utility?id=';
      window.location.href = path + $(this).attr('id');
      });

    $("input.namingFormula[type=radio]").change(function () {
      var selection = $(this).val();
      path = '/imaging_utility?namingFormula=';
      window.location.href = path + $(this).attr('namingFormula');
      });

  });   
  
  /* These functions are in the standalone .js file. These grab all the NAV data. */
  $(document).ready(function(){
    startItemList();
    scrollItemListListener();
    autoCompleteListener();  
  });
           
</script>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
    
      <div id=uploaderWrapper>        
        
      <h3>IMAGING UTILITY</h3>
      
       <div id="tabs">
          <ul>
            <li><a href="#tab-completedRequests">PIS</a></li>
            <li><a href="#tab-nav">NAV</a></li>
            <li><a href="#tab-standalone">Standalone</a></li>
          </ul>
          
          <br>
          
            <div id="tab-completedRequests" style="width: 900px; margin: auto;">            
              
              <?php echo(Form::open_for_files('/imaging_utility/upload_completed_request')); ?>
              
                <fieldset>                  
                  <div id=completedList1 style="float: left; width: 300px; height: 300px; overflow: scroll; margin-right: 20px; line-height: 130%; border: 1px solid #666;">
                    <table>
                      <tr><th>Available Items</th></tr>        
                      <?php

                        // $requests is the database object containing the entire SELECT.
                        for($i = 0; $i < count($requests); $i++)
                        {              
                          // Get the primary key to use as as ID for each row.
                          //$id = $requests[$i]->id;
                          echo('<tr><td>');  
                          echo(Form::radio("availableItem", 
                                            $requests[$i]->id, 
                                            (($requests[$i]->id == $id) ? 'checked' : ''),
                                            array('id'      => $requests[$i]->id, 
                                                  'class'   => 'item'
                                            )));
                          echo(' ' . $requests[$i]->item_no . ' [' . $requests[$i]->angle . ']');
                          echo('</td></tr>' . "\n");              
                        }
                      ?>
                    </table>
                  </div>
          
                 <div id=itemData1 style="float: left; width: 300px;">
                  <ul>
                    <li>Item:</li>
                    <li id=requester>
                    <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->item_no : '')); ?>
                    </li>
                    <li>Angle:</li>
                    <li id=requester>
                    <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->angle : '')); ?>
                    </li>
                    <li>Requester:</li>
                    <li id=requester>
                    <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->requester : '')); ?>
                    </li>
                    <li>Customer:</li>
                    <li id=customer>
                    <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->customer : '')); ?>
                    </li>
                    <li>Brand:</li>
                    <li id=brand>
                    <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->brand : '')); ?>
                    </li>
                    <li>Type:</li>
                    <li id=type>
                    <?php echo('&nbsp;&nbsp;' . (isset($id) ? $completedRequest->type : '')); ?>
                    </li>
                  </ul>
                </div>
                  
                <div id=applications1 style="float: left; line-height: 130%; width: 250px;">
                  <?php echo(Form::label('apps', 'APPLICATIONS')); ?>
                  <br><p style="font-size: 12px; font-style: italic;">(check with your Admin if an option isn't displayed - spec data may be missing.)</p>
                  <?php 
                    for($i = 0; $i < count($appSpecs); $i++)
                    {
                      // Check that all values are present in db.
                      // If not, don't echo the option.
                      // This prevents later failing when trying to repurpose.
                      if(!empty($appSpecs[$i]->application)
                        && !empty($appSpecs[$i]->naming_formula)
                        && !empty($appSpecs[$i]->file_location)
                        && !empty($appSpecs[$i]->width)
                        && !empty($appSpecs[$i]->height)
                        && !empty($appSpecs[$i]->type))
                      {
                        echo(Form::checkbox('apps[]', $appSpecs[$i]->application));
                        echo($appSpecs[$i]->application . '<br>');
                      }
                    }
                  ?>
                </div>
                <div style="clear: both;"></div>
                <br><br><hr><br><br>
                <div id=uploader1>                  
                  <input type="hidden" id="MAX_FILE_SIZE" name="MAX_FILE_SIZE" value="3000000" />
                  
                  <div>
                    <?php echo(Form::label('image', 'File to upload (only one allowed):')); ?>
                  	<?php echo(Form::file('image', array('id'=> 'image_id'))); ?>
                  </div>
        
                  <div id="filedrag">or drop file here (only one allowed).</div>
                  
                </div>
                  
                <br>
                
                <div id=defaultStyle>
                    <?php echo(Form::label('defaultStyle', 'DEFAULT FOR STYLE')); ?>
                    <br>
                    <?php echo(Form::radio("defaultStyle", 'Yes')); ?>Yes
                    <?php echo(Form::radio("defaultStyle", 'No', true)); ?>No
                </div>
                
                <br>              
                <br>
                <?php echo(Form::submit('Upload File')); ?>
                <br>
                
                <div id="messages">
                  <br><p>Status Messages</p>
                </div>                    
              <div>                 
            </fieldset>       
            </form>
          </div>    
            
            
          <div id="tab-nav">
            <?php 
              if(isset($page) && ($page > 0))
              {
                //require_once(SERVER_PATH . 'application/views/inc/imaging_utility_standalone' . $page . '.php');
              }
              else
              {
                //require_once(SERVER_PATH . 'application/views/inc/imaging_utility_standalone1.php');
              }
            ?>
            <div id=product style="float: left;">
              <label>SELECT AN ITEM</label><br>              
              <input id=itemSearch name=itemSearch placeholder="Scroll, or type in item number to search." />              
              <?php echo(Form::open_for_files('/imaging_utility/upload_completed_request')); ?>
                               
              <fieldset>
                            
                <div id=itemList>
                  <table>
                    <tr><th>Available Items</th></tr> 

                    <tr><td><div id=output></div></td></tr>
                    <tr><td><input type=hidden name=item_no /></td></tr>

                  </table>
                </div><!-- div#itemList -->
            </div><!-- div#product -->

                <div id=applications2 style="float: left; line-height: 130%; width: 250px;">
                  <?php echo(Form::label('apps', 'APPLICATIONS')); ?>
                  <br><p style="font-size: 12px; font-style: italic;">(check with your Admin if an option isn't displayed - spec data may be missing.)</p>
                  <?php 
                    for($i = 0; $i < count($appSpecs); $i++)
                    {
                      // Check that all values are present in db.
                      // If not, don't echo the option.
                      // This prevents later failing when trying to repurpose.
                      if(!empty($appSpecs[$i]->application)
                        && !empty($appSpecs[$i]->naming_formula)
                        && !empty($appSpecs[$i]->file_location)
                        && !empty($appSpecs[$i]->width)
                        && !empty($appSpecs[$i]->height)
                        && !empty($appSpecs[$i]->type))
                      {
                        echo(Form::checkbox('apps[]', $appSpecs[$i]->application));
                        echo($appSpecs[$i]->application . '<br>');
                      }
                    }
                  ?>
                </div><!-- div#applications2 -->
                
                <div style="clear: both;"></div>
                
                <br><br><hr><br><br>
                <div id=uploader2>                  
                  <input type="hidden" id="MAX_FILE_SIZE" name="MAX_FILE_SIZE" value="3000000" />
                  
                  <div>
                    <?php echo(Form::label('image', 'File to upload (only one allowed):')); ?>
                  	<?php echo(Form::file('image', array('id'=> 'image_id'))); ?>
                  </div>
        
                  <div id="filedrag">or drop file here (only one allowed).</div>
                  
                </div><!-- div#uploader2 -->
                  
                <br>
                
                <div id=defaultStyle2>
                    <?php echo(Form::label('defaultStyle', 'DEFAULT FOR STYLE')); ?>
                    <br>
                    <?php echo(Form::radio("defaultStyle", 'Yes')); ?>Yes
                    <?php echo(Form::radio("defaultStyle", 'No', true)); ?>No
                </div><!-- div#defaultStyle2 -->
                
                <br>              
                <br>
                <?php echo(Form::submit('Upload File')); ?>
                <br>
                
                <div id="messages">
                  <br><p>Status Messages</p>
                </div>                    
            </fieldset>       
            </form>            
          </div><!--tab-nav-->
                
                           
          <div id="tab-standalone">
            <?php 
              if(isset($page) && ($page > 0))
              {
                // Echo the jQuery function to maintain focus on proper tab.
                echo('<script>' . "\n");
                echo('$(function($) {' . "\n");
                echo('// Jump to the current tab in use.' . "\n");
                echo('$("#tabs").tabs({ active: 2 });' . "\n");
                echo('});' . "\n");
                echo('</script>' . "\n");
 
                require_once(SERVER_PATH . '/application/views/inc/imaging_utility_standalone' . $page . '.php');
              }
              else
              {
                require_once(SERVER_PATH . '/application/views/inc/imaging_utility_standalone1.php');
              }
            ?>
          </div><!--tab-standalone-->
                           
        </div><!--id=tabs-->

      </div><!--id=uploaderWrapper-->
   
    </div><!--id=inner-->
    
  </div><!--id=outer-->
    
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>