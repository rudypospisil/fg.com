<?php
/**
 * Open Requests view.
 * This view shows the current open requests in the system.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>

<?php Loader::load('head', $title); ?>

<script>
 $(function() {
   $("#tabs").tabs();
 });
 
 $(document).ready(function(){  
  var payload = '';
  $('.noHover').hover(function(){   
      $('.itemDetailPopup').css('display', 'none');
  });

 $('.selectable').hover(function(){   
   var item = $(this).attr('id');
   console.log(item);
   
   payload = get_openRequestDetailsPopup(item);   
   console.log(payload);
   
   var yPosition = get_mouseY();
    console.log(yPosition);

   $('.itemDetailPopup').css({'display':'block', 'top':yPosition});
   $('.itemDetailPopup').html(payload);     
  }, 
  function(){
    $('.itemDetailPopup').css('display', 'none');
  });
  
 });
</script>

<body id=background class=noHover>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter class=noHover>

    <div id=mainWrapperInner class=noHover>
      
      <br>
      <div id=content class=noHover>
      
        <div id=contentInner class=noHover>

        <?php $sort = Input::has('sort') ? Input::get('sort') : 'batch_no'; ?>
        <div id=header>
          <h3>CURRENT OPEN REQUESTS</h3>
          
          <?php
          // If table is empty, skip all of the following html, otherwise an exception will throw.
          if(isset($requests))
          {
          ?>
          <h6>(Mouse over "Batch #" to view as project. Mouse over "Item #" to view single entry.)</h6>

          <div id=paginationOpenRequests>
            <?php echo(Form::hidden('page', $page)); ?>
            <?php echo(Form::hidden('sort', $sort, array('id' => 'sort'))); ?>
            <p>
              <?php echo($startNumber); ?>-<?php echo($all == false ? $endNumber : $totalCount); ?>&nbsp;of&nbsp;
              <?php echo($totalCount); ?>&nbsp;rows
              &nbsp;&nbsp;<a href="/open_requests?p=<?php echo($prevPage); ?>&sort=<?php echo($sort); ?>"> < </a>
              &nbsp;&nbsp;<a href="/open_requests?p=<?php echo($nextPage); ?>&sort=<?php echo($sort); ?>"> > </a>
              &nbsp;&nbsp;<?php echo($all == false ? ('<a href="/open_requests?all=true&sort=' . $sort . '">ALL</a>') : 'ALL'); ?>
              &nbsp;&nbsp;Page: <?php echo Form::select('pageJump', $pageArray, $page); ?>
              <input type=hidden id=projectMenuString name=projectMenuString />
              &nbsp;&nbsp;Project: <?php echo Form::select('projectJump', $projects, $projectMenuString); ?>
            </p>
          </div><!--#paginationOpenRequests-->
        </div><!--#header-->
        
        <div class=itemDetailPopup></div>
        
        <table id=openRequests>
        <tr>
          <th <?php if($sort == 'batch_no') { echo(' class=selected '); } ?> style="width: 50px;">
            <a <?php if($sort == 'batch_no') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=batch_no">Batch&nbsp;#</a></th>
            
          <th <?php if($sort == 'project_title') { echo(' class=selected '); } ?> style="width: 160px;">
            <a <?php if($sort == 'project_title') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=project_title">Project Title</a></th>

          <th <?php if($sort == 'priority') { echo(' class=selected '); } ?> style="width: 50px;">
            <a <?php if($sort == 'priority') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=priority">Priority</a></th>

          <th <?php if($sort == 'item_no') { echo(' class=selected '); } ?> style="width: 144px;">
            <a <?php if($sort == 'item_no') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=item_no">Item&nbsp;#</a></th>
            
          <th <?php if($sort == 'style_no') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'style_no') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=style_no">Style&nbsp;#</a></th>
            
          <th <?php if($sort == 'brand') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'brand') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=brand">Brand</a></th>
            
          <th<?php if($sort == 'angle') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'angle') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=angle">Angle</a></th>
                        
          <th <?php if($sort == 'due_date') { echo(' class=selected '); } ?> style="width: 50px;">
            <a <?php if($sort == 'due_date') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=due_date">Due&nbsp;Date</a></th>
            
          <th <?php if($sort == 'status') { echo(' class=selected '); } ?> style="width: 150px;">
            <a <?php if($sort == 'status') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=status">Status</a></th>
            
          <th <?php if($sort == 'type') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'type') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=type">Type</a></th>
            
          <th <?php if($sort == 'customer') { echo(' class=selected '); } ?> style="width: 100px;">
            <a <?php if($sort == 'customer') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=customer">Customer</a></th>
          
          <th <?php if($sort == 'photographer') { echo(' class=selected '); } ?> style="width: 80px;">
            <a <?php if($sort == 'photographer') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=photographer">Photog</a></th>
            
          <th <?php if($sort == 'shoot_date') { echo(' class=selected '); } ?> style="width: 50px;">
            <a <?php if($sort == 'shoot_date') { echo(' class=selected '); } ?> href="/open_requests?p=<?php echo($page); ?>&sort=shoot_date">Shoot&nbsp;Date</a></th>
        </tr>
        
          <?php

            $highlight[0] = 'highlightGreen';
            $highlight[1] = 'highlightIndigo';
            $i = 0;
            $num = 0;

            $count = count($requests);
            
            // $requests is the database object containing the entire SELECT.
            for($i = 0; $i < $count; $i++)
            {
              
              // Get the primary key to use as as ID for each row.
              $id = $requests[$i]->id;

              if($i > 0)
              {
                $j = $i - 1;
              }
              else
              {
                $j = 0;
              }
              if($requests[$i]->batch_no != $requests[$j]->batch_no)
              {
                $num++;
                $num = $num % 2;
              }              


              echo('<tr class="' . $highlight[$num] . '">');                
              echo('<td id=batch_' . $id . ' class=batchSelectable>');
              echo($requests[$i]->batch_no
                    . '</td><td id=title_' . $id . ' class=batchSelectable>'
                    . substr($requests[$i]->project_title, 0, 15) . '...'
                    . '</td><td class=noHover>'
                    . $requests[$i]->priority
                    . '</td><td id=' . $id . ' class=selectable>'
                    . $requests[$i]->item_no
                    . '</td><td>'
                    . $requests[$i]->style_no
                    . '</td><td>'
                    . $requests[$i]->brand
                    . '</td><td>'
                    . $requests[$i]->angle
                    . '</td><td>'
                    . $requests[$i]->due_date
                    . '</td><td>'
                    . $requests[$i]->status
                    . '</td><td>'
                    . $requests[$i]->type
                    . '</td><td>'
                    . $requests[$i]->customer
                    . '</td><td>'
                    . substr($requests[$i]->photographer, 0, 9) . '...'
                    . '</td><td>'
                    . $requests[$i]->shoot_date);
              echo('</td>');
              // Output the edit/view link using the primary key.
              echo('<td style="width: 30px;"><a style="text-decoration: underline; color: blue;" href="/open_requests/edit?id=' . $id . '">edit</a>
              </td>');
              echo('</tr>' . "\n");
              
            }
          ?>
          </table>
          <?php
          }
          else
          {
            echo '<p>There are currently no open requests in the database.</p>' . "\n";
            echo '</div><!--#header-->';
          }
          ?>
        </div><!--contentInner-->

      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->

<!--  
  <div id="input-menus" class="inline-spaces">
        <div class="context-menu-three box menu-1" 
          data-yesno0="true" 
          data-yesno2="true" 
        <strong>right click to filter</strong>
      </div>
  </div>
  
<uul></uul>
-->
<script>
$(document).ready(function() {
    // Sorting and pagination function.
    sort = $('#sort').val();
      
    $('.selectable').click(function(e) {
        path = '/open_requests/edit?id=';
        window.location.href = path + $(this).attr('id');
    });
    
    $('.batchSelectable').click(function(e) {
        
        //console.log($(this).attr('id'));
        var fullId = $(this).attr('id');
        //console.log(fullId);
        var id = fullId.split("_").pop();
        //console.log(id);
        path = '/open_requests/edit?id=';
        window.location.href = path + id + '#tabs-2';
    });
    
    $('.selectable').hover(
      function() {
        $('td').removeClass('batchHover');
      });
    $('.noHover').hover(
      function() {
        $('td').removeClass('batchHover');
      });
    $('.batchSelectable').hover(
      function() {
        $('td').removeClass('batchHover');
        var fullId = $(this).attr('id');
        var idName = fullId.split("_").shift();
        if(idName == 'title')
        {
          $(this).prev('td').addClass('batchHover');
        }
        else
        {
          $(this).next('td').addClass('batchHover');
        }
      });
  
    $('select[name=pageJump]').change(function(e)
    {
      var path = '/open_requests?p=';
      window.location.href = path + $(':selected',this).attr('value') + '&sort=' + sort;      
    });
    
    $('select[name=projectJump]').change(function(e)
    {
      var projectSelected = $(':selected', this).text();
      
      $('#projectMenuString').val(projectSelected);
      //console.log($('#projectMenuString').val());
      
      var projectNum = projectSelected.split(" ")[0];
      
      //console.log(projectNum);
      var path = '/open_requests?project=';
      window.location.href = path + projectNum + '&sort=' + sort + '&string=' + projectSelected;      
    });
    
    $.getJSON('/open_requests_test/group_by/angle', function(data){
      $.each(data, function(key, value){
        $('uul').append('<li>' + value + '</li>');
      });
    });
});
</script>    
<script type="text/javascript">
    $(function(){
        /**************************************************
         * Menu Input
         **************************************************/
        $.contextMenu({
            selector: '.context-menu-three', 
            items: {
                yesno0: {name: "Brand", type:'checkbox', value:""},
                sep1: "---------",
                yesno1: {name: "Batch ID", type:'checkbox', selected:true},
                yesno2: {name: "Item No", type:'checkbox', selected:true},
                yesno3: {name: "Style No", type:'checkbox', selected:true},
                yesno4: {name: "Requester", type:'checkbox', selected:true},
                yesno5: {name: "Due Date", type:'checkbox', selected:true},
                sep2: "---------",
                key: {name: "Click to Filter", callback: function(e){alert($(".context-menu-three").data('yesno0'))}}
            }, 
            events: {
                show: function(opt) {
                    var $this = this;
                    // import states from data store
                    $.contextMenu.setInputValues(opt, $this.data());
                }, 
                hide: function(opt) {
                    var $this = this;
                    // export states to data store
                    $.contextMenu.getInputValues(opt, $this.data());
                    alert($(".context-menu-three").data('yesno0'));
                }
            }
        });
    });
</script>
    
<?php Loader::load('footer'); ?>