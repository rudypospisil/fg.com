<?php
/**
 * Edit Request view.
 * This view allows user to edit request.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
?>

<?php Loader::load('head', $title); ?>

<script>
  $(function() {
    $("#tabs").tabs();
  });

  $(document).ready(function(){
    if($('#type').val() == 'Customer Request')
    {
      $('#customerLabels').show();
      $('#cusReqMore').show();    
    }    
    // Grab the list of customers from db. Change customer info on onchange event.
    get_customerListWithSelect();
  
    // Prep the tooltip.
    $('#tooltipIcon').click(function(){
      if($('#tooltipPopup').css('display') == 'none')
      {
        $('#tooltipPopup').css('display', 'block');
      }
      else
      {
        $('#tooltipPopup').css({'display':'none'});
      }
    });
});
</script>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=contentEditRequest>
        <h3>EDITING OPEN REQUEST (Contributor)</h3>
        
        <div id="tabs">
          <ul>
            <li><a href="#tabs-1">Single Details</a></li>
            <li><a href="#tabs-2">Project Members</a></li>
          </ul>
          
          <div id="tabs-1">
        
            <?php echo Form::open('open_requests/updateOpenRequest?id=' . $request->id,'post'); ?>
            <?php echo Form::hidden('id', $request->id); ?>
            <div id=editRequest1>
              <table>
                <tr>
                  <td>Project Title: </td>
                  <td><?php echo $request->project_title; ?></td>
                  <?php echo Form::hidden('projectTitle', $request->project_title); ?>
                </tr>
                <tr>
                  <td>Priority: </td>
                  <td><?php echo($request->priority - 1); ?></td>
                </tr>
                <tr>
                  <td>Requester: </td>
                  <?php echo(Form::hidden('requester', $request->requester)); ?>
                  <td><?php echo($request->requester); ?></td>
                </tr>
                <tr>
                  <td>Submitted: </td>
                  <?php echo(Form::hidden('timestamp_created', $request->timestamp_created)); ?>
                  <td><?php echo($request->timestamp_created ? : ' '); ?></td>
                </tr>
                <tr>
                  <td>Status: </td>
                  <td><?php echo(Form::select('status', array('' => $statusDropdown), $request->status)); ?></td>
                </tr>
                <tr>
                  <td>Due Date: </td>
                  <td><?php echo($request->due_date); ?></td>
                </tr>
                <tr>
                  <td>Item No: </td>
                  <td><?php echo($request->item_no); ?></td>
                </tr>
                <tr>
                  <td>Style No: </td>
                  <td><?php echo($request->style_no); ?></td>
                </tr>
                <tr>
                  <td>Brand: </td>
                  <td><?php echo($request->brand); ?></td>
                </tr>
                <tr>
                  <td>Angle: </td>
                  <td><?php echo($request->angle); ?></td>
                </tr>
              </table>
            </div>    
            
            <div id=editRequest2>
              <table>
                <tr>
                  <td>Type: </td>
                  <td id=type><?php echo $request->type; ?></td>
                </tr>
                <br>
                <tr>
                  <td>
                    <div id=customerLabels>
                      <ul>
                        <li class=customerLabel>Customer</li>
                        <li class=customerLabel>File Type</li>
                        <li class=customerLabel>File Size</li>
                        <li class=customerLabel>Comment</li>
                      </ul>
                    </div>
                  </td>
                  <td>
                    <div id=cusReqMore>
                      <ul>
                        <li name=customerName id=customerName><?php echo($request->customer); ?></li><br>
                        <li id=customerFileType class=customerData><?php echo($request->file_type); ?></li><br>
                        <li id=customerFileSize class=customerData>
                          <?php echo($request->file_width); ?>px (w) by <?php echo($request->file_height) ?>px (h)
                        </li><br>
                        <li id=customerComment class=customerData><?php echo($request->customer_comment); ?></li>
                      </ul>
                    </div>
                  </td>            
                </tr>
                <tr>
                  <td>Photographer: </td>
                  <td><?php echo($request->photographer); ?></td>
                </tr>
                <tr>
                  <td>Shoot Date: </td>
                  <td><?php echo($request->shoot_date); ?></td>
                </tr>
                <tr>
                  <td>Email Alerts: </td>
                  <td><?php echo($request->email_alerts); ?></td>
                </tr>
                <tr>
                  <td>Notes: </td>
                  <td><?php echo($request->notes); ?></td>
                </tr>
                <tr>
                  <td>Batch ID: </td>
                  <td><?php echo($request->batch_no); ?></td>
                </tr>
              </table>
            </div>
            
            <div id=buttons>
              <div id=leftButton>
                <?php echo(Form::submit('Submit')); ?>
              </div>            
              <?php echo(Form::close()); ?>                            
              
              <?php echo(Form::open('open_requests','post')); ?>
                <div id=rightButton>
                  <?php echo(Form::submit('Cancel', array('id' => 'cancel'))); ?>
                </div>
              <?php echo Form::close(); ?>                            
            </div>
              
              <br><br>
              <div style="clear: both;"></div>
              
            </div><!-- tab1 -->
          
            <div id="tabs-2">
              <h3>Project Edit Panel<img id=tooltipIcon src="/img/icons/icon_tooltip.png" /></h3>
              <div id=tooltipPopup>
                <h1>Editing Project Title</h1>
                <p>All batch members MUST have the same Project Title. You cannot create separate Project Titles for individual members within the same project. To change Project Title, simply type it into the Project Title text box and click Update. Because this is a global update, it is unnecessary to tick which members. The PIS system knows what to do.</p>
                <h1>Updating Project Members</h1>
                <p>Tick which members that you want edited, type in/select your changes, and click the Update button.</p>
                <h1>Deleting Project Members</h1>
                <p>Tick which members that you want deleted, and click the Delete button.</p>
              </div><!--#tooltipPopup-->             
              <h6>(Whether you are updating or deleting, you MUST select which items.)</h6>
              
              <br><br>
              
              <div id=batchMembers>
                <form id=selectAll>
                <?php
                  foreach($batchRequest as $batchedRequest)
                  {
                    // Get the primary key to use as as ID for each row.
                    $id = $batchedRequest->id;
                    echo Form::checkbox('batchMembers[]', $id);
                    if($id != Input::get('id'))
                    {                      
                      echo('<a class=defaultAnchorTag href="/index.php/open_requests/edit?id=' . $id . '">' 
                        . $batchedRequest->item_no 
                        . '</a> (' 
                        . $batchedRequest->angle 
                        . ')<br><br>'
                        . "\n");
                    }
                    else
                    {
                      echo($batchedRequest->item_no . ' (' . $batchedRequest->angle . ')<br><br>');
                    }
                  }
                 ?>
                <a class=defaultAnchorTag href="javascript: selectAllCheckboxes()">Select all</a> / <a class=defaultAnchorTag href="javascript: deselectAllCheckboxes()">Deselect all</a>
                </form> 
              </div><!--#batchMembers-->
               
              <br>
               
              <div id=batchEdits>
                 <?php 
                  echo Form::open('open_requests/updateBatchMembers?batch_no=' . $request->batch_no,'post', 
                    array('name' => 'updateBatchMembers', 'onsubmit' => 'return validateBatchMemberUpdate();'));
                 ?>                
                 <table id=cleanTable> 
                  <tr>              
                    <td style="border-right: 0;">Status: </td>
                    <td style="border-left: 0;"><?php echo Form::select('batchStatus', array('' => $statusDropdown)); ?></td>
                  </tr>
                </table>
                
                <br>
                
                <?php
                  echo '<div id=batchMembersToUpdate></div>';
                  echo Form::submit('Update');
                  echo Form::close();
                ?>
                
                <br>

                <div id=batchButtons>
                 <?php
                  echo Form::open('new_request/append_to_batch?batch_no=' . $request->batch_no,'post', array('name' => 'addToBatch'));                
                  echo Form::submit('Add Member');
                  echo Form::close();
                ?>
                <div>
                  <p id=noBatchMemberSelectedError>You Must Select at Least One Member.</p>
                </div>                
                </div><!--#batchButtons-->

              </div><!--#batchEdits-->
              
              <br>
              
              <div id=projectReport>
                <h3>Project Report</h3>
                <ul>
                  <li>Project Title: <?php echo $request->project_title; ?></li>
                  <li>Total Members in Project: <?php echo $countOfBatchedOpenRequests + $countOfBatchedCompletedRequests; ?></li>
                  <li>Still Open: <?php echo $countOfBatchedOpenRequests; ?> (see list at left)</li>
                  <li>Completed: <?php echo $countOfBatchedCompletedRequests; ?></li>
                <?php
                  foreach($completedRequests as $completedRequest)
                  {
                    echo '<li class=italic>' 
                      . $completedRequest->item_no 
                      . ' ('
                      . $completedRequest->angle
                      . ')'
                      . '</li>' . "\n";
                  }
                ?>
                </ul>
              </div><!--#projectReport-->
              
            </div><!-- #tabs-2 -->       
        
        </div><!-- tabs -->        
      
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
<?php Loader::load('footer'); ?>