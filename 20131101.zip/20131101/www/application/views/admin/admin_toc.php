<?php
/**
 * Admin Control Panel view.
 * This view builds the admin control panel page.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
?>
<?php require_once('/var/www/application/views/inc/head.php'); ?>

<script>
 $(function() {
   $( "#tabs" ).tabs({ active: 0 });
 });
 
</script>

<body id=background>

  <?php require_once('/var/www/application/views/inc/masthead.php'); ?>
    
  <div id=mainWrapperOuter>

    <div id=mainWrapperInner>
      
      <div id=adminContent>
              
      <h3>ADMIN CONTROL PANEL</h3>

        <div id="tabs">
          <ul>
            <li><a href="#tabs-1">Applications</a></li>
            <li><a href="#tabs-2">Status</a></li>
            <li><a href="#tabs-3">Angles</a></li>
            <li><a href="#tabs-4">Photographers</a></li>
          </ul>
          
            <div id="tabs-1">            
              <div>                
                <?php echo(Form::open('admin/add_entry_app','post')); ?>
                <?php echo(Form::submit('+')); ?>
                <?php echo(Form::close()); ?>                            
                <br>
              </div>
            
              <table>
                <tr class=header><td>APPLICATION</td><td>NAMING FORMULA</td><td>FILE LOCATION</td><td>WIDTH</td><td>HEIGHT</td><td>TYPE</td></tr>
              <?php
                for($i = 0; $i < count($adminData['app']); $i++)
                {
                  echo('<tr>');
                  echo(Form::open('admin/update_app','post'));
                  echo(Form::hidden('id', $adminData['app'][$i]->id));
                  echo('<td class=largeField>' . Form::text('application', $adminData['app'][$i]->application) . '</td>');
                  echo('<td class=largeField>' . Form::text('naming_formula', $adminData['app'][$i]->naming_formula) . '</td>');
                  echo('<td class=largeField>' . Form::text('file_location', $adminData['app'][$i]->file_location) . '</td>');
                  echo('<td class=smallField>' . Form::text('width', $adminData['app'][$i]->width) . '</td>');
                  echo('<td class=smallField>' . Form::text('height', $adminData['app'][$i]->height) . '</td>');
                  echo('<td class=smallField>' . Form::select('type', array('jpg' => 'jpg', 'gif' => 'gif', 'png' => 'png'), $adminData['app'][$i]->type) . '</td>');
                  echo('<td class=noBorder>' . Form::submit('UPDATE') . '</td>');
                  echo(Form::close() . "\n");
                  echo(Form::open('admin/delete_app','post'));
                  echo(Form::hidden('id', $adminData['app'][$i]->id));
                  echo('<td class=noBorder>' . Form::submit('DELETE', array('id' => 'delete')) . '</td>');
                  echo(Form::close());
                  echo('</tr>' . "\n");
                }
              ?>
              </table>
              <br>
              <p>Please note: if any data is missing for an item, the option will not show up in the Imaging Utility.</p>
              <br>
            </div>
            
            <div id="tabs-2">
              <div>                
                <?php echo(Form::open('admin/add_entry_status','post')); ?>
                <?php echo(Form::submit('+')); ?>
                <?php echo(Form::close()); ?>                            
                <br>
              </div>
            
              <table>
                <tr class=header><td>STATUS CODES</td></tr>
              <?php
                for($j = 0; $j < count($adminData['status']); $j++)
                {
                  echo('<tr>');
                  echo(Form::open('admin/update_status','post'));
                  echo(Form::hidden('id', $adminData['status'][$j]->id));
                  echo('<td class=largeField>' . Form::text('status', $adminData['status'][$j]->status) . '</td>');
                  echo('<td class=noBorder>' . Form::submit('UPDATE') . '</td>');
                  echo(Form::close() . "\n");
                  echo(Form::open('admin/delete_status','post'));
                  echo(Form::hidden('id', $adminData['status'][$j]->id));
                  echo('<td class=noBorder>' . Form::submit('DELETE', array('id' => 'delete')) . '</td>');
                  echo(Form::close());
                  echo('</tr>' . "\n");
                }
              ?>
              </table>
              <br>
            </div>
            
            <div id="tabs-3">
              <p>...</p>
              <p>...</p>
              <p>...</p>
              <p>...</p>
              <p>...</p>
              <p>...</p>
              <p>...</p>
            </div>
            <div id="tabs-4">
              <div>                
                <?php echo(Form::open('admin/add_entry_photographer','post')); ?>
                <?php echo(Form::submit('+')); ?>
                <?php echo(Form::close()); ?>                            
                <br>
              </div>
            
              <table>
                <tr class=header><td>PHOTOGRAPHERS</td></tr>
              <?php
                for($i = 0; $i < count($adminData['photographers']); $i++)
                {
                  echo('<tr>');
                  echo(Form::open('admin/update_photographer','post'));
                  echo(Form::hidden('id', $adminData['photographers'][$i]->id));
                  echo('<td class=largeField>' . Form::text('photographers', $adminData['photographers'][$i]->name) . '</td>');
                  echo('<td class=noBorder>' . Form::submit('UPDATE') . '</td>');
                  echo(Form::close() . "\n");
                  echo(Form::open('admin/delete_app','post'));
                  echo(Form::hidden('id', $adminData['photographers'][$i]->id));
                  echo('<td class=noBorder>' . Form::submit('DELETE', array('id' => 'delete')) . '</td>');
                  echo(Form::close());
                  echo('</tr>' . "\n");
                }
              ?>
              </table>
              <br>
            </div>

        </div><!--adminContent-->
        
      </div><!--content-->
   
    </div><!--inner-->
    
  </div><!--outer-->
  
  <?php require_once('/var/www/application/views/inc/footer.php'); ?>