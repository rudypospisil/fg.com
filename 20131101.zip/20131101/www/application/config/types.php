<?php

  /**
   * The types.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date July 2013
   */
  
  // This will be used throughout the system.
  
  // I am doing this here as it serves as a master function rather than rewriting the queries each time.
  
  $typesDropdown = array('Prototype' => 'Prototype', 
                        'Production' => 'Production', 
                        'Customer Request' => 'Customer Request');
  
  // Return an array of all of the types.
  return $typesDropdown;