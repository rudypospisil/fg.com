<?php

  return array(
  /**
   * All column headings for requests.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date February 2013
   */
  
     0 => 'New Request', 
     'Open Requests',
     'Completed',
     'Library',
     'Imaging Utility',
  );