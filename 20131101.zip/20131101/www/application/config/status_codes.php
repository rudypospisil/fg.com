<?php

  /**
   * The status codes.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date February 2013
   */
  
  // Pull values in from database and build array.
  // This will be used throughout the system for DROPDOWN MENUS.
  
  $statusCodeObjectArray = DB::table('status_codes')
                                ->order_by('status_code', 'asc')
                                ->get();
  
  $statusCodes[0] = 'Select...';
  
  foreach($statusCodeObjectArray as $statusCode)
  {
    $statusCodes[$statusCode->status_code] = $statusCode->status_code;
  }
  
  return $statusCodes;