<?php

  /**
   * The photographers.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date April 2013
   */
  
  // Pull values in from database and build array.
  // This will be used throughout the system for DROPDOWN MENUS.
  
  // Declare an array named 'photographers'.
  //$photographers = new Array();
  
  // Read in all of the photographers table.
  // Make an array, each row becomes an object within this array.
  $photographersObjectArray = DB::table('photographers')->get();

  $photographers[0] = 'Select...';
  
  // Loop through the array, stopping on each object.
  foreach($photographersObjectArray as $photographer)
  {
    // Concat first and last name and set to a variable called full_name.
    //$full_name = $photographer->first_name . $photographer->last_name;
    
    // Within the photographers array, create an index named with the fullname, and set its value also to fullname.
    $photographers[$photographer->full_name] = $photographer->full_name;
  }
  
  // Return an array of all of the photographers as full names.
  return $photographers;