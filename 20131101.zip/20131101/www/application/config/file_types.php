<?php

  /**
   * The types.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date July 2013
   */
  
  // This will be used throughout the system.
  
  // I am doing this here as it serves as a master function rather than rewriting the queries each time.
  
  $fileTypesDropdown = array('NA' => 'NA',
                              'gif' => 'gif', 
                              'jpg' => 'jpg', 
                              'png' => 'png',
                              'psd' => 'psd',
                              'tif' => 'tif');
  
  // Return an array of all of the types.
  return $fileTypesDropdown;