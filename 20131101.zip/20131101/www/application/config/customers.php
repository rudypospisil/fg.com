<?php

  /**
   * The status codes.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date February 2013
   */
  
  // Pull values in from database and build array.
  // This will be used throughout the system for DROPDOWN MENUS.
  
  $customersObjectArray = DB::table('customers')->order_by('customer', 'asc')->get();
  //$customers = array();
  
  if(count($customersObjectArray) > 0)
  {
    foreach($customersObjectArray as $customer)
    {
      $customers[$customer->customer] = $customer->customer;
    }
  }
  else
  {
    $customers = DB::table('globals')->where('id', '=', 1)->only('error_empty_database');
  }  
  
  //echo $customers;
  //exit;
  return $customers;