<?php
  /**
   * The menu items for the landing page.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date August 2013
   */
  
  // Build the table of contents according to the user's privileges.
  $memberof = Login::get_userMemberof();
  
  // Build array of memberof foreign keys for its valid sections.
  $memberofSections = DB::table('systemcodes_memberof')->where('code', '=', $memberof)->first('fk_sections');
  
  // Explode the keys into an array.            
  $fkSections = explode(',', $memberofSections->fk_sections);
  
  // Grab all of the sections data.
  $systemCodesSections = DB::table('systemcodes_sections')->get();
  
  // Build the menu matching the memberof its foreign keys to the sections table.
  for($i = 0; $i<count($fkSections); $i++)
  {
    $fk = $fkSections[$i];
    $url = $systemCodesSections[$fk]->url;
    $text = $systemCodesSections[$fk]->text;
    echo '<li>&bull;&nbsp;<a href="'
      . $url
      . '">'
      . $text
      . '</a></li>' . "\n";
  }            
  
  // Add ability of logging out.
  $logout = DB::table('systemcodes_sections')->where('code', '=', 'logout')->first();
  echo '<li>&bull;&nbsp;<a href="'
    . $logout->url
    . '">'
    . $logout->text
    . '</a></li>' . "\n";