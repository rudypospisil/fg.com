<?php

  /**
   * The priority codes.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date July 2013
   */
  
  // Pull values in from database and build array.
  // This will be used throughout the system for DROPDOWN MENUS.
  
  $prioritiesObjectArray = DB::table('priority_codes')->get();
  
  $i = 1;
  $priorities[0] = 'Select...';
  foreach($prioritiesObjectArray as $priorityCode)
  {
    $priorities[$i] = $priorityCode->code;
    $i++;
  }
  
  return $priorities;