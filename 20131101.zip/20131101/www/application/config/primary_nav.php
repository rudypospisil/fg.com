<?php
  /**
   * The menu items for the primary navigation.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date February 2013
   */
  
  $memberof = Login::get_userMemberof();
  
  //$groups = DB::table('systemcodes_memberof')->get();
  // Note to self: rewrite this so that it is as generic as possible.
  // Use Db values. See my example that I did in the landing nav.
  
  switch($memberof)
  {
    case 'admin':
      return array(
         0 => 'New Request', 
         1 => 'Open Requests',
         2 => 'Completed Requests',
         3 => 'Library',
         4 => 'Imaging Utility'
      );      
    break;
    case 'manager':
      return array(
         0 => 'New Request', 
         1 => 'Open Requests',
         2 => 'Completed Requests',
         //3 => 'Library',
         //4 => 'Imaging Utility'
      );      
      break;
    case 'contributor':
      return array(
         0 => 'New Request', 
         1 => 'Open Requests',
         2 => 'Completed Requests',
         //3 => 'Library'
      );      
      break;
    case 'photog':
      return array(
         0 => 'Open Requests',
         1 => 'Completed Requests',
         //2 => 'Library'
      );      
      break;
    case false:
    default:
      Return Redirect::to('login');
      break;
  }

/*  
  // Build array of memberof foreign keys for its valid sections.
  $memberofSections = DB::table('systemcodes_memberof')->where('code', '=', $memberof)->first('fk_sections');
  
  // Explode the keys into an array.            
  $fkSections = explode(',', $memberofSections->fk_sections);
  
  // Grab all of the sections data.
  $systemCodesSections = DB::table('systemcodes_sections')->get();
  
  $primaryNav = new stdClass();
  
  // Build the menu matching the memberof its foreign keys to the sections table.
  for($i = 0; $i<count($fkSections); $i++)
  {
    $fk = $fkSections[$i];
    
    $primaryNav[$i]->menuTitle = $systemCodesSections[$fk]->menu_title;
    $primaryNav[$i]->url = $systemCodesSections[$fk]->url;
  } 
  
  return $primaryNav;           
*/