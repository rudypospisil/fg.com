<?php

  /**
   * The angles.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date April 2013
   */
  
  // Pull values in from database and build array.
  // This will be used throughout the system.
  
  // I am doing this here as it serves as a master function rather than rewriting the queries each time.
  
  // Declare an array named 'angles'.
  // $angles = new Array();
    
  // Read in all of the angles table.
  // Make an array, each row becomes an object within this array.
  $anglesObjectArray = DB::table('angles')
                            ->get();
  
  // Loop through the array, stopping on each object.
  foreach($anglesObjectArray as $angle)
  {
    // Create an index named with the angle, and set its value also to its angle.
    $angles[$angle->angle] = $angle->angle;
  }
  
  // Return an array of all of the angles.
  return $angles;