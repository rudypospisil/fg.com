<?php

  /**
   * The application specs for the imaging utility.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date May 2013
   */
  
  // Pull values in from database and build array.
  // This will be used throughout the system ONLY FOR DROPDOWN MENUS.
  
  // I am doing this here as it serves as a master function rather than rewriting the queries each time.
  
  // Declare an array named 'appSpecs'.
  $appSpecs = new Array();
    
  // Read in all of the app_specs table.
  // Make an array, each row becomes an object within this array.
  $appSpecsObjectArray = DB::table('app_specs')
                                ->order_by('application', 'asc')
                                ->get();
  
  // Loop through the array, stopping on each object.
  foreach($anglesObjectArray as $appSpec)
  {
    // Create an index named with the value, and set its value also to the queried value.
    $appSpecs[$appSpec->application]                  = $$appSpec->application;
    $appSpecs[$appSpec->application]->naming_formula  = $$appSpec->naming_formula;
    $appSpecs[$appSpec->application]->file_location   = $$appSpec->file_location;
    $appSpecs[$appSpec->application]->width           = $$appSpec->width;
    $appSpecs[$appSpec->application]->height          = $$appSpec->height;
    $appSpecs[$appSpec->application]->type            = $$appSpec->type;
  }
  
  // Return an array of all of the angles.
  return $appSpecs;