<?php
/**
 * LDAP Authentication class.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */

class Rpldapauth extends Laravel\Auth\Drivers\Driver 
{

	  function __construct() 
	  {
      parent::__construct();   
    }


    public function attempt($args = array())
    {
      // Initial credentials supplied by Steve.
      //$user='CN=OTRS Search,CN=Users,DC=fgoldman,DC=com';
      //$username = 'OTRS Search';
      //$password = 't1ck3tsyst3m';
      
      // User inputted parameters.
      $username = $args['username'];
      $password = $args['password'];
      
      // Is it a photographer that is logging in?
      // It's not a photographer, check against AD.
      if(count(self::isPhotographer($username, $password)) == 1 
        || ($this->isInActiveDirectory($username, $password)))
      {
        self::logUser($username, Session::get('ldap_cn'), Session::get('ldap_email'), Session::get('ldap_memberof'));
        return true;
      }
      else
      {
        return false;
      }      
    }


    private static function isPhotographer($username, $password)
    {
      $photog = DB::table('photographers')
        ->where('username', '=', $username)
        ->where('password', '=', $password)
        ->first();
        
      if(count($photog) == 1)
      {
        Session::put('ldap_cn', $photog->first_name . ' ' . $photog->last_name); 
        Session::put('ldap_email', $photog->email); 
        Session::put('ldap_memberof', 'photog'); 
      }
      
      return $photog;
    }



    /**
     * Validate the user as an AD entry.
     * 
     */
    private static function isInActiveDirectory($username, $password)
    {
      $userPrincipalName  = $username . '@fgoldman.com';

      // FG LDAP server.
      $ldapServer='fgidc2.fgoldman.com';
      $ldapPort = 389;

      // Set the base DN.
      $baseDn = "DC=fgoldman,DC=com";
      
      // Return only these three attributes for said user.
      $returnThese = array("mail", 
                           "cn", 
                           "userprincipalname", 
                           "memberof"
                           );
      
      // Connect to LDAP server. Returns LDAP link identifier.
      $ldapConn = ldap_connect($ldapServer);  
            
      // These options MUST be set, otherwise search will fail.
      ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
      ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0);

      // If LDAP connection is successful, bind and search.
      if($ldapConn)
      {
        // Bind with appropriate dn to give update access
        if(ldap_bind($ldapConn, $userPrincipalName, $password))
        {
          // Perform search on the authenticated user.
          $filter = "(userprincipalname=$userPrincipalName)";
          $search = ldap_search($ldapConn, $baseDn, $filter, $returnThese);

          // Get the entry of said user.
          $entry = ldap_get_entries($ldapConn, $search);
          
          // Set the various attributes.
          $cn       = self::setCn($entry);

          $email    = self::setEmail($entry);

          $memberof = self::setMemberof($entry);
                    
          // Authentication success. Break connection.
          ldap_unbind($ldapConn);
          
          // Let system know that login succeeded. This will establish a session.
          return true;
        }
        else
        // Bind is unsuccessful. Reset.
        {
          ldap_unbind($ldapConn);
          Session::forget('ldap_cn'); 
          Session::forget('ldap_email'); 
          Session::forget('ldap_memberof'); 
          return false;
        } 
      }
      else
      // Connection is unsuccessful.
      {
        echo('Unable to connect to LDAP server'); 
        return false;
      }
    }



    /**
     * Set the user's Common Name according to their AD entry.
     * 
     */
    private static function setCn($entry)
    {
      
      // Set the user's name as their AD Common Name entry (cn).
      $cn = isset($entry[0]['cn']) ? $entry[0]['cn'][0] : 'No CN in AD Entry.';
      
      Session::put('ldap_cn', $cn);
      
      return $cn;
    }



    /**
     * Set the user's Email according to their AD entry.
     * 
     */
    private static function setEmail($entry)
    {
      // Set the user's email as their AD mail entry (mail) or user principal name (userprincipalname).
      $email = isset($entry[0]['mail']) 
        ? $entry[0]['mail'][0] 
        : (isset($entry[0]['userprincipalname']) 
            ? $entry[0]['userprincipalname'][0] 
            : 'No Email in AD Entry.');
                        
      Session::put('ldap_email', $email);
      
      return($email);
    }



    /**
     * Set the user's privileges according to their AD entry.
     * 
     */
    private static function setMemberof($entry)
    {
      // Set the user's membership privileges according to AD.
      $memberofArray = isset($entry[0]['memberof']) ? $entry[0]['memberof'] : false;
      
      if($memberofArray != false)
      {
        foreach($memberofArray as $member)
        {
          switch($member)
          {
            case stripos($member, 'admin') !== false:
              $memberof = 'admin';
              break;
            case stripos($member, 'manager') !== false:
              $memberof = 'manager';
              break;
            case stripos($member, 'contributor') !== false:
              $memberof = 'contributor';
              break;
            default:
              $memberof = false;  
          }
          // If user has a proper memberof, break out of the foreach loop.
          if(isset($memberof) && $memberof != false)
          {
            break;
          }
        }              
      }
      else
      {
        $memberof = false;
      }
      
      Session::put('ldap_memberof', $memberof);
      
      return($memberof);
    }



    /**
     * Write the user's login to the login_history table.
     * 
     */
    private static function logUser($username, $cn, $email, $memberof)
    {
      // Log user.
      DB::table('login_history')->insert(array(
        'username'  => $username,
        'cn'        => $cn,
        'email'     => $email,
        'memberof'  => ($memberof != false 
                          ? ucfirst($memberof) 
                          : 'No AD Entry for PIS')
      ));
    }


    public function retrieve($id)
    {
      // For Debugging purposes.

      // Using my info to authenticate.
      $username = 'rpospisil@fgoldman.com';
      $password = 'Goldman1';
      
      // FG LDAP server.
      $ldapServer='fgidc2.fgoldman.com';

      // Set the base DN.
      $baseDn = "DC=fgoldman,DC=com";
            
      // Connect to LDAP server. Returns LDAP link identifier.
      $ldapConn = ldap_connect($ldapServer);  
            
      // These options MUST be set, otherwise search will fail.
      ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
      ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0);

      // Bind.
      ldap_bind($ldapConn, $username, $password);

      // Hard coded. Change this to whomever's info you are searching for.
      $filter = '(cn=rpospisil)' . '@fgoldman.com';

      // Perform search on the authenticated user.
      $search = ldap_search($ldapConn, $baseDn, $filter);

      // Get the entry of said user.
      $entry = ldap_get_entries($ldapConn, $search);
      
      echo('<pre>');
      print_r($entry);
      echo('</pre>');
      
      ldap_unbind($ldapConn);      
    }

    
}