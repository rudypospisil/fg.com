<?php
/**
 * Automated task to pull items from NAV and store them in the local PIS database.
 * This will backup, and then clear and rewrite itself every 24 hours.
 * 
 * This NAV data in the local db will be accessed for PIS functioning.
 * This is done for expendiency. Querying the NAV server for each request is too crippling.
 *
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date June 2013
 *
 * A cron job automatically runs this task every 24 hours at midnight.
 * The task takes approximately 2 minutes.
 *
 *  MAILTO="rudypospisil@gmail.com"
 *  0 0 * * * /usr/bin/php /var/www/artisan pull_nav_data
 *
 * The command line to forcibly perform this task: '/usr/bin/php /var/www/artisan pull_nav_data'.
 *
 */

// One long procedure, here we go, go, go... 
class Pull_NAV_Data_Task 
{ 
  public function run($arguments)
  {
    // Because this is called as part of a unix cron job, all echoes will be passed to the command line and any emails sent out. They will NOT be echoed to the general user.
    //
    // I'm running a lot of try/catch blocks here in order to clarify success or failure, and prevent mishaps.
    //
    // First, backup up data in case of db error and the need to rollback.
    // Clear the local backup table of day-before-yesterday's data, reset the primary key, and insert yesterday's data.
    try
    {
      NewRequest::resetNavTable('nav_backup');   
      $backup = NewRequest::fetchNavItemListFromLocalDb('nav', 'item_no');
      for($i = 0; $i < count($backup); $i++)
      {
        DB::table('nav_backup')->insert(array(
          'item_no'             => $backup[$i]->item_no,
          'collection_code'     => $backup[$i]->collection_code,
          'product_group_code'  => $backup[$i]->product_group_code,
          'style_no'            => $backup[$i]->style_no,
          'gender_code'         => $backup[$i]->gender_code                    
        ));          
      }
      echo('Yesterday\'s data has been backed up to the "nav_backup" table. ');
    }
    catch (Exception $e)
    {
      echo "Database backup error. " . $e;
    }
    // Clear array, otherwise a "Segmentation fault (core dumped)" error occurs.
    $backup = '';


    // Set up wrapper to send http requests to NAV.
    // NTLM authentication requires this bit of hoop jumping.
    //
    // The wrapper methods are in the NTLMStream class.
    // another account: define('USERPWD', 'fgoldman\webservice:Fredgold1949');
    define('USERPWD', 'pisservice:Jewel1949');

    // Unregister the current HTTP wrapper 
    stream_wrapper_unregister('http'); 
    // Register the new HTTP wrapper 
    stream_wrapper_register('http', 'NTLMStream') or die("Failed to register protocol");
    
    // Set the NAV Webservice URI. 
    $baseURI  = 'http://fgi-dev-sql.fgoldman.com:7047/DynamicsNAV/WS/';
    $wsdl     = $baseURI . 'TEST-FGI/Codeunit/PIS';
    
    // Need this to quell Laravel.
    error_reporting(0);
    
    // Instantiate Soap Client which is extended by the NTLMSoapClient class. 
    $client = new NTLMSoapClient($wsdl);
    
    /*
    // Options needed for debugging.
    $client = new NTLMSoapClient($wsdl, array('trace' => 1, 
                                              'exceptions' => true, 
                                              'cache_wsdl' => WSDL_CACHE_NONE
                                              ));
    */

    // Set up object to pass to NAV.
    $goldmanAppPISXMLObject = new stdClass();
    $goldmanAppPISXMLObject->goldmanAppPISXML = ''; 
    
    // Used for determining page load time.
    //$start_time = microtime(true);
    
    try
    {
      // Query the NAV. Returns an object with all item data.
      $itemList = $client->GoldManAppPISTest($goldmanAppPISXMLObject); 
      echo "NAV data object has been retrieved from NAV server. ";             
    }
    catch (SoapFault $fault)
    {
      echo "Fault code: {$fault->faultcode}" . "\n<br>";
      echo "Fault string: {$fault->faultstring}" . "\n<br>";
      echo("\n<br>" . "Please contact your IT Administrator. There appears to be an issue with the NAV server." . "\n<br>");
    }
    
    // Used for determining page load time. For debugging only. Comment out.
    // echo('This page was generated in ' . number_format(microtime(true) - $start_time, 2) . ' seconds.');

    // Restore the original http protocol.
    stream_wrapper_restore('http');
      
    // The WSDL shows the NAV structured as such:
    // All items are at $result->goldmanAppPISXML->CostCalculationHeader[index]      
    
    // End of NAV server querying.
    
    // All following deal with the local db.
    
    // Now, clear the current local table and insert the NAV data.
    // Note: the data comes from the NAV unsorted. We will need to sort it and reinsert.
    NewRequest::resetNavTable('nav');
    try
    {
      // Insert the NAV data into the local PIS db.
      for($i = 0; $i < count($itemList->goldmanAppPISXML->CostCalculationHeader); $i++)
      {
        if(strpos($itemList->goldmanAppPISXML->CostCalculationHeader[$i]->ItemNo, '.00') !== false)
        {
          DB::table('nav')->insert(array(
            'item_no'             => $itemList->goldmanAppPISXML->CostCalculationHeader[$i]->ItemNo,
            'collection_code'     => $itemList->goldmanAppPISXML->CostCalculationHeader[$i]->CollectionCode,
            'product_group_code'  => $itemList->goldmanAppPISXML->CostCalculationHeader[$i]->ProductGroupCode,
            'style_no'            => $itemList->goldmanAppPISXML->CostCalculationHeader[$i]->StyleNo,
            'gender_code'         => $itemList->goldmanAppPISXML->CostCalculationHeader[$i]->GenderCode                    
          ));          
        }
      }
      echo('NAV data object has been written to local table "nav". ');
    }
    catch (Exception $e)
    {
      echo "Database error. ";
    }
    // Clear object out of memory, otherwise a "Segmentation fault (core dumped)" error occurs.
    $itemList = '';
    


    // Immediately pull the data back out of the local db as an item_no ordered array.
    $sortedItemList = array();
    try
    {
      $sortedItemList = NewRequest::fetchNavItemListFromLocalDb('nav', 'item_no');

      echo('NAV data has been sorted by ItemNo. ');
    }
    catch (Exception $e)
    {
      echo "Sorting error. " . $e;
    }

    
    
    // Reinsert this sorted data.
    // This is quicker and easier than writing a sort algorithm.
    
    // Clear all data out because we are going to replace it with the sorted data.
    NewRequest::resetNavTable('nav');          
    try
    {
      // Insert the sorted NAV data into the local PIS db.
      for($i = 0; $i < count($sortedItemList); $i++)
      {
        DB::table('nav')->insert(array(
          'item_no'             => $sortedItemList[$i]->item_no,
          'collection_code'     => $sortedItemList[$i]->collection_code,
          'product_group_code'  => $sortedItemList[$i]->product_group_code,
          'style_no'            => $sortedItemList[$i]->style_no,
          'gender_code'         => $sortedItemList[$i]->gender_code                    
        ));          
      }
      echo('Sorted NAV data has been rewritten to local table "nav" . ');
    }
    catch (Exception $e)
    {
      echo "Database insert error. " . $e;
    }
    
    echo('Task completed. This process will repeat in 24 hours.');
  }
  
}