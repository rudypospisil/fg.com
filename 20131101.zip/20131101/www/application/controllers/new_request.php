<?php
/**
 * New Request controller class.
 * This is for implementing new requests.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
 
class New_request_Controller extends Base_Controller 
{


	  function __construct() 
	  {
      parent::__construct();   
    }



    public function action_index()
    {
      $loggedIn = Login::get_userLoggedIn();
      $memberOf = Login::get_userMemberof();
      
      if($loggedIn == true && ($memberOf == 'admin' || $memberOf == 'manager' || $memberOf == 'contributor'))
      {
        // Reset batching variable
        // Batching loop maintained through new_request_batch view.
        Session::put('batching', false);
        
        // Grab item list count from local db to display.
        $itemListCount = NewRequest::getItemListCount();
        
        // Grab angle options. The config file will query the db.
        $angles = Config::get('angles');
        
        // Grab priority options. The config file will query the db.
        $priorityCodes = Config::get('priority_codes');
        
        // Grab customer data. Query the db.
        $customers = Config::get('customers');
        
        $data = array(
                  'title'          => 'Creating a New Request',
                  'section'        => 'New Request',
                  'itemListCount'  => $itemListCount,
                  'angles'         => $angles,
                  'priorityCodes'  => $priorityCodes,
                  'customers'      => $customers
                );      
        
        return View::make('new_request', $data);
      }
      else
      {
        Return Redirect::to('login');
      }
    }



    public function action_nav_wait()
    {
      if(Session::get('loggedin') == true)
      {
        $data = array(
                  'title'         => 'Creating a New Request',
                  'section'       => 'New Request'
                );      
        
        return View::make('new_request_nav_wait', $data);
      }
      else
      {
        Return Redirect::to('login');
      }
    }





    public function action_submit()
    {
      $id = NewRequest::insert();
      
      //Session::put('batch_no', $id);
      Session::put('id', $id);

      $request = OpenRequests::retrieve_open_request($id);
      Session::put('batch_no', $request->batch_no);
           
      $data = array(
                'title'          => 'Request Has Been Saved.',
                'section'        => 'New Request',
                'id'             => $id,
                'request'        => $request
              );   
                 
      return View::make('new_request_success', $data);
      
    }
    
        
    
    
    public function action_add_to_batch()
    {
      Session::put('batching', true);
      
      $id = Session::get('id');

      $previousRequest = OpenRequests::retrieve_open_request($id);
      
      $previousRequestAngles = array();
      foreach(Session::get('angles') as $angle)
      {
        array_push($previousRequestAngles, $angle);
      }
      
      // Grab item list count from local db to display.
      $itemListCount = Nav::getItemListCount();
      
      // Grab angle options. The config file will query the db.
      $angles = Config::get('angles');
      
      // Grab priority options. The config file will query the db.
      $priorityCodes = Config::get('priority_codes');
      
      // Grab customer data. Query the db.
      $customers = Config::get('customers');
      
      $data = array(
                    'title'                   => 'Creating a Batched Request',
                    'section'                 => 'New Request',
                    'previousRequest'         => $previousRequest,
                    'previousRequestAngles'   => $previousRequestAngles,
                    'itemListCount'           => $itemListCount,
                    'angles'                  => $angles,
                    'priorityCodes'           => $priorityCodes,
                    'customers'               => $customers
                  );      
          
      return View::make('new_request_batch', $data);
    }   
  

  
    public function action_append_to_batch()
    {
      Session::put('batching', true);
      
      $batchNo = Input::get('batch_no');
      
      $batchMember = DB::table('open_requests')->where('batch_no', '=', $batchNo)->first();
      
      // Grab item list count from local db to display.
      $itemListCount = Nav::getItemListCount();
      
      // Grab angle options. The config file will query the db.
      $angles = Config::get('angles');
      
      // Grab priority options. The config file will query the db.
      $priorityCodes = Config::get('priority_codes');
      
      // Grab customer data. Query the db.
      $customers = Config::get('customers');
      
      $data = array(
                    'title'             => 'Creating a Batched Request',
                    'section'           => 'New Request',
                    'batchMember'       => $batchMember,
                    'itemListCount'     => $itemListCount,
                    'angles'            => $angles,
                    'priorityCodes'     => $priorityCodes,
                    'customers'         => $customers
                  );      
          
      return View::make('open_request_add_to_batch', $data);
    }   
  

  
  
    public function action_no_batch()
    {
      // Reset session variable for safety.
      Session::put('batching', false);
      // Clear out session variable. Therefore, it will need to be rebuilt upon next insert.
      // This ensures no overriding batch_nos between users.
      Session::put('batch_no', NULL);
      
      //return Controller::call('open_requests@index');

      Return Redirect::to('open_requests');
    }   




    public function action_getItemListForAjax($number)
    {
      $table = 'nav';
      $sort = 'item_no';
      
      $itemList = DB::table($table)->order_by($sort, 'asc')->skip($number)->take(100)->get();

      $itemListJSON = json_encode($itemList);
      echo($itemListJSON);
    }   


    public function action_getItemListForAutocomplete()
    {
      $table = 'nav';
      $sort = 'item_no';
      $searchString = mb_strtoupper($_GET['term']);
      $searchString = '%' . $searchString . '%';
      //$itemList = DB::table($table)->order_by($sort, 'asc')->take(5000)->get();
      $itemList = DB::table($table)->where('item_no', 'LIKE', $searchString)->order_by($sort, 'asc')->get();

      $itemListJSON = json_encode($itemList);
      echo($itemListJSON);
      //echo($_GET['term']);
    }   




    public function action_getSearchedItemListForAjax($number)
    {
      $searchString = mb_strtoupper(Input::get('term'));

      $table = 'nav';
      //$sort = 'item_no';
      
      $searchedItemList = DB::table($table)->where('item_no', 'LIKE', $searchString)->get($number);
      //$searchedItemList = DB::table($table)->take(10);
      
      $searchedItemListJSON = json_encode($searchedItemList);
      
      echo($searchedItemListJSON);
    }   


    public function action_getCustomersList()
    {
      $table = 'customers';
      $sort = 'customer';
      
      $customersList = DB::table($table)->order_by($sort, 'asc')->get();

      $customersListJSON = json_encode($customersList);
      echo($customersListJSON);
    }   

    public function action_get_customer()
    {
      $table = 'customers';
      $sort = 'customer';
      
      $customersList = DB::table($table)->order_by($sort, 'asc')->get();

      $customersListJSON = json_encode($customersList);
      echo($customersListJSON);
    }   



    public function action_checkForDuplicateItem($item)
    {
      $itemAlreadyExists = DB::table('open_requests')->where('item_no', '=', $item)->first();
      if($itemAlreadyExists)
      {
        $itemAlreadyExistsJSON = json_encode($itemAlreadyExists);
        echo($itemAlreadyExistsJSON);
        }   
    }   



    
}	
