<?php
/**
 * Debug controller class.
 * This is for production debugging purposes only.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
class Debug_Controller extends Base_Controller 
{


	  function __construct() 
	  {
      parent::__construct();   
    }



    public function action_index()
    {
    }




    public function action_changePrivileges()
    {
      $memberof = Input::get('memberof');
      
      switch($memberof)
      {
        case 'a':
          SESSION::put('ldap_memberof', 'admin');
          SESSION::put('pageSuffix', '_admin');
          break;
        case 'm':
          SESSION::put('ldap_memberof', 'manager');
          SESSION::put('pageSuffix', '_manager');
          break;
        case 'c':
          SESSION::put('ldap_memberof', 'contributor');
          SESSION::put('pageSuffix', '_contributor');
          break;        
      }
      return Redirect::back();
    }




}	
