<?php
/**
 * Open Request controller class.
 * This is for implementing new requests.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
class Open_requests_Controller extends Base_Controller 
{


	  function __construct() 
	  {
      parent::__construct();   
    }



    public function action_index()
    {
      // See if valid logged in user. If false, function will send user to login page. If true, code proceeds forward.
      $loggedIn = Login::get_isUserLoggedIn();
      $memberof = Login::get_userMemberof();
      
      if($loggedIn == true)
      {
        $sort = Input::has('sort') ? Input::get('sort') : 'batch_no';
        $all = Input::has('all') ? Input::get('all') : false;
                        
        if($memberof == 'photog')
        {
          $filter = array(0 => 'photographer', 1 => '=', 2 => Session::get('ldap_cn'));
        }
        else
        {
          $filter = array(0 => 'id', 1 => '>', 2 => '0');
        }
        $totalCount = OpenRequests::get_count('open_requests', $filter);
        // If there are no records in db, the following block will be passed over.  
        if($totalCount > 0)
        {
          $totalPages = ceil($totalCount / 20);
          
          // Create array of sequential page numbers.
          // This will be passed into the select dropdown.
          for($i = 1; $i <= $totalPages; $i++)
          {
            $pageArray[$i] = $i;
          }
                    
          $page = Input::has('p') ? Input::get('p') : 1;
          $prevPage = ($page > 1) ? ($page - 1) : $page;
          $nextPage = ($page < ($totalCount/20)) ? ($page + 1) : $page;
          $startNumber = (($page * 20) - 19);
          $endNumber = (($page * 20) > $totalCount) ? $totalCount : ($page * 20);
          
          $projectBatchNum = Input::has('project') ? Input::get('project') : 'ALL';
          // Create array of projects.
          // This will be passed into the select dropdown.
          $projects = DB::table('open_requests')
                          ->group_by('batch_no')
                          ->order_by('batch_no', 'asc')
                          ->get(array('batch_no', 'project_title'));
          
          $projectsDropdown = array();
          $projectsDropdown[0] = 'ALL';
          for($i=0; $i < count($projects); $i++)
          {
            $mashup = $projects[$i]->batch_no . ' / ' . $projects[$i]->project_title;
            $projectsDropdown[$mashup] = $mashup;
          }
          
          switch($all)
          {
            case true:
              $requests = OpenRequests::retrieve_all($sort, $filter);
              break;
            case false:
              $requests = OpenRequests::retrieve_20($sort, $page, $filter);
              break;
            default:
              $requests = OpenRequests::retrieve_20($sort, $page, $filter);
              break;
          }
           
          $projectMenuString = Input::get('string');
          
          if($projectBatchNum != 'ALL')
          {
            $requests = DB::table('open_requests')
                          ->where('batch_no', '=', $projectBatchNum)
                          ->get();          
          } 
                 
          $data = array(
                    'title'       => 'Current Open Requests',
                    'section'     => 'Open Requests',
                    'requests'    => $requests,
                    'totalCount'  => $totalCount,
                    'pageArray'   => $pageArray,
                    'page'        => $page,
                    'prevPage'    => $prevPage,
                    'nextPage'    => $nextPage,
                    'startNumber' => $startNumber,
                    'endNumber'   => $endNumber,
                    'sort'        => $sort,
                    'all'         => $all,
                    'projects'    => $projectsDropdown,
                    'projectMenuString'    => $projectMenuString
                    );
                    
          $view = Input::get('view');
          
          switch($view)
          {
            case 'singles':
              return View::make('open_requests', $data);
              break;            
            case 'batches':
              $request = OpenRequests::retrieve_batches_as_groups($sort);                       
              $data = array(
                        'title'     => 'Viewing as Batches',
                        'section'   => 'Open Requests',
                        'request'   => $request
                        );                                 
              return View::make('open_requests_batches', $data);
              break;            
            default:
              return View::make('open_requests', $data);
              break;
              
          }        
        }
        else
        // No data in db.
        {
          $data = array(
                    'title'     => 'There are no Open Requests Available.',
                    'section'   => 'Open Requests'
                    );                                 
          return View::make('open_requests', $data);
        } 
      }
      else
      // Error catch for invalid users.
      {
        Return Redirect::to('login');
      }
    }





    public function action_view_single()
    {
      $id = Input::get('id');

      $request = OpenRequests::retrieve_open_request($id);

      $batchRequest = OpenRequests::retrieve_batch($id);      
      
      // Bring in the values for dropdowns. (Changing menus items done in the admin panel and saved to db.)
      $statusDropdown         = Config::get('status_codes');
      $angleDropdown          = Config::get('angles');
      $photographerDropdown   = Config::get('photographers');
      $priorityDropdown       = Config::get('priority_codes');
      
      $data = array(
                'title'                   => 'Viewing an Open Request',
                'section'                 => 'Open Requests',
                'request'                 => $request,
                'batchRequest'            => $batchRequest,
                'statusDropdown'          => $statusDropdown,
                'angleDropdown'           => $angleDropdown,
                'photographerDropdown'    => $photographerDropdown,
                'priorityDropdown'        => $priorityDropdown
                );
      
      return View::make('view_request', $data);
    }
    
 
 
    

    public function action_view_as_grouped_batches()
    {
      $request = OpenRequests::retrieve_batches_as_groups();
      
      $data = array(
                'title'    => 'Viewing as Batches',
                'section'  => 'Open Requests',
                'request'  => $request
                );
      
      return View::make('open_requests_batches', $data);
    }
    
    

    public function action_edit()
    {
      $loggedIn = Login::get_userLoggedIn();
      $memberOf = Login::get_userMemberof();
      
      if($loggedIn == true)
      {
        $id = Input::get('id');
        //$update = Input::get('update');
  
        if($request = OpenRequests::retrieve_open_request($id))
        {
          $batchNo = $request->batch_no;

          $batchRequest = OpenRequests::retrieve_batch($batchNo);      
          $countOfBatchedOpenRequests = count($batchRequest);
          
          // Bring in the values for dropdowns. (Changing menus items done in the admin panel and saved to db.)
          $statusDropdown         = Config::get('status_codes');
          $angleDropdown          = Config::get('angles');
          $photographerDropdown   = Config::get('photographers');
          $priorityDropdown       = Config::get('priority_codes');
          $typesDropdown          = Config::get('types');
          $fileTypesDropdown      = Config::get('file_types');
          $customersDropdown      = Config::get('customers');
          
          
          // The following series of conditionals is to protect old requests that use deprecated names/values no longer in the admin db.
          // If you don't, old data will get written over by the dropdown default.
          // If need be, add deprecated status to array so they will appear in dropdown.
          if(!in_array($request->status, $statusDropdown))
          {
            $statusDropdown[$request->status] = $request->status;
          }
          // If need be, add deprecated angle to array so they will appear in dropdown.
          if(!in_array($request->angle, $angleDropdown))
          {
            $angleDropdown[$request->angle] = $request->angle;
          }
          // If need be, add deprecated photographer to array.
          if(!in_array($request->photographer, $photographerDropdown))
          {
            $photographerDropdown[$request->photographer] = $request->photographer;
          }
          //
          
          // Now, let's get any completed requests that are part of this batch.
          $completedRequests = CompletedRequests::retrieve_completed_requests($batchNo);          
          $countOfBatchedCompletedRequests  = count($completedRequests);
                   
          $data = array(
                    'title'                   => 'Viewing an Open Request',
                    'section'                 => 'Open Requests',
                    'request'                 => $request,
                    'batchRequest'            => $batchRequest,
                    'memberOf'                => $memberOf,
                    'statusDropdown'          => $statusDropdown,
                    'angleDropdown'           => $angleDropdown,
                    'photographerDropdown'    => $photographerDropdown,
                    'priorityDropdown'        => $priorityDropdown,
                    'typesDropdown'           => $typesDropdown,
                    'fileTypesDropdown'       => $fileTypesDropdown,
                    'customersDropdown'       => $customersDropdown,
                    'completedRequests'       => $completedRequests,
                    'countOfBatchedOpenRequests'      => $countOfBatchedOpenRequests,
                    'countOfBatchedCompletedRequests' => $countOfBatchedCompletedRequests
                    );
            
          $page = 'edit_request_' . $memberOf;
          return View::make($page, $data);
        }
        else
        // Request doesn't exist.
        {
          Return Redirect::to('open_requests');
        }
      }
      else
      {
        Return Redirect::to('login');
      }
    }
    
    

    public function action_update()
    {
      $id = Input::get('id');
      
      // This function updates the requests according to privileges and returns whether it is completed or not.
      $completed = OpenRequests::update_openRequest($id);   

      // Status returned.
      // Request is completed/closed. Take user to Completed Requests module.
      if($completed == true)
      {
        $request = CompletedRequests::retrieve_completed_request($id);
      }
      // Request still open.
      else
      {
        $request = OpenRequests::retrieve_open_request($id);      
        //Return Redirect::to('open_requests/edit?id=' . $id);
      }
      $data = array(
                'title'     => 'Editing an Open Request',
                'section'   => 'Open Requests',
                'request'   => $request,
                'update'    => 'success'
                );
      //$page = 'open_requests/edit?id=' . $id;
      $page = 'edit_request_success';
      return View::make($page, $data);
    }


    public function action_updateOpenRequest()
    {
      $id = Input::get('id');
      
      // This function updates the requests according to privileges and returns whether it is completed or not.
      
      $userInputs = Data::get_userInputs();
      $userMemberof = Login::get_userMemberof();
      $payload = Data::set_updateRequestPayload($userMemberof, $userInputs);
      
      if($payload['status'] == 'Completed')
      {
        OpenRequests::move_member('open_requests', 'completed_requests', $id, $payload);
        $response = CompletedRequests::get_member('completed_requests', array(0 => 'id', 1 => $id));
      }
      else
      {
        OpenRequests::update_member('open_requests', array(0 => 'id', 1 => $id), $payload);
        $response = OpenRequests::get_member('open_requests', array(0 => 'id', 1 => $id));
      }
        
      $data = array(
                'title'     => 'Editing an Open Request',
                'section'   => 'Open Requests',
                'request'   => $response,
                'update'    => 'success'
                );
      $page = 'edit_request_success';
      return View::make($page, $data);
    }

    
    public function action_group_by($whichColumn)
    {
      $filterList = OpenRequests::group_by($whichColumn);
      
      //header("Content-type: text/javascript");
      return $filterList;
    }


    public function action_change_batch_due_date($batch_no)
    {
      OpenRequests::change_batch_due_date($batch_no);
      Return Redirect::to('open_requests?view=batches');
    }


    public function action_get_customersList()
    {
      $table = 'customers';
      $sort = 'customer';
      
      $customersList = DB::table($table)->order_by($sort, 'asc')->get();

      $customersListJSON = json_encode($customersList);
      echo $customersListJSON;
    }   

    public function action_get_customer()
    {
      $id = Input::get('id');
      $table = 'open_requests';
      
      $openRequest = DB::table($table)->where('id', '=', $id)->get();

      $openRequestJSON = json_encode($openRequest);
      echo $openRequestJSON;
    }   

    public function action_ajax_getOpenRequest($id)
    {
      $table = 'open_requests';
      
      $openRequest = DB::table($table)->where('id', '=', $id)->get();

      $openRequestJSON = json_encode($openRequest);
      echo $openRequestJSON;
    }   


    public function action_updateBatchMembers()
    {
      if(isset($_POST['batchMembersToUpdate']))
      {
        $batchMembersToUpdate = explode('|', $_POST['batchMembersToUpdate']);
        // Remove the last index because it is empty due to the last pipe.
        array_pop($batchMembersToUpdate);
        $batchMembersCount = count($batchMembersToUpdate);
      }
      else
      {
        $batchMembersCount = 0;
      }

      $batchNo = Input::get('batch_no');
      $payload = array();
      if(Input::has('batchProjectTitle'))
      {
        $payload['project_title'] = Input::get('batchProjectTitle');        
        OpenRequests::update_member('open_requests', array(0 => 'batch_no', 1 => $batchNo), $payload);
        CompletedRequests::update_member('completed_requests', array(0 => 'batch_no', 1 => $batchNo), $payload);
      }
      if(Input::has('batchPriority') && Input::get('batchPriority') != 0)
      {
        $payload['priority'] = Input::get('batchPriority');
      }
      if(Input::has('batchStatus') && Input::get('batchStatus') != '0')
      {
        $payload['status'] = Input::get('batchStatus');
      }
      if(Input::has('batchDueDate'))
      {
        $payload['due_date'] = Input::get('batchDueDate');
      }
      if(Input::has('batchPhotographer'))
      {
        $payload['photographer'] = Input::get('batchPhotographer');
      }
      if(Input::has('batchShootDate'))
      {
        $payload['shoot_date'] = Input::get('batchShootDate');
      }

      if($batchMembersCount != 0)
      {
        for($i = 0; $i<$batchMembersCount; $i++)
        {
          if(isset($payload['status']) && $payload['status'] == 'Completed')
          {
            OpenRequests::move_member('open_requests', 'completed_requests', $batchMembersToUpdate[$i], $payload);
          }
          else
          {
            OpenRequests::update_member('open_requests', array(0 => 'id', 1 => $batchMembersToUpdate[$i]), $payload);
          }
        }
      }
      // Grab the current batch title in case it wasn't edited.
      // Check for completed status. Otherwise, if there are no more open requests, an exception will be thrown.
      if(isset($payload['status']) && $payload['status'] == 'Completed')
      {
        $obj = DB::table('completed_requests')->where('batch_no', '=', $batchNo)->first('project_title');
      }
      else
      {
        $obj = DB::table('open_requests')->where('batch_no', '=', $batchNo)->first('project_title');
      }
      
      $payload['project_title'] = $obj->project_title;
      $data = array(
          'title'       => 'Batch Edit Successful',
          'section'     => 'Open Requests',
          'batchEdits'  => $payload,
          'update'      => 'success'
          );
      //$page = 'open_requests/edit?id=' . $id;
      $page = 'edit_batch_success';
      return View::make($page, $data);
    }   



    public function action_deleteBatchMembers($batch_no)
    {
      $batchNo = Input::get('batch_no');
      $batchMembersToDelete = explode('|', $_POST['batchMembersToDelete']);
      // Remove the last index because it is empty due to the last pipe.
      array_pop($batchMembersToDelete);
      $batchMembersCount = count($batchMembersToDelete);
      
      for($i = 0; $i<$batchMembersCount; $i++)
      {
        //OpenRequests::delete_member_byId('open_requests', $batchMembersToDelete[$i]);
        OpenRequests::delete_member('open_requests', array(0 => 'id', 1 => $batchMembersToDelete[$i]));
      }
      $openRequest = DB::table('open_requests')->where('batch_no', '=', $batchNo)->first();
      
      if($openRequest)
      {
        // Take the user back to the first member of the batch.
        $url = 'open_requests/edit?id=' . $openRequest->id . '#tabs-2';
      }
      else
      {
        // The only member of the batch was deleted, so take the user to the general open requests page.
        $url = 'open_requests';
      }
      
      Return Redirect::to($url);
      //print_r($batchMembersToDelete);

    }   



}	
