<?php
/**
 * tests only
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
 
class Test_Controller extends Base_Controller
{

    public function action_index()
    {
    }


    public function action_thumb()
    {

      // Setup the maximium width and height for the finished image
      $max_width = "150";
      $max_height = "150";
      
      // Directory containing the images
      $dir = '/var/www/public/filestore/upload'; 
      
      // Select all jpg, png and gif images
      foreach (glob($dir."{*.jpg,*.png,*.gif}",GLOB_BRACE ) as $filename) 
      {
        // Get the image size for use in the code
        $size=GetImageSize( $filename );
        
        $new_name = "thumb_".$filename;
        
        $cmd = " $filename -thumbnail $max_widthx$max_height ";
        exec("convert $cmd $new_name"); 
      }      
    }



}