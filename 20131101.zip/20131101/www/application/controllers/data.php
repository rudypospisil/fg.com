<?php
/**
 * Data controller class.
 * This is for the data controller panel.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
 
class Data extends Base_Controller
{
    public function action_index()
    {
  
    }         

    public function action_get_customersList()
    {
      $table = 'customers';
      $sort = 'customer';
      
      $customersList = DB::table($table)->order_by($sort, 'asc')->get();

      $customersListJSON = json_encode($customersList);
      echo($customersListJSON);
    }   

    public function action_get_customer()
    {
      $id = Input::get('id');
      
      $table = 'open_requests';
      
      $customer = DB::table($table)->where('id', '=', $id)->get();

      $customerJSON = json_encode($customer);
      echo($customerJSON);
    }   


}