<?php
/**
 * Admin controller class.
 * This is for the admin controller panel.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
 
class Admin_Controller extends Base_Controller
{

    public function action_index()
    {
      if((Session::get('loggedin') == true) && (Session::get('privileges') == 'admin'))
      {
        $columns = Admin::get_column_names();
        
        $adminData = Admin::retrieve_all();
                  
        $data = array(
                  'title'         => 'Admin Panel',
                  'section'       => 'Admin Panel',
                  'columns'       => $columns,
                  'app_specs'     => $adminData['app_specs'],
                  'status_codes'  => $adminData['status_codes'],
                  'angles'        => $adminData['angles'],
                  'photographers' => $adminData['photographers'],
                  'customers'     => $adminData['customers']
                );      
        
        return View::make('admin', $data);
      }
      else
      {
        Return Redirect::to('login');
      }      
    }


    public function action_uploadDoc($editing)
    {
      //echo basename($_FILES['uploadDoc']['name']);
      //exit;

      $targetPath = '/filestore/specs/';
      $targetPath = $targetPath . basename($_FILES['uploadDoc']['name']);
      if(move_uploaded_file($_FILES['uploadDoc']['tmp_name'], $targetPath)) 
      {
        echo "The file " . basename($_FILES['uploadDoc']['name']) . " has been uploaded";
      } 
      else
      {
        echo "There was an error uploading the file, please try again!";
        print_r($_FILES['uploadDoc']['error']);
      }
      // The hash tag will be parsed by JavaScript to determine proper tab to activate.
      //Return Redirect::to('admin#tab-' . $editing . 's');
    }
    
    public function action_update($editing)
    {
      // Grab ID to update proper row in db.
      $id = Input::get('id');
      
      // Update row in db.
      Admin::update($editing, $id);      
      
      // The hash tag will be parsed by JavaScript to determine proper tab to activate.
      Return Redirect::to('admin#tab-' . $editing . 's');
    }
    
    public function action_add_entry($editing)
    {
      // Insert new empty row in db.
      Admin::add_entry($editing);

      // The hash tag will be parsed by JavaScript to determine proper tab to activate.
      Return Redirect::to('admin#tab-' . $editing . 's');
    }

    public function action_add_child_entry($editing, $app)
    {
      // Insert new empty row in db.
      Admin::add_child_entry($editing, $app);

      // The hash tag will be parsed by JavaScript to determine proper tab to activate.
      Return Redirect::to('admin#tab-' . $editing . 's');
    }

    public function action_delete($editing)
    {
      // Grab ID to delete proper row in db.
      $id = Input::get('id');
      
      // Delete row in db.
      Admin::delete($editing, $id);      

      // The hash tag will be parsed by JavaScript to determine proper tab to activate.
      Return Redirect::to('admin#tab-' . $editing . 's');
    }



}