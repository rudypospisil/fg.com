<?php
/**
 * Login controller class.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
class Login_Controller extends Base_Controller 
{

	  function __construct() 
	  {
      parent::__construct();   
    }


    public function action_index()
    {
      return View::make('home.login')
  		    ->with('title', 'Welcome to the FG PIS. Please Log In.');
    }



    /**
     * Query Active Directory with login credentials.
     *
     * This checks first to see if user is a valid AD member.
     * Then, checks to see which privileges said user has.
     *
     * Admin
     * Manager
     * Contributer (this is the default is privileges not found.)
     * Photographer
     * 
     * @param string $ldapServer URL of AD server.
     * @return 
     */
    public function action_checkLogin()
    {
      $userdata = array(
        'username'  => Input::get('username'),
        'password'  => Input::get('password')
      );
      
      // Using my own LDAP class.
      // path = /var/www/application/libraries/rpldapauth.php
      if(Auth::attempt($userdata))
      {
        Session::put('username', $userdata['username']);
        Session::put('loggedin', true);

        Session::put('privileges', 'admin'); // Hard coded for now. This needs to be tied into LDAP.

        // Set page suffix variable according to a user's privileges.
        // This will be tacked on to routes dependent on privileges.
        switch(Session::get('privileges'))
        {
          case 'admin':
            Session::put('pageSuffix', '_admin');
            break;
          case 'manager':
            Session::put('pageSuffix', '_manager');
            break;
          case 'contributor':
            Session::put('pageSuffix', '_contributor');
            break;
          case 'photog':
            Session::put('pageSuffix', '_photog');
            break;
          default:
            Session::put('pageSuffix', '_contributor');
            break;
        }
        return Redirect::to('home');
      }
      else
      {
        Session::put('username', '');
        Session::put('loggedin', false);
        Session::put('loginError', true);

        Session::put('privileges', '');
        Session::put('pageSuffix', '');

        Return Redirect::to('login');
      }
    }



    /**
     * Log the user out.
     *
     * @param string .
     * @return 
     */
    public function action_logout()
    {
      Login::logout();
      Return Redirect::to('home');
    }
      
      
      
      
    public function action_search_ldap()
    {
      $username1='CN=OTRS Search,CN=Users,DC=fgoldman,DC=com';
      $password1 = 't1ck3tsyst3m';
      
      $username2 = 'Rudy Pospisil';
      $password2 = 'Goldman1';
      
      $ldapServer='fgidc2.fgoldman.com';
      $ldapPort = 389;
      
      
      // Connect to LDAP server. Returns LDAP link identifier.
      $ldapConn = ldap_connect($ldapServer);
                  
      ldap_set_option($ldapConn, LDAP_OPT_PROTOCOL_VERSION, 3);
      ldap_set_option($ldapConn, LDAP_OPT_REFERRALS, 0);

      if($ldapConn)
      {
        echo('Connection successful.<br>');

        // Bind with appropriate dn to give update access
        if($result = ldap_bind($ldapConn, $username1, $password1))
        {          
          echo('Binding successful.<br>');
                    
          $base_dn = "DC=fgoldman,DC=com";
          $filter = "(userprincipalname=otrs@fgoldman.com)";
          $justThese = array("mail", "cn", "userprincipalname");
           
          if($search = ldap_search($ldapConn, $base_dn, $filter, $justThese))
          {
            echo('Search successful.<br>');
          }
          else
          {
            echo('Search unsuccessful.<br>');
          }
          $entries = ldap_get_entries($ldapConn, $search);
              
          echo('<pre>');
            print_r($entries);
          echo('</pre>');
          
          echo(isset($entries[0]['cn']) ? ('CN=' . $entries[0]['cn'][0] . '<br>') : '');
          echo(isset($entries[0]['userprincipalname']) ? ('userprincipalname=' . $entries[0]['userprincipalname'][0] . '<br>') : '');
          echo(isset($entries[0]['mail']) ? ('Email=' . $entries[0]['mail'][0] . '<br>') : '');
          
        }
        else
        {
          echo('fail');
        } 
        ldap_close($ldapConn);
      }
    }
    
    
    
}	
