<?php
/**
 * Completed Requests controller class.
 * This is for completed requests.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
class Completed_requests_Controller extends Base_Controller 
{


	  function __construct() 
	  {
      parent::__construct();   
    }




    public function action_index()
    {
      $loggedIn = Login::get_userLoggedIn();
      $memberof = Login::get_userMemberof();

      if($loggedIn == true)
      {
        $sort = Input::has('sort') ? Input::get('sort') : 'batch_no';
        $all = Input::has('all') ? Input::get('all') : false;
                        
        if($memberof == 'photog')
        {
          $filter = array(0 => 'photographer', 1 => '=', 2 => Session::get('ldap_cn'));
        }
        else
        {
          $filter = array(0 => 'id', 1 => '>', 2 => '0');
          
        }
        $totalCount = CompletedRequests::get_count('completed_requests', $filter);
        
        // If the Completed Requests table is empty, skip this block.
        if($totalCount > 0)
        { 
          $totalPages = ceil($totalCount / 20);
          
          // Create array of sequential page numbers.
          // This will be passed into the select dropdown.
          for($i = 1; $i <= $totalPages; $i++)
          {
            $pageArray[$i] = $i;
          }
          
 
          $page = Input::has('p') ? Input::get('p') : 1;
          $prevPage = ($page > 1) ? ($page - 1) : $page;
          $nextPage = ($page < ($totalCount/20)) ? ($page + 1) : $page;
          $startNumber = (($page * 20) - 19);
          $endNumber = (($page * 20) > $totalCount) ? $totalCount : ($page * 20);
          
          $projectBatchNum = Input::has('project') ? Input::get('project') : 'ALL';
          // Create array of projects.
          // This will be passed into the select dropdown.
          $projects = DB::table('open_requests')
                          ->group_by('batch_no')
                          ->order_by('batch_no', 'asc')
                          ->get(array('batch_no', 'project_title'));
          
          $projectsDropdown = array();
          $projectsDropdown[0] = 'ALL';
          for($i=1; $i < count($projects); $i++)
          {
            $mashup = $projects[$i]->batch_no . ' / ' . $projects[$i]->project_title;
            $projectsDropdown[$mashup] = $mashup;
          }

          switch($all)
          {
            case true:
              $requests = CompletedRequests::retrieve_all($sort, $filter);
              break;
            case false:
              $requests = CompletedRequests::retrieve_20($sort, $page, $filter);
              break;
            default:
              $requests = CompletedRequests::retrieve_20($sort, $page, $filter);
              break;
          }
                  
          $projectMenuString = Input::get('string');
          
          if($projectBatchNum != 'ALL')
          {
            $requests = DB::table('open_requests')
                          ->where('batch_no', '=', $projectBatchNum)
                          ->get();          
          } 
                 
          $data = array(
                    'title'       => 'Completed Requests',
                    'section'     => 'Completed Requests',
                    'requests'    => $requests,
                    'totalCount'  => $totalCount,
                    'pageArray'   => $pageArray,
                    'page'        => $page,
                    'prevPage'    => $prevPage,
                    'nextPage'    => $nextPage,
                    'startNumber' => $startNumber,
                    'endNumber'   => $endNumber,
                    'sort'        => $sort,
                    'all'         => $all,
                    'projects'    => $projectsDropdown,
                    'projectMenuString'    => $projectMenuString
                    );
                    
          $view = Input::get('view');
          
          switch($view)
          {
            case 'singles':
              return View::make('completed_requests', $data);
              break;            
            case 'batches':
              $request = CompletedRequests::retrieve_batches_as_groups();                       
              $data = array(
                        'title'     => 'Viewing as Batches',
                        'section'   => 'Completed Requests',
                        'request'   => $request
                        );                                 
              return View::make('completed_requests_batches', $data);
              break;            
            default:
              return View::make('completed_requests', $data);
              break;
              
          }        
        }
        else
        // No data in db.
        {
          $data = array(
                    'title'     => 'No Completed Requests Available',
                    'section'   => 'Completed Requests'
                    );                                 
          return View::make('completed_requests', $data);
        } 
      }        
      else
      {
        Return Redirect::to('login');
      }
    }


    public function action_ajax_getCompletedRequest($id)
    {
      $table = 'completed_requests';
      
      $completedRequest = DB::table($table)->where('id', '=', $id)->get();

      $completedRequestJSON = json_encode($completedRequest);
      echo $completedRequestJSON;
    }   


}	