<?php
/**
 * Nav controller class.
 * This is for the admin controller panel.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
 
class Nav_Controller extends Base_Controller
{
    public function action_index()
    {
    // Get local table ready...
    Nav::emptyNavTable();   

    // Set up wrapper to send http requests to NAV.
    // NTLM authentication requires this bit of hoop jumping.
    //
    // The wrapper methods are in the NTLMStream class.
    // another account: define('USERPWD', 'fgoldman\webservice:Fredgold1949');
    define('USERPWD', 'pisservice:Jewel1949');

    // Unregister the current HTTP wrapper 
    stream_wrapper_unregister('http'); 
    // Register the new HTTP wrapper 
    stream_wrapper_register('http', 'NTLMStream') or die("Failed to register protocol");
    
    // Set the NAV Webservice URI. 
    $baseURI  = 'http://fgi-dev-sql.fgoldman.com:7047/DynamicsNAV/WS/';
    $wsdl     = $baseURI . 'TEST-FGI/Codeunit/PIS';
    
    // Need this to quell Laravel.
    error_reporting(0);
    
    // Instantiate Soap Client which is extended by the NTLMSoapClient class. 
    $client = new NTLMSoapClient($wsdl);
    
    /*
    // Options needed for debugging.
    $client = new NTLMSoapClient($wsdl, array('trace' => 1, 
                                              'exceptions' => true, 
                                              'cache_wsdl' => WSDL_CACHE_NONE
                                              )
                                            );
    */

    // Set up object to pass to NAV.
    $goldmanAppPISXMLObject = new stdClass();
    $goldmanAppPISXMLObject->goldmanAppPISXML = ''; 
    
    // Used for determining page load time.
    //$start_time = microtime(true);
    
    try
    {
      // Query the NAV. Returns an object with all item data.
      $result = $client->GoldManAppPISTest($goldmanAppPISXMLObject);              
    }
    catch (SoapFault $fault)
    {
      echo "Fault code: {$fault->faultcode}" . "\n<br>";
      echo "Fault string: {$fault->faultstring}" . "\n<br>";
      echo("\n<br>" . "Please contact your IT Administrator. There appears to be an issue with the NAV server." . "\n<br>");
    }
    
    // Used for determining page load time.
    // echo('This page was generated in ' . number_format(microtime(true) - $start_time, 2) . ' seconds.');

    // Restore the original http protocol.
    stream_wrapper_restore('http');
   
    
    // The WSDL shows the NAV structured as such:
    // All items are at $result->goldmanAppPISXML->CostCalculationHeader[index]      
    
    try
    {
      for($i = 0; $i < count($result->goldmanAppPISXML->CostCalculationHeader); $i++)
      {
        DB::table('nav')->insert(array(
          'item_no'             => $result->goldmanAppPISXML->CostCalculationHeader[$i]->ItemNo,
          'collection_code'     => $result->goldmanAppPISXML->CostCalculationHeader[$i]->CollectionCode,
          'product_group_code'  => $result->goldmanAppPISXML->CostCalculationHeader[$i]->ProductGroupCode,
          'style_no'            => $result->goldmanAppPISXML->CostCalculationHeader[$i]->StyleNo,
          'gender_code'         => $result->goldmanAppPISXML->CostCalculationHeader[$i]->GenderCode                    
        ));          
      }
    }
    catch (Exception $e)
    {
      echo "Database error. Please hit your back button.";
    }
    //echo('<pre>');
    //var_dump($result);
    //echo('</pre>');
    
    echo('NAV data has been pulled.');
    
    $sortedResult = NewRequest::fetchNavItemListFromLocalDb('nav', 'item_no');
    //echo('<pre>');
    //print_r($sortedResult);
    //echo('</pre>');

    // Clear all data out because we are going to replace it with the sorted data.
    Nav::emptyNavTable();
    
    echo('Local NAV table has been cleared.');
    
    for($i = 0; $i < count($sortedResult); $i++)
    {
      DB::table('nav')->insert(array(
        'item_no'             => $sortedResult[$i]->item_no,
        'collection_code'     => $sortedResult[$i]->collection_code,
        'product_group_code'  => $sortedResult[$i]->product_group_code,
        'style_no'            => $sortedResult[$i]->style_no,
        'gender_code'         => $sortedResult[$i]->gender_code                    
      ));          
    }

  echo('Local NAV Table has been cleared and updated with the most current NAV Server data.');
  
  }         


}