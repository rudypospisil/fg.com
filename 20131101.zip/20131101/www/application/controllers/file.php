<?php
/**
 * File controller class.
 * This is for file uploads and other file functions.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
 
class File_Controller extends Base_Controller
{

    public function action_index()
    {
    }



    public function action_upload()
    {
      File::upload();
    }



}