<?php
/**
 * Imaging Utility controller class.
 * This is for implementing new requests.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
class Imaging_utility_Controller extends Base_Controller 
{

	  function __construct() 
	  {
      parent::__construct();   
    }



    public function action_index()
    {
      $data = ImagingUtility::setDataArray(0);
      
      return View::make('imaging_utility', $data);    
    }



    public function action_loadJSON()
    {
      $items = DB::table('completed_requests')->order_by('item_no', 'asc')->get();
      //$json = json_encode($items);
      //return($json);
      return Response::json(array('json' => $items));
    }
    

 
    
    
    /**
     * Standalone panel.
     * 
     */
     
    
    
    public function action_choose_apps()
    {
      if(Input::has('apps'))
      {
        // Set up the data object, sending the $nextPage attribute.
        $data = ImagingUtility::setDataArray(2);
                        
        return View::make('imaging_utility', $data);
      }
      else
      {
        echo('You didn\'t select anything. Please hit your browser\'s back button, and try again, please.');
      }
    }



    public function action_set_formulas()
    {
      // Set up the data object, sending the $nextPage attribute.
      $data = ImagingUtility::setDataArray(3);
      
      $pisFileName = Input::get('TEST_item_no') . '-' . Input::get('TEST_style_no') . '-' . Input::get('TEST_angle');
      $data['pisFileName'] = $pisFileName;
      
      return View::make('imaging_utility', $data);
    }



    public function action_upload_standalone()
    {      
      $input = Input::get();
      
      $rules = array(
        'picture' => 'image'
      );
      
      $validation = Validator::make($input, $rules);
      
      if($validation->fails())
      {
        //return $validation->errors;
        echo('You didn\'t select a proper image file. Please hit your browser\'s back button, and try again, please.');        
      }
      else
      {
        
        $pisFileName = Input::get('TEST_pisFileName');

        $originalFileName   = Input::file('image.name');
        $thumbnailName150px = $pisFileName . '_150px_tb' . '.jpg';
        $thumbnailName300px = $pisFileName . '_300px_tb' . '.jpg';
        $thumbnailPath150px = '/var/www/public/filestore/thumbnails/150px/';
        $thumbnailPath300px = '/var/www/public/filestore/thumbnails/300px/';
        $pisFileExt         = 'psd';
        $pisFilePath = '/var/www/public/filestore/psd/';
        
        $payload = array(
                    'pis_no'              =>  0,
                    'original_file_name'  =>  $originalFileName,
                    'pis_file_name'       =>  $pisFileName,
                    'pis_file_ext'        =>  $pisFileExt,
                    'file_location'       =>  $pisFilePath
                  );

        // Insert the file's info into the filestore table.
        DB::table('filestore')->insert($payload);

        $pisFileName .= ('.' . $pisFileExt);

        Input::upload('image', $pisFilePath, $pisFileName);        

        exec('convert ' . $pisFilePath.$pisFileName . '[0] -strip -thumbnail 150x150 ' . $thumbnailPath150px.$thumbnailName150px);

        exec('convert ' . $pisFilePath.$pisFileName . '[0] -strip -thumbnail 300x300 ' . $thumbnailPath300px.$thumbnailName300px);

        // Set up the data object, sending the $nextPage attribute.
        $data = ImagingUtility::setDataArray(4);
        $data['pisFileName'] = $pisFileName;
        $data['thumbnailName150px'] = $thumbnailName150px;
  
        return View::make('imaging_utility', $data);        
      }
    }   


    public function action_upload_completed_request()
    {      
      $pisFileName = '';
      $input = Input::get();
      
      $rules = array(
        'picture' => 'image'
      );
      
      $validation = Validator::make($input, $rules);
      
      if($validation->fails())
      {
        //return $validation->errors;
        echo('You didn\'t select a proper image file. Please hit your browser\'s back button, and try again, please.');        
      }
      else
      {
        $id = Input::get('availableItem');

        foreach($_POST['apps'] as $app)
        {
          $naming_formula = DB::table('app_specs')->where('application','=', $app)->only('naming_formula');
          
          $namingFormulaArray = explode(',', $naming_formula);
          
          foreach($namingFormulaArray as $parameter)
          {
            if($parameter == '-')
            {
              $pisFileName .= '-';
            }
            else
            {
              $pisFileName .= DB::table('completed_requests')->where('id','=', $id)->only($parameter);;
            }
          }
        }
        
        $originalFileName   = Input::file('image.name');
        $thumbnailName150px = $pisFileName . '_150px_tb' . '.jpg';
        $thumbnailName300px = $pisFileName . '_300px_tb' . '.jpg';
        $thumbnailPath150px = '/var/www/public/filestore/thumbnails/150px/';
        $thumbnailPath300px = '/var/www/public/filestore/thumbnails/300px/';
        $pisFileExt         = 'psd';
        $pisFilePath = '/var/www/public/filestore/psd/';
        
        $payload = array(
                    'pis_no'              =>  $id,
                    'original_file_name'  =>  $originalFileName,
                    'pis_file_name'       =>  $pisFileName,
                    'pis_file_ext'        =>  $pisFileExt,
                    'file_location'       =>  $pisFilePath
                  );

        // Insert the file's info into the filestore table.
        DB::table('filestore')->insert($payload);

        $pisFileName .= ('.' . $pisFileExt);

        Input::upload('image', $pisFilePath, $pisFileName);        

        exec('convert ' . $pisFilePath.$pisFileName . '[0] -strip -thumbnail 150x150 ' . $thumbnailPath150px.$thumbnailName150px);

        exec('convert ' . $pisFilePath.$pisFileName . '[0] -strip -thumbnail 300x300 ' . $thumbnailPath300px.$thumbnailName300px);

        // Set up the data object, sending the $nextPage attribute.
        $data = ImagingUtility::setDataArray(4);
        $data['pisFileName'] = $pisFileName;
        $data['thumbnailName150px'] = $thumbnailName150px;
  
        return View::make('imaging_utility', $data);
      }
    }   



    public function action_continue()
    {      
      // Set up the data object, sending the $nextPage attribute.
      $data = ImagingUtility::setDataArray(0);

      return View::make('imaging_utility_standalone', $data);
    }   



    public function action_clear()
    {
      Input::clear();
      
      Input::upload('image', 'public/filestore/upload/', Input::file('image.name'));
      
      //ImagingUtility::upload_file();
    }   

    public function post_upload()
    {
        $input = Input::all();
        $user = Auth::user();
        $image = Input::file('headshot');
        $layer = PHPImageWorkshop\ImageWorkshop::initFromPath($image['tmp_name']);

        $dirPath = path('storage').'/uploads/thumbnails/avatars/';
        $filename = Auth::user()->id. uniqid($image['size']) .'.jpg';
        $createFolders = true;
        $backgroundColor = null; // transparent, only for PNG (otherwise it will be white if set null)
        $imageQuality = 100; // useless for GIF, usefull for PNG and JPEG (0 to 100%)
        $layer->resizeInPixel(377, 310, true, 0, 0, 'MM');
        $layer->save($dirPath, $filename, $createFolders, $backgroundColor, $imageQuality);

        $user->headshot = $filename;
        $user->headshot_file = $image['name'];
        $user->save();

        return Redirect::to('/');

    }

}