<?php
/**
 * Home controller class.
 * This is the landing page for all users - the default controller.
 * We'll send the user on from here.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */

class Home_Controller extends Base_Controller 
{

	  function __construct() 
	  {
      parent::__construct();   
    }


    public function action_index()
    {
      if(Session::get('loggedin') == true)
      {
    		return View::make('home.home')
    		    ->with('title', 'Welcome to the FG PIS');        
      }
      else
      {
        // This should already be zeroed out, but I'm just being anal.
        Session::forget('ldap_cn');
        Session::put('loggedin', false);
        
    		return View::make('home.login')
    		    ->with('title', 'Welcome to the FG PIS. Please Log In.');
  		}
    }



    /**
     * Query Active Directory with login credentials.
     *
     * @param string $ldapServer URL of AD server.
     * @return 
     */
    public function action_checkLogin()
    {
      $userdata = array(
        'username'  => Input::get('username'),
        'password'  => Input::get('password')
      );
      
      // Using my own LDAP class.
      if(Auth::attempt($userdata))
      {
        //Session::put('username', $userdata['username']);
        // CN & Mail SESSION varibles set in library function.
        Session::put('loggedin', true);

        Session::put('privileges', 'admin'); // Hard coded for now. This needs to be tied into LDAP.

        // Set page suffix variable according to a user's privileges.
        // This will be tacked on to routes dependent on privileges.
        switch(Session::get('privileges'))
        {
          case 'admin':
            Session::put('pageSuffix', '_admin');
            break;
          case 'manager':
            Session::put('pageSuffix', '_manager');
            break;
          case 'contributer':
            Session::put('pageSuffix', '_contributer');
            break;
          default:
            Session::put('pageSuffix', '_contributer');
            break;
        }
        return Redirect::to('home');
      }
      else
      {
        Session::forget('ldap_cn');
        Session::forget('ldap_email');
        Session::put('loggedin', false);
        Session::put('loginError', true);

        Session::put('privileges', '');
        Session::put('pageSuffix', '');

        Return Redirect::to('login');
      }
    }

    
}