<?php
/**
 * Open Request controller class.
 * This is for implementing new requests.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
class Open_requests_test_Controller extends Base_Controller 
{


	  function __construct() 
	  {
      parent::__construct();   
    }



    public function action_index()
    {
      if(Session::get('loggedin') == true)
      {
        $sort = Input::has('sort') ? Input::get('sort') : 'batch_no';
        $all = Input::has('all') ? Input::get('all') : false;
                        
        $totalCount = DB::table('open_requests')->count();        
        $totalPages = ceil($totalCount / 20);
        
        // Create array of sequential page numbers.
        // This will be passed into the select dropdown.
        for($i = 1; $i <= $totalPages; $i++)
        {
          $pageArray[$i] = $i;
        }
        
        $page = Input::has('p') ? Input::get('p') : 1;
        $prevPage = ($page > 1) ? ($page - 1) : $page;
        $nextPage = ($page < ($totalCount/20)) ? ($page + 1) : $page;
        $startNumber = (($page * 20) - 19);
        $endNumber = (($page * 20) > $totalCount) ? $totalCount : ($page * 20);
        
        switch($all)
        {
          case true:
            $requests = OpenRequests::retrieve_all($sort);
            break;
          case false:
            $requests = OpenRequests::retrieve_20($sort, $page);
            break;
          default:
            $requests = OpenRequests::retrieve_20($sort, $page);
            break;
        }
        
                
        $data = array(
                  'title'       => 'Current Open Requests',
                  'section'     => 'Open Requests',
                  'requests'    => $requests,
                  'totalCount'  => $totalCount,
                  'pageArray'   => $pageArray,
                  'page'        => $page,
                  'prevPage'    => $prevPage,
                  'nextPage'    => $nextPage,
                  'startNumber' => $startNumber,
                  'endNumber'   => $endNumber,
                  'sort'        => $sort,
                  'all'         => $all
                  );
        
                  
        $view = Input::get('view');
        
        switch($view)
        {
          case 'singles':
            return View::make('open_requests_test', $data);
            break;            
          case 'batches':
            $request = OpenRequests::retrieve_batches_as_groups();                       
            $data = array(
                      'title'     => 'Viewing as Batches',
                      'section'   => 'Open Requests',
                      'request'   => $request
                      );                                 
            return View::make('open_requests_batches', $data);
            break;            
          default:
            return View::make('open_requests_test', $data);
            break;
            
        }        
      }
      else
      {
        Return Redirect::to('login');
      }
    }





    public function action_view_single()
    {
      $id = Input::get('id');

      $request = OpenRequests::retrieve_open_request($id);

      $batchRequest = OpenRequests::retrieve_batch($id);      
      
      // Bring in the status codes for dropdown. (Changing menus items done in this file.)
      $statusDropdown = Config::get('status_codes');
      
      $data = array(
                'title'           => 'Viewing an Open Request',
                'section'         => 'Open Requests',
                'request'         => $request,
                'batchRequest'    => $batchRequest,
                'statusDropdown'  => $statusDropdown
                );
      
      return View::make('view_request', $data);
    }
    
 
 
    

    public function action_view_as_grouped_batches()
    {
      $request = OpenRequests::retrieve_batches_as_groups();
      
      $data = array(
                'title'           => 'Viewing as Batches',
                'section'         => 'Open Requests',
                'request'         => $request
                );
      
      return View::make('open_requests_batches', $data);
    }
    
    

    public function action_edit()
    {
      $id = Input::get('id');

      if($request = OpenRequests::retrieve_open_request($id))
      {
        $batchRequest = OpenRequests::retrieve_batch($id);      
        
        // Bring in the status codes for dropdown. (Changing menus items done in this file.)
        $statusDropdown = Config::get('status_codes');
        
        $data = array(
                  'title'           => 'Editing an Open Request',
                  'section'         => 'Open Requests',
                  'request'         => $request,
                  'batchRequest'    => $batchRequest,
                  'statusDropdown'  => $statusDropdown
                  );
        
        $page = 'edit_request' . SESSION::get('pageSuffix');
        return View::make($page, $data);
      }
      else
      {
        Return Redirect::to('open_requests');
      }
    }
    
    

    public function action_update()
    {
      $id = Input::get('id');
      
      // This function updates the requests according to privileges and returns whether it is completed or not.
      $statusCompleted = OpenRequests::update_open_request($id);

      // Status returned.
      // Request still open.
      if($statusCompleted != true)
      {
        Return Redirect::to('open_requests/edit?id=' . $id);
      }
      else
      // Request is completed/closed. Take user to Completed Requests module.
      {
        Return Redirect::to('completed_requests');
      }
    }


    public function action_group_by($whichColumn)
    {
      $filterList = OpenRequests::group_by($whichColumn);
      
      //header("Content-type: text/javascript");
      return($filterList);
    }

}	
