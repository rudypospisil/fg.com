<?php
/**
 * Library controller class.
 * This is for completed requests.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
class Library_Controller extends Base_Controller 
{


	  function __construct() 
	  {
      parent::__construct();   
    }



    public function action_index()
    {
      $loggedIn = Login::get_userLoggedIn();
      if($loggedIn == true)
      {
        $data = array(
                  'title'     => 'Frederick Goldman Digital Asset Library',
                  'section'   => 'Library',
                  'requests'  => ''
                  );
        
        return View::make('library', $data);
      }
      else
      {
        Return Redirect::to('login');
      }
    }


    public function action_product_detail()
    {
      if(Session::get('loggedin') == true)
      {
        $id = Input::get('id');
        
        $fileDetails    = Library::get_file_details($id);
        
        $productDetails = Library::get_product_details($id);
        
        $data = array(
                  'title'           => 'Frederick Goldman Digital Asset Library',
                  'section'         => 'Library',
                  'fileDetails'     => $fileDetails,
                  'productDetails'  => $productDetails,
                  'id'              => $id
                  );
        
        
        
        return View::make('product_detail', $data);                
      }
      else
      {
        Return Redirect::to('login');
      }
    }

}	