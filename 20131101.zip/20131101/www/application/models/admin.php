 <?php
/**
 * Admin Control Panel model.
 * 
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
 
 
class Admin
{
  
  public static function get_column_names()
  {
    // Run raw query to get column names.
    $columns = DB::query('show columns from app_specs');
  
    return $columns;
  }
  
  
  
/**
 * Retrieve all admin editable data from db.
 * 
 * @return $adminData Object
 *
 */
  public static function retrieve_all()
  {
    $app_specs      = DB::table('app_specs')
                            ->order_by('application', 'asc')
                            ->get();
    $status_codes   = DB::table('status_codes')
                            ->order_by('status_code', 'asc')
                            ->get();
    $angles         = DB::table('angles')
                            ->order_by('angle', 'asc')
                            ->get();
    $photographers  = DB::table('photographers')
                            ->order_by('full_name', 'asc')
                            ->get();
    $customers      = DB::table('customers')
                            ->order_by('customer', 'asc')
                            ->get();
    
    for($i = 0; $i < count($app_specs); $i++)
    {
      $app_specs[$i]->application = html_entity_decode($app_specs[$i]->application);
    }
    
    $adminData = array('app_specs'      => $app_specs, 
                       'status_codes'   => $status_codes, 
                       'angles'         => $angles, 
                       'photographers'  => $photographers,
                       'customers'      => $customers
                       );
    
    return $adminData;
  }  



/**
 * Update user inputted changes from Admin view.
 * 
 * @return none
 *
 */
  public static function update($editing, $id)
  {
    // Set up the payload to insert.
    // Most will only be updating a single field. The default case will handle those.
    switch($editing)
    {
      case 'app_spec':
        $payload = array(
                    'application'      => Input::get('application'),
                    'naming_formula'   => Input::get('naming_formula'),
                    'file_location'    => Input::get('file_location'),
                    'width'            => Input::get('width'),
                    'height'           => Input::get('height'),
                    'type'             => Input::get('type')                                
                    );
        break;
      case 'customer': 
        $fileStorePath = '/var/www/public/filestore';         
        $payload = array(
                    'customer'         => Input::get('customer'),
                    'comment'          => Input::get('comment'),
                    'file_path'        => $fileStorePath,
                    'width'            => Input::get('width'),
                    'height'           => Input::get('height'),
                    'file_type'        => Input::get('file_type')                               
                    );
        break;
      case 'photographer':
        $username = strtolower(substr(Input::get('first_name'), 0, 1) . Input::get('last_name'));
        $password = self::randomPassword();
        $firstName = ucfirst(Input::get('first_name'));
        $lastName = ucfirst(Input::get('last_name'));
        $fullName = $firstName . ' ' . $lastName;
        $payload = array(
                    'first_name'         => $firstName,
                    'last_name'          => $lastName,
                    'full_name'          => $fullName,
                    'email'              => strtolower(Input::get('email')),
                    'username'           => $username,
                    'password'           => $password
                    );
        break;
      default:
        $payload = array($editing => Input::get($editing));
        break;
    }    

    // The table is the plural version of $editing.
    $table = $editing . 's';
    
    DB::table($table)
          ->where('id', '=', $id)
          ->update($payload);  
  }  


public static function randomPassword() {
    $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 5; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}


/**
 * Add a blank entry to user selected table. User will then input data and update.
 * 
 * @return none
 *
 */
  public static function add_entry($editing)
  {
    // The table is the plural version of $editing.
    $table = $editing . 's';
    
    DB::table($table)->insert(array($editing => ''));
  }  


/**
 * Add a blank entry to user selected table. User will then input data and update.
 * 
 * @return none
 *
 */
  public static function add_child_entry($editing, $app)
  {
    // The table is the plural version of $editing.
    $table = $editing . 's';
    
    // The app names have spaces which the system encodes.
    // Decoding them doesn't seem to work, there I'm using a string replace to resolve the issue.
    $app = str_replace('%20', ' ', $app);
    
    $result = DB::table($table)->where('application', '=', $app)->first();
    
    DB::table($table)->insert(array('application'     => $app,
                                    'naming_formula'  => !empty($result->naming_formula) ? $result->naming_formula : '',
                                    'file_location'   => !empty($result->file_location) ? $result->file_location : '',
                                    'width'           => '',
                                    'height'          => ''
                                    ));
  }  


/**
 * Delete user selected row.
 * 
 * @return none
 *
 */
  public static function delete($editing, $id)
  {
    // The table is the plural version of $editing.
    $table = $editing . 's';
    
    DB::table($table)->delete($id);
  }  



}