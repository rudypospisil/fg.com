 <?php
/**
 * Library model.
 * 
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
 
 
class Library
{
  
  public static function get_file_details($id)
  {    
    $fileDetails = DB::table('filestore')->find($id);
    
    return $fileDetails;
  }


  public static function get_product_details($id)
  {
    $pis_no = DB::table('filestore')->where('id', '=', $id)->only('pis_no');
    
    $productDetails = DB::table('completed_requests')->find($pis_no);
    
    return $productDetails;
  }


}