<?php
/**
 * Functions model.
 * This model executes various misc functions.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
class Functions
{

  /**
   * Generic function to grab the "group by" column values for the javascript filter menus.
   * The table and a column name MUST be passed in.
   * An AJAX call is made to this function in order to populate a JSON object.
   * 
   * @author Rudy Pospisil <rudy@rudypospisil.com>
   * @package Frederick Goldman Photo Image System
   * @version 1.0.0
   * @date April 2013
   */
  public static function group_by($table, $whichColumn)
  {
    $result = DB::table($table)
                    ->group_by($whichColumn)
                    ->get();
    
    $i = 0;
    foreach($result as $item)
    {
      $filterList[$i] = $item->$whichColumn;
      $i++;
    }
    echo json_encode($filterList);
  } 
  
  
  
   
}