<?php
/**
 * Imaging Utility model.
 * This model performs db functions for the open requests module.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
 
 
class ImagingUtility
{
  

    public static function loadJSON()
    {
      $items = DB::table('completed_requests')->order_by('item_no', 'asc')->get();
      $json = json_encode($items);
      return($json);
    }
    
    

  public static function retrieve_app_specs()
  {
    $appSpecs = DB::table('app_specs')
                  ->order_by('application', 'asc')
                  ->get();
                   
    // Loop through and create an array of the naming formula variables.
    for($i = 0; $i < count($appSpecs); $i++)
    {
      $appSpecs[$i]->namingFormulaArray = explode(',', $appSpecs[$i]->naming_formula);
    }
    
    return($appSpecs); 
  }
  
  
  /**
   * Standalone panel.
   * 
   */
    public static function setDataArray($nextPage)
    {
      $id               = Input::get('id');
      
      $requests         = CompletedRequests::retrieve_all('item_no');
      
      $completedRequest = CompletedRequests::retrieve_completed_request($id);
      
      $json             = ImagingUtility::loadJSON();
    
      $appSpecs         = ImagingUtility::retrieve_app_specs();

      $userApps         = Input::get('apps');
            
      $data = array(
                'title'             => 'Imaging Utility',
                'section'           => 'Imaging Utility',
                'requests'          => $requests,
                'json'              => $json,
                'id'                => $id,
                'completedRequest'  => $completedRequest,
                'appSpecs'          => $appSpecs,
                'userApps'          => $userApps,
                'page'              => $nextPage
                );
      
      return $data;
    }
    


}