<?php
/**
 * Login model class.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date July 2013
 */
class Login 
{

  // Getter for the logged in user's privileges. Defaults to NULL if invalid user.
  public static function get_userPrivileges()
  {
    $userPrivileges = Session::get('privileges', NULL);
    return $userPrivileges;
  }

  public static function get_userMemberof()
  {
    $memberof = (Session::has('ldap_memberof') && Session::get('ldap_memberof') != false) 
      ? Session::get('ldap_memberof')
      : false;
    return $memberof;
  }

    
  public static function get_userLoggedIn()
  {
    $loggedIn = (Session::has('loggedin') && Session::get('loggedin') != false) 
      ? Session::get('loggedin')
      : false;
    return $loggedIn;
  }

    
  public static function get_isUserLoggedIn()
  {
    if(Session::has('loggedin') && Session::get('loggedin') != false) 
    {
      $loggedIn = true;
      return $loggedIn;
    }
    else
    {
      $loggedIn = false;
      self::logout();
      return $loggedIn;
    }
  }


  public static function get_userName()
  {
    if(Session::has('ldap_cn') && Session::get('ldap_cn') != false)
    {
      $user = Session::get('ldap_cn');
    }
    else
    {
      self::logout();
    }
    return $user;
  }


  /**
   * Log the user out.
   *
   * @param string .
   * @return 
   */
  public static function logout()
  {
    Session::forget('loginError');
    Session::forget('loggedin');
    Session::forget('username');
    Session::forget('memberof');
    Session::forget('privileges');
    Session::forget('pageSuffix');
    Session::forget('ldap_cn'); 
    Session::forget('ldap_email'); 
    Session::forget('ldap_memberof'); 
  }
      
    /**
     * Invalid login.
     *
     * @param string .
     * @return 
     */
    public static function invalidLogin()
    {
      Session::put('username', '');
      Session::put('loggedin', false);
      Session::put('loginError', true);

      Session::put('privileges', '');
      Session::put('pageSuffix', '');

      Return Redirect::to('home');
    }
      
    
}