<?php
/**
 * Nav Model class.
 * This is for the admin controller panel.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date June 2013
 */
 
class Nav
{
    public static function buildLocalTableWithItemsFromNav()
    {
      //define('USERPWD', 'fgoldman\webservice:Fredgold1949');
      define('USERPWD', 'pisservice:Jewel1949');
 
      // Unregister the current HTTP wrapper 
      stream_wrapper_unregister('http'); 
      // Register the new HTTP wrapper 
      stream_wrapper_register('http', 'NTLMStream') or die("Failed to register protocol");
      
      // Set the NAV Webservice URI. 
      $baseURI  = 'http://fgi-dev-sql.fgoldman.com:7047/DynamicsNAV/WS/';
      $wsdl     = $baseURI . 'TEST-FGI/Codeunit/PIS';
      
      // Need this to quell Laravel.
      error_reporting(0);
      
      // Instantiate Soap Client 
      $client = new NTLMSoapClient($wsdl);
      
      /*
      // Options set for debugging.
      $client = new NTLMSoapClient($wsdl, array('trace' => 1, 
                                                'exceptions' => true, 
                                                'cache_wsdl' => WSDL_CACHE_NONE
                                                )
                                              );
      */

      // Set up object to pass to NAV.
      $goldmanAppPISXMLObject = new stdClass();
      $goldmanAppPISXMLObject->goldmanAppPISXML = ''; 
      
      // Used for determining page load time.
      //$start_time = microtime(true);
      
      try
      {
        // Query the NAV. Returns an object with all item data.
        $result = $client->GoldManAppPISTest($goldmanAppPISXMLObject);              
      }
      catch (SoapFault $fault)
      {
        echo "Fault code: {$fault->faultcode}" . "\n<br>";
        echo "Fault string: {$fault->faultstring}" . "\n<br>";
        echo("\n<br>" . "Please contact your IT Administrator. There appears to be an issue with the NAV server." . "\n<br>");
      }
      
      // Used for determining page load time.
      // echo('This page was generated in ' . number_format(microtime(true) - $start_time, 2) . ' seconds.');

      // Restore the original http protocol.
      stream_wrapper_restore('http');
     
      // The WSDL shows the NAV structured as such:
      // All items are at $result->goldmanAppPISXML->CostCalculationHeader[index]      
      
      try
      {
        for($i = 0; $i < count($result->goldmanAppPISXML->CostCalculationHeader); $i++)
        {
          DB::table('nav')->insert(array(
            'item_no'             => $result->goldmanAppPISXML->CostCalculationHeader[$i]->ItemNo,
            'collection_code'     => $result->goldmanAppPISXML->CostCalculationHeader[$i]->CollectionCode,
            'product_group_code'  => $result->goldmanAppPISXML->CostCalculationHeader[$i]->ProductGroupCode,
            'style_no'            => $result->goldmanAppPISXML->CostCalculationHeader[$i]->StyleNo,
            'gender_code'         => $result->goldmanAppPISXML->CostCalculationHeader[$i]->GenderCode                    
          ));          
        }
      }
      catch (Exception $e)
      {
        echo "Database error. Please hit your back button.";
      }
      
      $sortedResult = fetchItemListFromLocalDb('nav', 'item_no');
      for($i = 0; $i < count($sortedResult->goldmanAppPISXML->CostCalculationHeader); $i++)
      {
        DB::table('nav')->insert(array(
          'item_no'             => $sortedResult->goldmanAppPISXML->CostCalculationHeader[$i]->ItemNo,
          'collection_code'     => $$sortedResult->goldmanAppPISXML->CostCalculationHeader[$i]->CollectionCode,
          'product_group_code'  => $sortedResult->goldmanAppPISXML->CostCalculationHeader[$i]->ProductGroupCode,
          'style_no'            => $sortedResult->goldmanAppPISXML->CostCalculationHeader[$i]->StyleNo,
          'gender_code'         => $sortedResult->goldmanAppPISXML->CostCalculationHeader[$i]->GenderCode                    
        ));          
      }      
    }
    
    
    
  public static function fetchNavItemListFromLocalDb($table, $sort)
  {
    $itemList = DB::table($table)->order_by($sort, 'asc')->get();
    return($itemList);
  }


  
  public static function resetNavTable($table)
  {
    // I've purposely hardcoded the table so as to prevent accidental deletion of a table caused by the wrong parameter passed.
    // Empty the table of the previous evening's data set.
    DB::table($table)->delete();
    // Reset the primary key auto increment back to 1.
    DB::query('ALTER TABLE `' . $table . '` AUTO_INCREMENT = 1;');   
  }


    public static function getItemListCount()
    {
      $itemList = DB::table('nav')->get();
      $itemListCount = count($itemList);
      $itemList = '';
      return($itemListCount);
    }


}