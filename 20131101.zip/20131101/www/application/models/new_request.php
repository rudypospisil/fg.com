 <?php
/**
 * New Request model.
 * This model performs db functions for the open requests module.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
 
 
class NewRequest
{
  public $id;
    
  public static function insert()
  {      
    
    $customerName         = 'NA';
    $customerFileType     = 'NA';
    $customerFileWidth    = 'NA';
    $customerFileHeight   = 'NA';
    //$customerComment      = 'NA';
    
    switch(Input::get('type'))
    {
      case 'Prototype':
        break;
      case 'Production':
        break;
        // Check for duplicate item no.
      case 'Customer Request':
        $customerName         = Input::get('customerName');
        // Grab specs of chosen customer.
        // Easier to query the db, rather than pushing the javascript to php.
        $customer = DB::table('customers')->where('customer', '=', $customerName)->first();
        $customerFileType     = $customer->file_type;
        $customerFileWidth    = $customer->width;
        $customerFileHeight   = $customer->height;
        //$customerComment      = Input::get('customerFileComment');
      default:
        break;
    }
    
    
    // Grab last batch number.
    $lastBatchNo = OpenRequests::retrieve_last_batch_no();
    
    $batchNo = (Session::get('batching') == true)
      ? $lastBatchNo
      : $lastBatchNo + 1;

    DB::table('globals')->update(array('last_batch_no' => $batchNo), '=', 1);
    
    Session::put('batch_no', $lastBatchNo);
    
    // Set up variables from form.
    $projectTitle   = Input::get('projectTitle', 'None given.');
    $priority       = Input::get('priority');
    // $priority is getting its value from the index and not the chosen value.
    // Not sure why. Bandage fix - add 1.
    //$priority       += 1;
    $requester      = Session::get('ldap_cn');
    $status         = Input::get('status', 'New');
    $dueDate        = (Input::get('dueDate') == null) ? 'TBD' : Input::get('dueDate');  
    $itemNo         = (Input::has('item_no')) ? Input::get('item_no') : Input::get('item');
    $type           = Input::get('type', 'TBD');
    $emailAlerts    = Input::get('emailAlerts', 'None');      
    $notes          = Input::get('notes', 'NULL');
    $photographer   = Input::get('photographer', 'TBD');
    $shootDate      = Input::get('shootDate', 'TBD');
    
    $query    = DB::table('nav')->where('item_no', '=', $itemNo)->first();
    $styleNo  = $query->style_no;
    $brand    = $query->collection_code;
    
    // Run through the angle array in order to insert each angle as a separate request.
    $angleCount = count(Input::get('angles'));
    $angles     = Input::get('angles');
    
    // If batching, this is necessary in order to display previous choices. Easiest way.
    Session::put('angles', $angles);
    
    // Loop through the angles checkbox array
    $angleString = '';
    foreach($angles as $angle)
    {
      $angleString = $angleString . $angle . ', ';
      
      $id = DB::table('open_requests')->insert_get_id(array(
        'project_title' => $projectTitle,
        'priority'      => $priority,
        'requester'     => $requester,
        'status'        => $status,
        'due_date'      => $dueDate,
        'item_no'       => $itemNo,
        'style_no'      => $styleNo,
        'brand'         => $brand,
        'angle'         => $angle,
        'type'          => $type,
        'customer'      => $customerName,
        'file_type'     => $customerFileType,
        'file_width'    => $customerFileWidth,
        'file_height'   => $customerFileHeight,
        'email_alerts'  => $emailAlerts,      
        'notes'         => $notes,
        'batch_no'      => $batchNo,
        'photographer'  => $photographer,
        'shoot_date'    => $shootDate                    
      ));
    
      // Add data to the the history table for version history.
      // Second parameter is the notation for the "action" field.
      OpenRequests::insert_open_requests_history($id, 'origin');
    }
    
    // Now we deal with the "other" angle separately since it isn't part of the checkbox array.
    if(Input::has('anglesOther'))
    {
      $angle = Input::get('anglesOther');
      
      $id = DB::table('open_requests')->insert_get_id(array(
        'project_title' => $projectTitle,
        'priority'      => $priority,
        'requester'     => $requester,
        'status'        => $status,
        'due_date'      => $dueDate,
        'item_no'       => $itemNo,
        'style_no'      => $styleNo,
        'brand'         => $brand,
        'angle'         => $angle,
        'type'          => $type,
        'customer'      => $customerName,
        'file_type'     => $customerFileType,
        'file_width'    => $customerFileWidth,
        'file_height'   => $customerFileHeight,
        'email_alerts'  => $emailAlerts,      
        'notes'         => $notes,
        'batch_no'      => $batchNo,
        'photographer'  => $photographer,
        'shoot_date'    => $shootDate                    
      ));
      
      $angleString = $angleString . $angle;
                  
      // Add data to the the history table for version history.
      // Second parameter is the notation for the "action" field.
      OpenRequests::insert_open_requests_history($id, 'origin');
      
    }
    
    // Remove last comma.
    $angleString = substr($angleString, 0, -2);
    
    DB::table('globals')->update(array('angles' => $angleString), '=', 1);
        
    return $id;
  }
  

    public static function fetchNavItemListFromLocalDb($table, $sort)
    {
      $itemList = DB::table($table)->order_by($sort, 'asc')->get();
      return($itemList);
    }


      
    public static function getItemListCount()
    {
      $itemList = DB::table('nav')->get();
      $itemListCount = count($itemList);
      $itemList = '';
      return($itemListCount);
    }


      
    public static function fetchItemListAjax()
    {
      // Currently testing in controller only.
      // Don't use this!!!!
      
      $table = 'nav';
      $sort = 'item_no';
      
      $itemList = DB::table($table)->order_by($sort, 'asc')->take(100)->get();

      echo('<script>console.log("testc");</script>');
      $itemListJSON = json_encode($itemList);
      echo('<script>console.log(' . $itemListJSON . ');</script>');
      echo($itemListJSON);
    }


      
  public static function resetNavTable($table)
  {
    // I've purposely hardcoded the table so as to prevent accidental deletion of a table caused by the wrong parameter passed.
    // Empty the table of the previous evening's data set.
    DB::table($table)->delete();
    // Reset the primary key auto increment back to 1.
    DB::query('ALTER TABLE `' . $table . '` AUTO_INCREMENT = 1;');   
  }



  public static function checkForDuplicateItem($item)
  {
    $itemAlreadyExists = DB::table('open_requests')->where('item_no', '=', $item)->first();
    if($itemAlreadyExists)
    {
      $itemAlreadyExistsJSON = json_encode($itemAlreadyExists);
      echo($itemAlreadyExistsJSON);
    }   
  }





}