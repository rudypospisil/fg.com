 <?php
/**
 * Config model.
 * 
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date July 2013
 */
 
 
class Config
{
  
  public static function get_dropdownValues($configFile)
  {
    // Bring in the values for dropdowns. (Changing menus items done in the admin panel and saved to db.)
    $dropdownArray = Config::get($configFile);
    return $dropdownArray; 
  }


}