<?php
/**
 * Completed Requests model.
 * This model performs db functions for the open requests module.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
 
 
class CompletedRequests
{
  

  public static function get_count($table, $filter)
  {
    $totalCount = DB::table($table)
                        ->where($filter[0], $filter[1], $filter[2])
                        ->count();
    return $totalCount;
  }




  public static function retrieve_all($sortBy, $filter)
  {
    $requests = DB::table('completed_requests')
                  ->where($filter[0], $filter[1], $filter[2])
                  ->order_by($sortBy, 'asc')
                  ->get();
  
    return $requests;
  }
  
  
  
  // Retrieve a single completed request.
  public static function retrieve_completed_request($id)
  {
    $completedRequest = DB::table('completed_requests')
                              ->where('id_open_request', '=', $id)
                              ->first();
  
    return $completedRequest;
  }
  
  
  
  public static function retrieve_20($sortBy, $page, $filter)
  {
    $skip = $page > 1 ? (($page - 1) * 20) : 0;
    
    $requests = DB::table('completed_requests')
                    ->where($filter[0], $filter[1], $filter[2])
                    ->order_by($sortBy, 'asc')
                    ->skip($skip)
                    ->take(20)
                    ->get();
  
    return $requests;
  }
  


  
  public static function retrieve_batch($id)
  {
    $request = DB::table('completed_requests')
                    ->find($id);

    $batchNo = $request->batch_no;

    $batchRequest = DB::table('completed_requests')
                          ->where('batch_no', '=', $batchNo)
                          ->get();
      
    return $batchRequest;
  }



  public static function retrieve_completed_requests($batchNo)
  {
    $completedRequests = DB::table('completed_requests')
                              ->where('batch_no', '=', $batchNo)
                              ->get();
      
    return $completedRequests;
  }


  
  
  public static function retrieve_batches_as_groups()
  {
    $groupedBatchesParent = array();
    
    $request = DB::table('completed_requests')->order_by('batch_no', 'asc')->get();
    
    $count = count($request);
    
    $parent = 0;
    $child = 0;
    $next = 1;
    foreach($request as $row)
    {
      $groupedBatchesParent[$parent][$child] = $row;
      if($request[$next]->batch_no == $row->batch_no)
      {
        $child++;        
      }
      else
      {
        $parent++;
        $child = 0;
      }
      if($next >= $count-1)
      {
        $next = $count - 1;
      }
      else
      {
        $next++;        
      }      
    }
  return($groupedBatchesParent);  
  }
  
    
  
  public static function retrieve_last_batch_no()
  {
    $request = DB::table('completed_requests')
                  ->order_by('batch_no', 'desc')
                  ->take(1)
                  ->get('batch_no');
    
    foreach($request as $row)
    {
      $lastBatchNo = $row->batch_no;
    }
        
    // This ternary needed to protect against an error if a table has no records.
    return (isset($lastBatchNo) ? $lastBatchNo : 1);
  }


  // Copy member data in existing table.
  public static function get_member($table, $where)
  {
    $member = DB::table($table)
      ->where($where[0], '=', $where[1])
      ->first();
    return $member;
  }  

  // Update member in existing table.
  public static function update_member($table, $where, $payload)
  {
    DB::table($table)
      ->where($where[0], '=', $where[1])
      ->update($payload);
  }  

  // Insert member to table.
  public static function insert_member($table, $payload)
  {
    DB::table($table)->insert($payload);
  }  

  
  public static function update_open_request($id)
  {
    // Build array with the row data.
    $payload = array(
                  'requester'           => Session::get('username'),
                  'status'              => Input::get('status'),
                  'due_date'            => Input::get('dueDate'),
                  'item_no'             => Input::get('itemNo'),
                  'style_no'            => Input::get('styleNo'),
                  'brand'               => Input::get('brand'),
                  'angle_3q'            => Input::get('angle_3q'),
                  'angle_flat'          => Input::get('angle_flat'),
                  'angle_front'         => Input::get('angle_front'),
                  'angle_o'             => Input::get('angle_o'),
                  'angle_top'           => Input::get('angle_top'),
                  'type'                => Input::get('type'),
                  'customer'            => Input::get('customer'),
                  'file_type'           => Input::get('fileType'),
                  'size'                => Input::get('size'),
                  'photographer'        => Input::get('photographer'),
                  'shoot_date'          => Input::get('shootDate'),      
                  'email_alerts'        => Input::get('emailAlerts'),      
                  'notes'               => Input::get('notes'),
                  'misc'                => Input::get('misc'),
                  'reference'           => Input::get('reference'),
                  'batch_no'            => Input::get('batchNo')           
                  );

    DB::table('completed_requests')
          ->where('id', '=', $id)
          ->update($payload);
  }
  


  public static function insert_open_requests_history($id)
  {
    // Grab row before it gets updated.
    // We're going to copy it to the history table.
    $request = OpenRequests::retrieve_open_request($id);
    
    // Build array with the row data.
    $history = array(
                  'id_open_request'     => $id,
                  'modified_by'         => Session::get('username'),
                  'requester'           => $request->requester,
                  'original_timestamp'  => $request->timestamp_created,
                  'status'              => $request->status,
                  'due_date'            => $request->due_date,
                  'item_no'             => $request->item_no,
                  'style_no'            => $request->style_no,
                  'brand'               => $request->brand,
                  'angle'               => $request->angle,
                  'type'                => $request->type,
                  'customer'            => $request->customer,
                  'file_type'           => $request->file_type,
                  'size'                => $request->size,
                  'photographer'        => $request->photographer,
                  'shoot_date'          => $request->shoot_date,      
                  'email_alerts'        => $request->email_alerts,      
                  'notes'               => $request->notes,
                  'misc'                => $request->misc,
                  'reference'           => $request->reference,
                  'batch_no'            => $request->batch_no           
                  );

    DB::table('open_requests_history')->insert($history);
    
  }
  
  
}