<?php
/**
 * Open Requests model.
 * This model performs db functions for the open requests module.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date February 2013
 */
 
 
class OpenRequests
{
  

  public static function get_count($table, $filter)
  {
    $totalCount = DB::table($table)->where($filter[0], $filter[1], $filter[2])->count();
    return $totalCount;
  }


  public static function retrieve_all($sortBy, $filter)
  {
    $direction = ($sortBy == 'priority') ? 'dsc' : 'asc';
    $requests = DB::table('open_requests')
                    ->order_by($sortBy, $direction)
                    ->where($filter[0], $filter[1], $filter[2])
                    ->get();
  
    return $requests;
  }



  
  public static function retrieve_20($sortBy, $page, $filter)
  {
    $direction = ($sortBy == 'priority') ? 'desc' : 'asc';
    $skip = $page > 1 ? (($page - 1) * 20) : 0;
    
    $requests = DB::table('open_requests')
                    ->where($filter[0], $filter[1], $filter[2])
                    ->order_by($sortBy, $direction)
                    ->skip($skip)
                    ->take(20)
                    ->get();
  
    return $requests;
  }
  


  
  
  // Retrieve a single open request.
  public static function retrieve_open_request($id)
  {
    $openRequest = DB::table('open_requests')
                    ->find($id);
  
    return $openRequest;
  }
  
  
  
  
  public static function retrieve_batch($batchNo)
  {
    $batchRequest = DB::table('open_requests')
                        ->where('batch_no', '=', $batchNo)
                        ->get();
      
    return $batchRequest;
  }
  
  
  
  
  public static function retrieve_batches_as_groups($sortBy)
  {
    $direction = ($sortBy == 'priority') ? 'desc' : 'asc';
    $groupedBatchesParent = array();
    
    $request = DB::table('open_requests')
                    ->order_by($sortBy, $direction)
                    ->get();
    
    $count = count($request);
    
    $parent = 0;
    $child = 0;
    $next = 1;
    foreach($request as $row)
    {
      $groupedBatchesParent[$parent][$child] = $row;
      if($request[$next]->batch_no == $row->batch_no)
      {
        $child++;        
      }
      else
      {
        $parent++;
        $child = 0;
      }
      if($next >= $count-1)
      {
        $next = $count - 1;
      }
      else
      {
        $next++;        
      }      
    }
  return($groupedBatchesParent);  
  }
  
  
  
  
  public static function retrieve_last_batch_no()
  {
    $lastBatchNo = DB::table('globals')
                    ->where('id', '=', 1)
                    ->only('last_batch_no');
    
    // This ternary needed to protect against an error if a table has no records.
    return (isset($lastBatchNo) ? $lastBatchNo : 1);
  }


  public static function retrieve_last_batch_no_old()
  {
    $request = DB::table('misc')
                  ->order_by('id', 'desc')
                  ->take(1)
                  ->get('last_batch_no');
    
    foreach($request as $row)
    {
      $lastBatchNo = $row->last_batch_no;
    }
        
    // This ternary needed to protect against an error if a table has no records.
    return (isset($lastBatchNo) ? $lastBatchNo : 1);
  }



  
  public static function update_open_request($id)
  {
    $userInputs     = Data::get_userInputs();
    $userMemberof   = Login::get_userMemberof();

    // Build array for update insertation according to the user's privileges. Also, send the user input data.
    $payload = Data::set_updateRequestPayload($userMemberof, $userInputs);
        
    if($userMemberof != NULL) // Safety check.
    {
      // User is an admin or manager. Note to self: need to make these generic, associate with a table.
      if($userMemberof == 'admin' || $userMemberof == 'manager')
      {            
        if($userInputs->status == 'Completed')
        {
          // Insert history into the history table.
          self::insert_open_requests_history($id, 'completed');
          
          // Copy data over to the completed table.
          DB::table('completed_requests')
              ->insert($payload);
          
          // Remove data from the open requests table.
          DB::table('open_requests')
              ->where('id', '=', $id)
              ->delete();
          
        // Redundant variable. I just wanted to be clear for anyone else reading this code.
        $statusCompleted = true;
        return $statusCompleted;
        }
        else
        {
          // Insert history into the history table.
          self::insert_open_requests_history($id, 'updated');          
      
          DB::table('open_requests')
              ->where('id', '=', $id)
              ->update($payload);

          // Redundant variable. I just wanted to be clear for anyone else reading this code.
          $statusCompleted = false;
          return $statusCompleted;
        }        
      }
      // User has Contributor status and therefore can only update the project's status.
      elseif($userMemberof == 'contributor' || $userMemberof == 'photog')
      {
        // Get the current data from the database.
        $openRequest = Data::get_openRequest($id);
        if($userInputs->status == 'Completed')
        {          
          // The request has been completed, so we move the data to the completed_requests table. 
          $openRequestPayload           = Data::set_requestPayload($openRequest);
          // Need to change status to 'complete'.
          $openRequestPayload['status'] = $userInputs->status;

          // Insert history into the history table.
          OpenRequests::insert_open_requests_history($id, 'completed');
      
          // Move data over to the completed table.
          DB::table('completed_requests')
              ->where('id', '=', $id)
              ->insert($openRequestPayload);
          
          // Remove data from the open requests table.
          DB::table('open_requests')
              ->where('id', '=', $id)
              ->delete();
          
          // Redundant variable. I just wanted to be clear for anyone else reading this code.
          $statusCompleted = true;          
        }
        else
        {
          // Job is not completed, therefore only the status is changing.
          // and we are updating the current table. 
          
          // Only need to send the status. The Data class built the correct payload.
          DB::table('open_requests')
              ->where('id', '=', $id)
              ->update($payload);

          // Insert history into the history table.
          OpenRequests::insert_open_requests_history($id, 'updated');
      
          // Redundant variable. I just wanted to be clear for anyone else reading this code.
          $statusCompleted = false;

        }
        $data = array('statusCompleted' => $statusCompleted, 'request' => $openRequest);
          
        return $data;
      }
    }
    else
    {
      echo('A proper login has not been authenticated.');
    }
  }
  
  public static function update_openRequest($id)
  {
    $userInputs     = Data::get_userInputs();
    $userMemberof   = Login::get_userMemberof();

    // Build array for update insertation according to the user's privileges. Also, send the user input data.
    $payload = Data::set_updateRequestPayload($userMemberof, $userInputs);
        
    if($userMemberof != NULL) // Safety check.
    {
      // User is an admin or manager. Note to self: need to make these generic, associate with a table.
      switch($userMemberof)
      {
        case 'admin':
        case 'manager':
          if($userInputs->status == 'Completed')
          {
            // Insert history into the history table.
            self::insert_open_requests_history($id, 'completed');
            
            // Copy data over to the completed table.
            DB::table('completed_requests')
                ->insert($payload);
            
            // Remove data from the open requests table.
            DB::table('open_requests')
                ->where('id', '=', $id)
                ->delete();
            
          // Redundant variable. I just wanted to be clear for anyone else reading this code.
          $statusCompleted = true;
          return $statusCompleted;
          }
          else
          {
            // Insert history into the history table.
            self::insert_open_requests_history($id, 'updated');          
        
            DB::table('open_requests')
                ->where('id', '=', $id)
                ->update($payload);
  
            // Redundant variable. I just wanted to be clear for anyone else reading this code.
            $statusCompleted = false;
            return $statusCompleted;
            break;
          }        
      // User has Contributor status and therefore can only update the project's status.
      case 'contributor':
      case 'photog':
        // Get the current data from the database.
        $openRequest = Data::get_openRequest($id);
        if($userInputs->status == 'Completed')
        {          
          // The request has been completed, so we move the data to the completed_requests table. 
          $openRequestPayload           = Data::set_requestPayload($openRequest);
          // Need to change status to 'complete'.
          $openRequestPayload['status'] = $userInputs->status;

          // Insert history into the history table.
          OpenRequests::insert_open_requests_history($id, 'completed');
      
          // Move data over to the completed table.
          DB::table('completed_requests')
              ->where('id', '=', $id)
              ->insert($openRequestPayload);
          
          // Remove data from the open requests table.
          DB::table('open_requests')
              ->where('id', '=', $id)
              ->delete();
          
          // Redundant variable. I just wanted to be clear for anyone else reading this code.
          $statusCompleted = true;          
        }
        else
        {
          // Job is not completed, therefore only the status is changing.
          // and we are updating the current table. 
          
          // Only need to send the status. The Data class built the correct payload.
          DB::table('open_requests')
              ->where('id', '=', $id)
              ->update($payload);

          // Insert history into the history table.
          OpenRequests::insert_open_requests_history($id, 'updated');
      
          // Redundant variable. I just wanted to be clear for anyone else reading this code.
          $statusCompleted = false;

        }
        $data = array('statusCompleted' => $statusCompleted, 'request' => $openRequest);
          
        return $data;
        break;         
      }
    }
    else
    {
      echo('A proper login has not been authenticated.');
    }
  }
  


  public static function insert_open_requests_history($id, $action)
  {
/*
    // Grab row before it gets updated.
    // We're going to copy it to the history table.
    $request = OpenRequests::retrieve_open_request($id);
    
    // Build array with the row data.
    $history = array(
                  'id_open_request'     => $id,
                  'modified_by'         => Session::get('username'),
                  'priority'            => $request->priority,
                  'requester'           => $request->requester,
                  'original_timestamp'  => $request->timestamp_created,
                  'status'              => ($request->status) ? $request->status : 'None',
                  'due_date'            => ($request->due_date) ? $request->due_date : 'TBD',
                  'item_no'             => $request->item_no,
                  'style_no'            => $request->style_no,
                  'brand'               => $request->brand,
                  'angle'               => $request->angle,
                  'type'                => $request->type,
                  'customer'            => ($request->customer) ? $request->customer : 'NA',
                  'file_type'           => ($request->file_type) ? $request->file_type : 'NA',
                  'file_width'          => ($request->file_width) ? $request->file_width : 'NA',
                  'file_height'         => ($request->file_height) ? $request->file_height : 'NA',
                  'photographer'        => ($request->photographer) ? $request->photographer : 'TBD',
                  'shoot_date'          => ($request->shoot_date) ? $request->shoot_date : 'TBD',      
                  'email_alerts'        => ($request->email_alerts) ? $request->email_alerts : 'None',      
                  'notes'               => ($request->notes) ? $request->notes : 'None',
                  'batch_no'            => $request->batch_no,
                  'action'              => $action           
                  );

    DB::table('open_requests_history')
          ->insert($history);
*/    
  }


/**
 * Function to grab the "group by" column values for the javascript filter menus.
 * The column name MUST be passed in.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date April 2013
 */
  public static function group_by($whichColumn)
  {
    $result = DB::table('open_requests')
                          ->group_by($whichColumn)
                          ->get();
    
    $i = 0;
    foreach($result as $item)
    {
      $filterList[$i] = $item->$whichColumn;
      $i++;
    }
    echo json_encode($filterList);
  }  

  
  
  
  
  public static function change_batch_due_date($batch_no)
  {
    $inputName = 'batchDueDate_' . $batch_no;
    $newDueDate = Input::get($inputName);
    $payload = array(
                  'due_date' => $newDueDate                                
                  );

    DB::table('open_requests')
        ->where('batch_no', '=', $batch_no)
        ->update($payload);
  }  





  // Update member in existing table.
  public static function update_member($table, $where, $payload)
  {
    DB::table($table)
      ->where($where[0], '=', $where[1])
      ->update($payload);
  }  


  // Remove member from table.
  public static function delete_member($table, $where)
  {
    DB::table($table)
      ->where($where[0], '=', $where[1])
      ->delete();
  }  

  // Insert member to table.
  public static function insert_member($table, $payload)
  {
    DB::table($table)->insert($payload);
  }  


  // Copy member from table.
  public static function copy_member($table, $where)
  {
    $copiedMember = DB::table($table)
      ->where($where[0], '=', $where[1])
      ->get();
    return $copiedMember;
  }  


  // Copy member from table.
  public static function get_member($table, $where)
  {
    $member = DB::table($table)
      ->where($where[0], '=', $where[1])
      ->first();
    return $member;
  }  



  // Update member in existing table.
  // This move function assumes that fields are consistent between the two tables.
  // If the originating table has other fields that the destination table doesn't,
  //  an exception will be thrown.
  // I plan on writing some specific payload building functions.
  public static function move_member($fromTable, $toTable, $id, $payload)
  {
    self::update_member('open_requests', array(0 => 'id', 1 => $id), $payload);
    
    $copiedMember = self::copy_member('open_requests', array(0 => 'id', 1 => $id));
    
    // $copiedMember is an array of objects.
    // The objects need to be looped through and a new array needs to be built with the key/value pairs in order to be inserted into the new table.
    $newPayload = array();
    foreach($copiedMember as $member)
    {
      foreach($member as $key => $value)
      {
        $newPayload[$key] = $value;
      }  
    }

    // We need to transfer the pk_id to the 'id_open_request' field.
    $newPayload['id_open_request'] = $id;
    // Let the system handle the ai, unique pk.
    $newPayload['id'] = null;
    
    CompletedRequests::insert_member('completed_requests', $newPayload);
    
    self::delete_member('open_requests', array(0 => 'id', 1 => $id));
  }  


}