 <?php
/**
 * Loader model.
 * This contains functions to load in specific portions.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date August 2013
 */
 
 
class Loader
{
  /**
 * Default loader function.
 * 
 * @parameter $what   Which include.
 * @parameter $title  Title for the head include. 
 * @return 
 *
 */
  public static function load($what, $title)
  {
    switch($what)
    {
      case 'head':
        return require_once('/var/www/application/views/inc/head.php');
        break;
      case 'masthead':    
        require_once('/var/www/application/views/inc/masthead.php');
        break;
      case 'footer':
        require_once('/var/www/application/views/inc/footer.php');
        break;
      default:
        break; 
    }
  }

}