<?php
/**
 * Data model class.
 * This class is used to get and set the various data points.
 * 
 * @author Rudy Pospisil <rudy@rudypospisil.com>
 * @package Frederick Goldman Photo Image System
 * @version 1.0.0
 * @date July 2013
 */
class Data 
{

  // Getter for the logged in user's privileges. Defaults to NULL if invalid user.
  public static function get_userPrivileges()
  {
    $userPrivileges = Session::get('privileges', NULL);
    return $userPrivileges;
  }

    
  // Getter for the request edits entered in by user.
  public static function get_userInputs()
  {
    $userInputs = new stdClass();

    $userInputs->angle              = Input::get('angle', 'None');
    $userInputs->batchNo            = Input::get('batchNo', 'Error');
    $userInputs->brand              = Input::get('brand', 'None');
    $userInputs->dueDate            = Input::get('dueDate', 'TBD');
    $userInputs->emailAlerts        = Input::get('emailAlerts', 'None');
    $userInputs->id_open_request    = Input::get('id');
    $userInputs->itemNo             = Input::get('itemNo', 'None');
    $userInputs->notes              = Input::get('notes', 'None');
    $userInputs->photographer       = Input::get('photographer', 'TBD');
    $userInputs->priority           = Input::get('priority', '1');
    $userInputs->projectTitle       = Input::get('projectTitle', 'None');
    $userInputs->requester          = Input::get('requester', 'None');
    $userInputs->shootDate          = Input::get('shootDate', 'TBD');
    $userInputs->status             = Input::get('status', 'New');
    $userInputs->styleNo            = Input::get('styleNo', 'None');
    
    $userInputs->type               = Input::get('type', 'None');
    if($userInputs->type == 'Customer Request')
    {
      $userInputs->customer = Input::get('customerName', 'None');
      // Grab specs of chosen customer.
      // Easier to query the db, rather than pushing the javascript to php.
      $customerData = DB::table('customers')->where('customer', '=', $userInputs->customer)->first();
      $userInputs->customerFileType     = $customerData->file_type;
      $userInputs->customerFileWidth    = $customerData->width;
      $userInputs->customerFileHeight   = $customerData->height;
      $userInputs->customerComment      = ($customerData->comment) ? $customerData->comment : 'None';
    }
    else
    {
      $userInputs->customer             = 'NA';
      $userInputs->customerFileType     = 'NA';
      $userInputs->customerFileWidth    = 'NA';
      $userInputs->customerFileHeight   = 'NA';
      $userInputs->customerComment      = 'NA';          
    }    
    return $userInputs;        
  }



  // Setter for the update request payload.
  public static function set_updateRequestPayload($userMemberof, $userInputs)
  {
    switch($userMemberof)
    {
      case 'admin':
      case 'manager':
        // Build array with the user inputs.
        $payload = array(
          'angle'               => $userInputs->angle,
          'batch_no'            => $userInputs->batchNo,                                
          'brand'               => $userInputs->brand,
          'customer'            => $userInputs->customer,
          'customer_comment'    => $userInputs->customerComment,
          'due_date'            => $userInputs->dueDate,      
          'email_alerts'        => $userInputs->emailAlerts,      
          'file_type'           => $userInputs->customerFileType,
          'file_width'          => $userInputs->customerFileWidth,
          'file_height'         => $userInputs->customerFileHeight,
          'id_open_request'     => $userInputs->id_open_request,
          'item_no'             => $userInputs->itemNo,
          'notes'               => $userInputs->notes,
          'photographer'        => $userInputs->photographer,
          'priority'            => $userInputs->priority,      
          'project_title'       => $userInputs->projectTitle,
          'requester'           => $userInputs->requester,
          'shoot_date'          => $userInputs->shootDate,      
          'status'              => $userInputs->status,
          'style_no'            => $userInputs->styleNo,
          'type'                => $userInputs->type
          );                          
        return $payload;
        break;
      case 'contributor':
      case 'photog':
        $payload = array(
          'status'              => $userInputs->status
          );                          
        return $payload;
        break;
      case NULL:
        Return Redirect::to('login');
      default:
        Return Redirect::to('login');    
    }
  }



  // Getter for the open request payload.
  public static function get_openRequest($id)
  {
    $openRequest = DB::table('open_requests')->find($id);

    return $openRequest;
  }


  // Setter for the open request payload.
  public static function set_requestPayload($id, $openRequest)
  {
    // A request may have been completed, so we update the status. 
    $payload = array(
          'id_open_request'     => $id,
          'angle'               => $openRequest->angle,
          'batch_no'            => $openRequest->batchNo,                                
          'brand'               => $openRequest->brand,
          'customer'            => $openRequest->customer,
          'due_date'            => $openRequest->dueDate,      
          'email_alerts'        => $openRequest->emailAlerts,      
          'file_type'           => $openRequest->customerFileType,
          'file_width'          => $openRequest->customerFileWidth,
          'file_height'         => $openRequest->customerFileHeight,
          'item_no'             => $openRequest->itemNo,
          'notes'               => $openRequest->notes,
          'photographer'        => $openRequest->photographer,
          'priority'            => $openRequest->priority,      
          'project_title'       => $openRequest->projectTitle,
          'requester'           => $openRequest->requester,
          'shoot_date'          => $openRequest->shootDate,      
          'status'              => $openRequest->status,
          'style_no'            => $openRequest->styleNo,
          'type'                => $openRequest->type
          );
    return $payload;
  }
    
}	
